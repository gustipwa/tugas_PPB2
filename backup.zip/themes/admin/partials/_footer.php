
        <div class="footer">
            
            <div>
                <strong>Copyright</strong> Pusdatin Kemdikbud &copy; 2018
            </div>
        </div>

<div id="loading-all" class="modal fade bs-modal-lg">Loading...</div>
<!-- Modal -->
<div data-backdrop="static" data-keyboard="false" class="modal fade bs-modal-lg" id="modal-custom-global" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title" id="myModal-custom-Label">Detail</h4>
        </div>
        <div class="modal-body" id="modal-custom-body">
        Loading content...
        </div>
        
    </div>
  </div>
</div>
    <!-- Modal -->
    <div data-backdrop="static" data-keyboard="false" class="modal fade bs-modal-lg" id="modal-global"  role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title" id="myModalLabel">Detail</h4>
        </div>
        <div class="modal-body" id="modal-body">
        Loading content...
        </div>
        <div class="modal-footer">

        </div>
    </div>
      </div>
    </div>
  

<!-- Mainly scripts -->
    
    <script src="<?php echo base_url(); ?>themes/admin/plugins/select2/select2.full.min.js"></script>
    <script src="<?php echo base_url(); ?>themes/admin/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url(); ?>themes/admin/plugins/slimscroll/jquery.slimscroll.min.js"></script>
 
    <!-- Custom and plugin javascript -->
    <script src="<?php echo base_url(); ?>themes/admin/js/inspinia.js"></script>
    <script src="<?php echo base_url(); ?>themes/admin/plugins/pace/pace.min.js"></script>

    <!-- GITTER -->
    <script src="<?php echo base_url(); ?>themes/admin/plugins/gritter/jquery.gritter.min.js"></script>

    <!-- Sparkline -->
    <script src="<?php echo base_url(); ?>themes/admin/plugins/sparkline/jquery.sparkline.min.js"></script>

    <!-- Sparkline demo data  -->
    <script src="<?php echo base_url(); ?>themes/admin/js/demo/sparkline-demo.js"></script>

    <!-- ChartJS-->
    <script src="<?php echo base_url(); ?>themes/admin/plugins/chartJs/Chart.min.js"></script>

    
    <script src="<?php echo base_url(); ?>themes/admin/js/razor_app.js"></script>
    <script src="<?php echo base_url(); ?>themes/admin/plugins/datatables/dataTables.bootstrap.min.js"></script>
    <!-- sweet alert -->
    <script src="<?php echo base_url(); ?>themes/admin/js/sweetalert.js"></script>
    <link rel="stylesheet" href="<?php echo base_url(); ?>themes/admin/css/sweetalert.css">
    
<script type="text/javascript">
$('body').on('click','.show-modal',function (event) { 
    $('.perhatian').fadeOut(300, function(){});
      event.preventDefault();
      var currentBtn = $(this);
      var title = currentBtn.attr("tooltip");
      //alert(currentBtn.attr("href"));
      $.ajax({
      url: currentBtn.attr("href"),
      type: 'post',
      beforeSend: function (xhr) {
          $("#loading-all").show();
      },
      success: function (content, status, xhr) {
          var json = null;
          var is_json = true;
          try {
            json = $.parseJSON(content);
          } catch (err) {
            is_json = false;
          }
          if (is_json == false) {
            $("#modal-body").html(content);
            $("#myModalLabel").html(title);
            $("#modal-global").modal('show');
            $("#loading-all").hide();
          } else {
            alert("Error");
          }
      }
      }).fail(function (data, status) {
      if (status == "error") {
          alert("Error");
      } else if (status == "timeout") {
          alert("Error");
      } else if (status == "parsererror") {
          alert("Error");
      }
      });
  });
 
$('body').on('click','.popup',function () { 
  var url =$(this).attr("url");
  popitup(url);
});
function popitup(url,title = "Print window",w = 700,h=600) {
  var left = (screen.width/2)-(w/2);
    var top = (screen.height/2)-(h/2);

    return window.open(url, title, 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width='+w+', height='+h+', top='+top+', left='+left);

}
</script>
</body>
</html>