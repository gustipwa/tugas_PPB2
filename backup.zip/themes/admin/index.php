<?php echo theme_view('partials/_header'); ?> 
<?php
    $mainmenu = $this->uri->segment(2);
    $menu = $this->uri->segment(3);
?>
<body class="top-navigation">
    <div id="wrapper">
        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom white-bg">
        <nav class="navbar navbar-static-top" role="navigation">
            <div class="navbar-header">
                <button aria-controls="navbar" aria-expanded="false" data-target="#navbar" data-toggle="collapse" class="navbar-toggle collapsed" type="button">
                    <i class="fa fa-reorder"></i>
                </button>
                <a href="#" class="navbar-brand">E Informasi</a>
            </div>
            <div class="navbar-collapse collapse" id="navbar">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a aria-expanded="false" role="button" href="<?php echo base_url();?>admin/kepegawaian/pegawai/profile">Profile</a>
                    </li>
                    <?php if ($this->auth->has_permission('Dashboard.Reports.View')) : ?>
                    <li class="active">
                        <a aria-expanded="false" role="button" href="<?php echo base_url();?>admin/reports/dashboard">Dashboard</a>
                    </li>
                    <?php endif; ?>
                    <?php if ($this->auth->has_permission('Site.Kepegawaian.View')) : ?>
                    <li class="dropdown">
                        <a aria-expanded="false" role="button" href="#" class="dropdown-toggle" data-toggle="dropdown"> Pegawai <span class="caret"></span></a>
                        <ul role="menu" class="dropdown-menu">
                            <li><a href="<?php echo base_url();?>admin/kepegawaian/pegawai"><i class="fa fa-circle-o"></i> 
                              Data Pegawai</a>
                            </li>
                            <li><a href="<?php echo base_url();?>admin/kepegawaian/pegawai/ppnpn"><i class="fa fa-circle-o"></i> 
                              Data Pegawai PPNPN</a>
                            </li>
                            <li><a href="<?php echo base_url();?>admin/izin/sisa_cuti"><i class="fa fa-circle-o"></i> 
                              Sisa Cuti Pegawai</a>
                            </li>
                            <li><a href="<?php echo base_url();?>pegawai/diklatfungsional/daftar"><i class="fa fa-circle-o"></i> 
                              Data Diklat Fungsional</a>
                            </li>
                            <li><a href="<?php echo base_url();?>pegawai/diklatstruktural/daftar"><i class="fa fa-circle-o"></i> 
                              Data Diklat Struktural</a>
                            </li>
                            <li><a href="<?php echo base_url();?>pegawai/riwayatkursus/daftar"><i class="fa fa-circle-o"></i> 
                              Data Diklat Teknis</a>
                            </li>
                            <li><a href="<?php echo base_url();?>pegawai/riwayat_tugasbelajar/daftar"><i class="fa fa-circle-o"></i> 
                              Data Tugas Belajar</a>
                            </li>
                        </ul>
                    </li>
                    <?php endif; ?>
                    <li class="dropdown">
                        <a aria-expanded="false" role="button" href="#" class="dropdown-toggle" data-toggle="dropdown"> Perizinan <span class="caret"></span></a>
                        <ul role="menu" class="dropdown-menu">
                            <li><a href="<?php echo base_url();?>admin/izin/izin_pegawai"><i class="fa fa-circle-o"></i> 
                              Cuti</a>
                            </li>
                            <!-- update -->
                            <?php if ($this->auth->has_permission('Izin_pegawai.Verifikasi.View')) : ?>
                            <li><a href="<?php echo base_url();?>admin/izin/izin_pegawai/viewall"><i class="fa fa-circle-o"></i> 
                              Verifikasi Cuti</a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    
                    <?php if ($this->auth->has_permission('Site.Reports.View')) : ?>
                    <li class="dropdown">
                        <a aria-expanded="false" role="button" href="#" class="dropdown-toggle" data-toggle="dropdown"> Laporan <span class="caret"></span></a>
                        <ul role="menu" class="dropdown-menu">
                            <li>
                              <a href="<?php echo base_url();?>rekap/golongan_usia">
                                  <i class="fa fa-circle-o"></i>
                                  <span>Golongan dan Range Usia </span>    
                              </a>
                            </li>
                            <li>
                              <a href="<?php echo base_url();?>rekap/bup_usia">
                                  <i class="fa fa-circle-o"></i>
                                  <span>BUP dan Usia </span>    
                              </a>
                            </li>
                            <li>
                              <a href="<?php echo base_url();?>rekap/gender_usia">
                                  <i class="fa fa-circle-o"></i>
                                  <span>Gender dan Usia </span>    
                              </a>
                            </li>
                            <li>
                              <a href="<?php echo base_url();?>rekap/pendidikan_usia">
                                  <i class="fa fa-circle-o"></i>
                                  <span>Pendidikan dan Usia </span>    
                              </a>
                            </li>
                            <li>
                              <a href="<?php echo base_url();?>rekap/golongan_gender">
                                  <i class="fa fa-circle-o"></i>
                                  <span>Golongan dan Gender </span>    
                              </a>
                            </li>

                            <li>
                              <a href="<?php echo base_url();?>rekap/golongan_pendidikan">
                                  <i class="fa fa-circle-o"></i>
                                  <span>Golongan dan Pendidikan </span>    
                              </a>
                            </li>
                            <li>
                              <a href="<?php echo base_url();?>rekap/pendidikan_gender">
                                  <i class="fa fa-circle-o"></i>
                                  <span>Pendidikan dan Gender </span>    
                              </a>
                            </li>
                            <li>
                              <a href="<?php echo base_url();?>rekap/agama_gender">
                                  <i class="fa fa-circle-o"></i>
                                  <span>Agama dan Gender </span>    
                              </a>
                            </li>
                            <li>
                              <a href="<?php echo base_url();?>rekap/stats-pegawai-jabatan">
                                  <i class="fa fa-circle-o"></i>
                                  <span>Jumlah Pegawai per Kategori Jabatan </span>    
                              </a>
                            </li>
                            <li>
                              <a href="<?php echo base_url();?>admin/reports/pegawai/jabatan">
                                  <i class="fa fa-circle-o"></i>
                                  <span>Jumlah Pegawai per Jabatan </span>    
                              </a>
                            </li>
                         
                            <li><a href="<?php echo base_url();?>pegawai/duk"><i class="fa fa-circle-o"></i>
                              Daftar Urut Kepangkatan</a>
                            </li>
                            <?php if ($this->auth->has_permission('Petajabatan.Reports.View')) : ?>
                            <li><a href="<?php echo base_url();?>admin/reports/petajabatan"><i class="fa fa-table"></i>
                              Daftar kuota jabatan</a>
                            </li>
                            <?php endif; ?>
                            <?php if ($this->auth->has_permission('Petajabatan.Reports.View')) : ?>
                            <li><a href="<?php echo base_url();?>admin/reports/bezzeting"><i class="fa fa-table"></i>
                              Bezzeting</a>
                            </li>
                            <?php endif; ?>
                            <?php if ($this->auth->has_permission('Activities.Module.View')) : ?>
                            <li><a href="<?php echo base_url();?>admin/reports/activities"><i class="fa fa-table"></i>
                              Log Aktifitas User</a>
                            </li>
                            <?php endif; ?>
                            <?php if ($this->auth->has_permission('Site.Kepegawaian.View')) : ?>
                            <li><a href="<?php echo base_url();?>pegawai/duk/duksatker"><i class="fa fa-table"></i>
                              Daftar Nominatif PNS</a>
                            </li>
                            <?php endif; ?>
                            <?php if ($this->auth->has_permission('Site.Kepegawaian.View')) : ?>
                            <li><a href="<?php echo base_url();?>pegawai/duk/dukppnpn"><i class="fa fa-table"></i>
                              Daftar Nominatif PPNPN</a>
                            </li>
                            <?php endif; ?>
                            <?php if ($this->auth->has_permission('Proyeksi_pensiun.Reports.View')) : ?>
                            <li><a href="<?php echo base_url();?>admin/reports/proyeksi_pensiun"><i class="fa fa-circle-o"></i>
                              Proyeksi Pensiun</a>
                            </li>
                            <li><a href="<?php echo base_url();?>admin/reports/arsip_digital/jenis"><i class="fa fa-circle-o"></i>
                              Laporan Arsip</a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <?php endif; ?>
                    <?php if ($this->auth->has_permission('Site.Masters.View')) : ?>
                    <li class="dropdown">
                        <a aria-expanded="false" role="button" href="#" class="dropdown-toggle" data-toggle="dropdown"> Master Data <span class="caret"></span></a>
                        <ul role="menu" class="dropdown-menu">
                            <?php if ($this->auth->has_permission('Agama.Masters.View')) : ?>
                            <li><a href="<?php echo base_url();?>admin/masters/agama">
                              <i class="fa fa-circle-o"> </i>
                              <span>Agama</span></a>
                            </li>
                            <?php endif; ?>
                            <?php if ($this->auth->has_permission('Jabatan.Masters.View')) : ?>
                            <li>
                              <a href="<?php echo base_url();?>admin/masters/jabatan">
                                <i class="fa fa-circle-o"></i>
                                Jabatan
                              </a>
                            </li>
                            <?php endif; ?>
                            <?php if ($this->auth->has_permission('MasterPendidikan.Masters.View')) : ?>
                            <li>
                                <a href="<?php echo base_url();?>pegawai/masterpendidikan"><i class="fa fa-circle-o"></i>
                                Pendidikan
                              </a>
                            </li>
                            <?php endif; ?>
                             <?php if ($this->auth->has_permission('Tkpendidikan.Masters.View')) : ?>
                            <li>
                                <a href="<?php echo base_url();?>admin/masters/tkpendidikan">
                                    <i class="fa fa-circle-o"></i>
                                  Tk Pendidikan
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if ($this->auth->has_permission('Golongan.Masters.View')) : ?>
                            <li>
                                <a href="<?php echo base_url();?>admin/masters/golongan">
                                  <i class="fa fa-circle-o"></i>
                                Golongan
                              </a>
                            </li>
                            <li>
                              <a href="<?php echo base_url();?>pegawai/manage_unitkerja/index">
                                <i class="fa fa-circle-o"></i> Unit Kerja
                              </a>
                            </li>
                            <li>
                              <a href="<?php echo base_url();?>admin/masters/jenis_arsip">
                                <i class="fa fa-circle-o"></i> Jenis Arsip
                              </a>
                            </li>
                            <!--
                            <li>
                              <a href="<?php echo base_url();?>petajabatan/struktur">
                                <i class="fa fa-circle-o"></i> Struktur Organisasi
                              </a>
                            </li>
                            -->
                            <li>
                              <a href="<?php echo base_url();?>petajabatan/struktur/strukturpusdatin">
                                <i class="fa fa-circle-o"></i> Struktur Organisasi
                              </a>
                            </li>
                            <li>
                              <a href="<?php echo base_url();?>petajabatan/struktur/balai/8ae483a67355ebc601736ae963080395">
                                <i class="fa fa-circle-o"></i> Struktur Organisasi Balai Pengembangan Media Televisi Pendidikan dan Kebudayaan
                              </a>
                            </li>
                            <li>
                              <a href="<?php echo base_url();?>petajabatan/struktur/balai/8ae483a67355ebc601736aeb88400409">
                                <i class="fa fa-circle-o"></i> Struktur Organisasi Balai Pengembangan Media Radio Pendidikan dan Kebudayaan
                              </a>
                            </li>
                            <li>
                              <a href="<?php echo base_url();?>petajabatan/struktur/balai/8ae483a67355ebc601736aecec3f044f">
                                <i class="fa fa-circle-o"></i> Struktur Organisasi Balai Pengembangan Multimedia Pendidikan dan Kebudayaan
                              </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <?php endif; ?>

                    
                    <?php if ($this->auth->has_permission('Site.Settings.View')) : ?>
                    <li class="dropdown">
                        <a aria-expanded="false" role="button" href="#" class="dropdown-toggle" data-toggle="dropdown"> Setting <span class="caret"></span></a>
                        <ul role="menu" class="dropdown-menu">
                            <li><a href="<?php echo base_url();?>admin/settings/settings"><i class="fa fa-circle-o"></i> 
                            Pengaturan</a></li>
                            <li><a href="<?php echo base_url();?>admin/settings/roles"><i class="fa fa-circle-o"></i> 
                            Role</a></li>
                            <li><a href="<?php echo base_url();?>admin/settings/users"><i class="fa fa-circle-o"></i> 
                            User</a></li>
                            <li><a href="<?php echo base_url();?>admin/settings/permissions"><i class="fa fa-circle-o"></i> 
                            Permissions</a></li>
                        </ul>
                    </li>
                    <?php endif; ?>
                </ul>
                <ul class="nav navbar-top-links navbar-right">
                  <!--
                  <li class="dropdown">
                    <a class="dropdown-toggle count-info" data-toggle="dropdown" href="#" aria-expanded="false">
                        <i class="fa fa-envelope"></i>  <span class="label label-warning">16</span>
                    </a>
                    <ul class="dropdown-menu dropdown-messages">
                        <li>
                            <div class="dropdown-messages-box">
                                <a href="profile.html" class="pull-left">
                                    <img alt="image" class="img-circle" src="img/a7.jpg">
                                </a>
                                <div class="media-body">
                                    <small class="pull-right">46h ago</small>
                                    <strong>Mike Loreipsum</strong> started following <strong>Monica Smith</strong>. <br>
                                    <small class="text-muted">3 days ago at 7:58 pm - 10.06.2014</small>
                                </div>
                            </div>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <div class="dropdown-messages-box">
                                <a href="profile.html" class="pull-left">
                                    <img alt="image" class="img-circle" src="img/a4.jpg">
                                </a>
                                <div class="media-body ">
                                    <small class="pull-right text-navy">5h ago</small>
                                    <strong>Chris Johnatan Overtunk</strong> started following <strong>Monica Smith</strong>. <br>
                                    <small class="text-muted">Yesterday 1:21 pm - 11.06.2014</small>
                                </div>
                            </div>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <div class="dropdown-messages-box">
                                <a href="profile.html" class="pull-left">
                                    <img alt="image" class="img-circle" src="img/profile.jpg">
                                </a>
                                <div class="media-body ">
                                    <small class="pull-right">23h ago</small>
                                    <strong>Monica Smith</strong> love <strong>Kim Smith</strong>. <br>
                                    <small class="text-muted">2 days ago at 2:30 am - 11.06.2014</small>
                                </div>
                            </div>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <div class="text-center link-block">
                                <a href="mailbox.html">
                                    <i class="fa fa-envelope"></i> <strong>Read All Messages</strong>
                                </a>
                            </div>
                        </li>
                    </ul>
                </li>
              -->
                    <li class="user-header">
                      <a href="<?php echo base_url(); ?>admin/settings/users/edituser/">[
                        <b><?php echo (isset($current_user->display_name) && !empty($current_user->display_name)) ? $current_user->display_name : ($this->settings_lib->item('auth.use_usernames') ? $current_user->username : $current_user->email); ?>
                        </b>]</a>
                    </li>
                    <?php if($this->session->userdata('username_real') != ""){ ?>
                      <li>
                          <a href="<?php echo base_url(); ?>admin/settings/users/loginback/<?php echo $this->session->userdata('username_real'); ?>"><i class="fa fa-backward"></i>  <?php echo $this->session->userdata('username_real'); ?></a>
                      </li>
                    <?php } ?>
                    <li>
                        <a href="<?php echo site_url('logout'); ?>">
                            <i class="fa fa-sign-out"></i> Log out
                        </a>
                    </li>
                </ul>
            </div>
        </nav>
        </div>
        <div class="wrapper wrapper-content">
            <div class="container">
                 
                <?php echo Template::message(); ?>
                                  <?php echo isset($content) ? $content : Template::content(); ?>
            </div>
        </div>
  <?php echo theme_view('partials/_footer'); ?> 