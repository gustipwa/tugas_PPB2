<style type="text/css">
    .select2-container {
    z-index: 99999;
}
.select2-container {
    width: 100% !important;
    padding: 0;
}
</style>
<style>
	.dt-center {
		text-align:center;
	}
</style>
<!--tab-pane-->
<div class="tab-pane" id="<?php echo $TAB_ID;?>">
    <div class=" panel-body">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-21 col-xs-12">
            	<div class="mail-tools tooltip-demo m-t-md pull-right">
		            <?php if ($this->auth->has_permission('Riwayattugas_tambahan.Kepegawaian.Updatemandiri')) : ?>
			            <a type="button" class="show-modal-custom btn btn-sm btn-success" href="<?php echo base_url(); ?>pegawai/riwayattugas_tambahan/addmandiri/<?php echo $PNS_ID ?>" tooltip="Tambah Riwayat Tugas Tambahan (Mandiri)">
							<i class="fa fa-plus"></i> Tambah Tambahan
			            </a>
		            <?php endif; ?>
		            <?php if ($this->auth->has_permission('Riwayattugas_tambahan.Kepegawaian.Create')) : ?>
			            <a type="button" class="show-modal-custom btn btn-sm btn-warning" href="<?php echo base_url(); ?>pegawai/riwayattugas_tambahan/add/<?php echo $PNS_ID ?>" tooltip="Tambah Riwayat Tugas Tambahan">
							<i class="fa fa-plus"></i> Tambah
			            </a>
		            <?php endif; ?>
		        </div>
            <table class="table table-datatable">
            <thead>
                <tr>
                    <th width='20px' >No</th>
                    <th width="140px">Nomor SK</th>
                    <th width="100px">Tanggal SK</th>
                    <th>Nama Tugas</th>
                    <th width='100px' align="center">AKSI</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                        
                </tr>
            </tfoot>
            <tbody>
               
            </tbody>
        </table>  
        </div>
        </div>
    </div>
</div>
<!--tab-pane-->


<script type="text/javascript">

	(function($){
		var $container = $("#<?php echo $TAB_ID;?>");
		var grid_daftar = $(".table-datatable",$container).DataTable({
				ordering: false,
				processing: true,
				"bFilter": false,
				"bLengthChange": false,
				serverSide: true,
				"columnDefs": [
					//{"className": "dt-center", "targets": "_all"}
					{"className": "dt-center", "targets": [0,2,4]}
				],
				ajax: {
					url: "<?php echo base_url() ?>pegawai/riwayattugas_tambahan/ajax_list",
					type:'POST',
					data : {
						PNS_ID:'<?php echo $PNS_ID;?>'
					}
				}
		});
		$container.on('click','.show-modal-custom',function(event){
			showModalX.call(this,'sukses-tambah-riwayat-tt',function(){
				grid_daftar.ajax.reload();
			},this);
			event.preventDefault();
		});
		$container.on('click','.show-modal',showModalX);

		$container.on('click','.btn-hapus',function(event){
			event.preventDefault();
			var kode =$(this).attr("kode");
				swal({
					title: "Anda Yakin?",
					text: "Hapus data Riwayat Tugas Tambahan!",
					type: "warning",
					showCancelButton: true,
					confirmButtonClass: 'btn-danger',
					confirmButtonText: 'Ya, Hapus!',
					cancelButtonText: "Tidak, Batalkan!",
					closeOnConfirm: false,
					closeOnCancel: false
				},
				function (isConfirm) {
					if (isConfirm) {
						var post_data = "kode="+kode;
						$.ajax({
								url: "<?php echo base_url() ?>pegawai/riwayattugas_tambahan/delete/"+kode,
								dataType: "html",
								timeout:180000,
								success: function (result) {
									swal("Data berhasil di hapus!", result, "success");
									grid_daftar.ajax.reload();
							},
							error : function(error) {
								alert(error);
							} 
						});        
						
					} else {
						swal("Batal", "", "error");
					}
				});
		});
				
	})(jQuery);
</script>
