<style type="text/css">
    .select2-container {
    z-index: 99999;
}
.select2-container {
    width: 100% !important;
    padding: 0;
}
</style>
<?php 
    $id = isset($detail_riwayat->ID) ? $detail_riwayat->ID : '';
?>
<div class='box box-warning' id="form-riwayat-tb-add">
	<div class="box-body">
        <div class="messages">
        </div>
    <?php echo form_open($this->uri->uri_string(), 'id="form-riwayat-penghargaan-add"'); ?>
    <fieldset>
        
            <input id='id' type='hidden' class="form-control" name='id' maxlength='32' value="<?php echo set_value('ID', isset($detail_riwayat->ID) ? trim($detail_riwayat->ID) : ''); ?>" />
            <input type='hidden' class="form-control" name='PNS_NIP' maxlength='32' value="<?php echo set_value('NIP_BARU', isset($NIP_BARU) ? trim($NIP_BARU) : ''); ?>" />
            <div class="row">
                <div class="control-group<?php echo form_error('ID_JENIS_PENGHARGAAN') ? ' error' : ''; ?> col-sm-12">
                    <?php echo form_label('Penghargaan', 'ID_JENIS_PENGHARGAAN', array('class' => 'control-label')); ?>
                    <div class='controls'>
                        <select name="ID_JENIS_PENGHARGAAN" id="ID_JENIS_PENGHARGAAN" class="form-control">
                            <option value="">-- Silahkan Pilih --</option>
                            <?php if (isset($jeniss) && is_array($jeniss) && count($jeniss)):?>
                            <?php foreach($jeniss as $record):?>
                                <option value="<?php echo $record->ID?>" <?php if(isset($detail_riwayat->ID_JENIS_PENGHARGAAN))  echo  ($detail_riwayat->ID_JENIS_PENGHARGAAN==$record->ID) ? "selected" : ""; ?>><?php echo $record->NAMA; ?></option>
                                <?php endforeach;?>
                            <?php endif;?>
                        </select>
                        <span class='help-inline'><?php echo form_error('ID_JENIS_PENGHARGAAN'); ?></span>
                    </div>
                </div>   
                <div class="control-group<?php echo form_error('n_gol_ruang') ? ' error' : ''; ?> col-sm-8">
                    <?php echo form_label("NOMOR SK", 'Golongan Ruang', array('class' => 'control-label')); ?>
                    <div class='controls'>
                        <input id='SK_NOMOR' type='text' class="form-control" name='SK_NOMOR' maxlength='200' value="<?php echo set_value('SK_NOMOR', isset($detail_riwayat->SK_NOMOR) ? trim($detail_riwayat->SK_NOMOR) : ''); ?>" />
                        <span class='help-inline'><?php echo form_error('SK_NOMOR'); ?></span>
                    </div>
                </div>
                <div class="control-group col-sm-4">
                    <label for="inputNAMA" class="control-label">TANGGAL SK</label>
                    <div class="input-group date">
                    <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                    </div>
                        <input type='text' class="form-control pull-right datepicker" name='SK_TANGGAL'  value="<?php echo set_value('SK_TANGGAL', isset($detail_riwayat->SK_TANGGAL) ? $detail_riwayat->SK_TANGGAL : ''); ?>" />
                        <span class='help-inline'><?php echo form_error('SK_TANGGAL'); ?></span>
                    </div>
                </div>
                <div class="control-group<?php echo form_error('NILAI_SKP_N1') ? ' error' : ''; ?> col-sm-8">
                    <?php echo form_label("NILAI SKP N1", 'NILAI_SKP_N1', array('class' => 'control-label')); ?>
                    <div class='controls'>
                        <input id='NILAI_SKP_N1' type='text' class="form-control" name='NILAI_SKP_N1' maxlength='7' value="<?php echo set_value('NILAI_SKP_N1', isset($detail_riwayat->NILAI_SKP_N1) ? trim($detail_riwayat->NILAI_SKP_N1) : ''); ?>" />
                        <span class='help-inline'><?php echo form_error('NILAI_SKP_N1'); ?></span>
                    </div>
                </div> 
                <div class="control-group<?php echo form_error('NILAI_SKP_N2') ? ' error' : ''; ?> col-sm-8">
                    <?php echo form_label("NILAI SKP N2", 'NILAI_SKP_N2', array('class' => 'control-label')); ?>
                    <div class='controls'>
                        <input id='NILAI_SKP_N2' type='text' class="form-control" name='NILAI_SKP_N2' maxlength='7' value="<?php echo set_value('NILAI_SKP_N2', isset($detail_riwayat->NILAI_SKP_N2) ? trim($detail_riwayat->NILAI_SKP_N2) : ''); ?>" />
                        <span class='help-inline'><?php echo form_error('NILAI_SKP_N2'); ?></span>
                    </div>
                </div> 
            </div>
             
            </fieldset>
        </div>
  		<div class="box-footer">
            <hr>
            <input type='submit' name='save' id="btnsave" class='btn btn-primary' value="Simpan Data" /> 
        </div>
    <?php echo form_close(); ?>
</div>
<script src="<?php echo base_url(); ?>themes/admin/plugins/datepicker/bootstrap-datepicker.js"></script>
<script>
	 $(".select2").select2({width: '100%'});
</script>
<script>
  
    var form = $("#form-riwayat-penghargaan-add");
    //Date picker
    $('.datepicker').datepicker({
      autoclose: true,format: 'yyyy-mm-dd'
    }).on("input change", function (e) {
        var date = $(this).datepicker('getDate');
    });
</script>
<script>
	$("#btnsave").click(function(){
		submitdata();
		return false; 
	});	
	$("#frmA").submit(function(){
		submitdata();
		return false; 
	});	
    $(document).ready(function(){
        $(".lazy-select2").each(function(i,o){
            $(this).select2(
                {
                    placeholder: $(this).data('placeholder'),
                    width: '100%',
                    minimumInputLength: $(this).data('minimum'),
                    allowClear: true,
                    ajax: {
                        url: $(this).data('url'),
                        dataType: 'json',
                        data: function(params) {
                            return {
                                term: params.term || '',
                                page: params.page || 1
                            }
                        },
                        cache: true
                    }
                }
            );
        });
    });
	function submitdata(){
		var the_data = new FormData(document.getElementById("form-riwayat-penghargaan-add"));
		var json_url = "<?php echo base_url() ?>pegawai/riwayat_penghargaan/savemandiri";
		 $.ajax({    
		 	type: "POST",
			url: json_url,
			data: the_data,
            dataType: "json",
            processData: false, // tell jQuery not to process the data
            contentType: false, // tell jQuery not to set contentType
			success: function(data){ 
                if(data.success){
                    swal("Pemberitahuan!", data.msg, "success");
                    $("#modal-custom-global").trigger("sukses-tambah-riwayat-tb");
					$("#modal-global").modal("hide");
                    $("#modal-custom-global").modal("hide");
                    $grid_daftar.ajax.reload();
                }
                else {
                    $("#form-riwayat-tb-add .messages").empty().append(data.msg);
                }
			}});
		return false; 
	}
</script>