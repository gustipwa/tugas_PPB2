
<?php 
	$this->load->library('convert');
 	$convert = new convert();
    $tab_pane_pk = "tab_pane_pk";
    $tab_pane_penghargaan = "tab_pane_penghargaan";
    $tab_pane_arsip = "tab_pane_arsip";
    
?>
<?php
$id = isset($pegawai->ID) ? $pegawai->ID : '';
$PNS_ID = isset($pegawai->PNS_ID) ? $pegawai->PNS_ID : '';
$NIP_BARU = isset($pegawai->NIP_BARU) ? $pegawai->NIP_BARU : '';
?>
<div class="tab-pane" id="<?php echo $TAB_ID;?>">
    <div class=" panel-body">
        <div class="nav-tabs">
            <ul id="tab-insides-riwayat" class="nav nav-tabs">
                 
                <?php if($this->auth->has_permission("Riwayatpk.Kepegawaian.View")){ ?>
                <li class="active">
                    <a href="#<?php echo $tab_pane_pk;?>" data-toggle="tab" aria-expanded="false"> Perjanjian Kinerja </a>
                </li>
                <?php } ?>
                <?php if($this->auth->has_permission("Riwayatpenghargaan.Kepegawaian.View")){ ?>
                <li>
                    <a href="#<?php echo $tab_pane_penghargaan;?>" data-toggle="tab" aria-expanded="false"> Penghargaan </a>
                </li>
                <?php } ?>
                <li>
                    <a href="#<?php echo $tab_pane_arsip;?>" data-toggle="tab" aria-expanded="false"> Arsip </a>
                </li>
            </ul>
            <div class="tab-content">
                <?php 
                    if($this->auth->has_permission("Riwayatpk.Kepegawaian.View")){
                        $this->load->view('kepegawaian/tab_pane_pk',array('TAB_ID'=>$tab_pane_pk,'NIP_BARU'=>$NIP_BARU));
                    }
                    if($this->auth->has_permission("Riwayatpenghargaan.Kepegawaian.View")){
                        $this->load->view('kepegawaian/tab_pane_penghargaan',array('TAB_ID'=>$tab_pane_penghargaan,'NIP_BARU'=>$NIP_BARU));
                    }
                    if($this->auth->has_permission("Arsip_digital.Arsip.View")){
                        $this->load->view('kepegawaian/tab_pane_arsip',array('TAB_ID'=>$tab_pane_arsip,'NIP_BARU'=>$NIP_BARU));
                    }
                ?>
                
            </div>
        </div>


    </div>
</div>
