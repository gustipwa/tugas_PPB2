
<?php
$checkSegment = $this->uri->segment(4);
$areaUrl = SITE_AREA . '/kepegawaian/pegawai';
$num_columns	= 44;
$can_delete	= $this->auth->has_permission('Pegawai.Kepegawaian.Delete');
$can_edit		= $this->auth->has_permission('Pegawai.Kepegawaian.Edit');
$has_records	= isset($records) && is_array($records) && count($records);

if ($can_delete) {
    $num_columns++;
}
?>
<div class="row">
	<div class="col-md-4">
        <div class="ibox float-e-margins">
            <div class="ibox-title">
                <span class="label label-success pull-right"><?php echo date("Y"); ?></span>
                <h5>PNS PUSAT</h5>
            </div>
            <div class="ibox-content">
                <h1 class="no-margins">
            		<span class="bg-danger b-r-md padding2">
            			<?php echo isset($total_pns) ? number_format($total_pns,0,"",".") : ""; ?> 
            		</span>
                    &nbsp;Pegawai
                </h1>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="ibox float-e-margins">
            <div class="ibox-title">
                <span class="label label-success pull-right"><?php echo date("Y"); ?></span>
                <h5>PNS BALAI</h5>
            </div>
            <div class="ibox-content">
                <h1 class="no-margins">
            		<span class="bg-info b-r-md padding2">
            			<?php echo isset($total_balai) ? number_format($total_balai,0,"",".") : ""; ?> 
            		</span>
                    &nbsp;Pegawai
                </h1>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="ibox float-e-margins">
            <div class="ibox-title">
                <span class="label label-success pull-right"><?php echo date("Y"); ?></span>
                <h5>PPNPN</h5>
            </div>
            <div class="ibox-content">
                <h1 class="no-margins">
            		<span class="bg-success b-r-md padding2">
            			<?php echo isset($total_ppnpn) ? number_format($total_ppnpn,0,"",".") : ""; ?> 
            		</span>
                    &nbsp;Pegawai
                </h1>
            </div>
        </div>
    </div>
</div>
