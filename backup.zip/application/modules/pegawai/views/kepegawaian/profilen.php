
<?php 
	$this->load->library('convert');
    $convert = new convert();
    $tab_pendidikan = "tab_pendidikan";//uniqid("tab_pane_pendidikan");
    $tab_pane_personal_id = "tab_pane_personal";//uniqid("tab_pane_personal");
    $tab_pane_penilaian = "tab_pane_penilaian";//uniqid("tab_pane_kepangkatan");
    $tab_pane_riwayat = "tab_pane_riwayat";//uniqid("tab_pane_pindah_unit_kerja");
    $tab_pane_keluarga = "tab_pane_keluarga";//uniqid("tab_pane_pindah_unit_kerja");
    $tab_pane_lain    = "tab_pane_lain";
?>

<?php

if (validation_errors()) :
?>
<div class='alert alert-block alert-error fade in'>
    <a class='close' data-dismiss='alert'>&times;</a>
    <h4 class='alert-heading'>
        <?php echo lang('pegawai_errors_message'); ?>
    </h4>
    <?php echo validation_errors(); ?>
</div>
<?php
endif;
$id = isset($pegawai->ID) ? $pegawai->ID : '';
$PNS_ID = isset($pegawai->PNS_ID) ? $pegawai->PNS_ID : '';

?>
<div class="admin-box box box-primary profile">
	<div class="box-body">
	 
        <div class="row">
             <div class="col-md-2">
                <ul class="list-unstyled profile-nav">
                    <li>
                        <a href="<?php echo base_url(); ?>admin/kepegawaian/pegawai/uploadfoto/<?php echo $pegawai->PNS_ID; ?>" class="show-modal" title="Upload Photo" tooltip="Upload Photo">
                        <img src="<?php echo (isset($foto_pegawai) && $foto_pegawai != "") ? $foto_pegawai : 'noimage.jpg'; ?>" class="img-responsive pic-bordered" id="photopegawai" alt="">
                         </a>
                    </li>
                </ul>
                <br>
            </div>
            <div class="col-lg-10">
                <h1 class="font-green sbold uppercase"><?php echo isset($pegawai->GELAR_DEPAN) ? $pegawai->GELAR_DEPAN : ''; ?>  <?php echo isset($pegawai->NAMA) ? $pegawai->NAMA : ''; ?> <?php echo isset($pegawai->GELAR_BELAKANG) ? $pegawai->GELAR_BELAKANG : ''; ?></h1>
                <h4><b>NIP</b> <?php echo isset($pegawai->NIP_BARU) ? $pegawai->NIP_BARU : ''; ?></h4>
                <ul class="list-inline">
                    <?php //echo print_r($pegawai); ?>
                    <li>
                        TEMPAT/TGL LAHIR <i class="fa fa-map-marker"></i> 
                        <?php echo isset($selectedTempatLahirPegawai->NAMA) ? $selectedTempatLahirPegawai->NAMA : ""; ?> / 
                         <i class="fa fa-calendar"></i> <?php echo isset($pegawai->TGL_LAHIR) ? $convert->fmtDate($pegawai->TGL_LAHIR,"dd month yyyy") : 'TGL_LAHIR'; ?> 
                    </li>
                    <li>
                        <i class="fa fa-map-marker"></i> <?php echo isset($pegawai->ALAMAT) ? $pegawai->ALAMAT : 'ALAMAT'; ?></li>
                    <div class="tabs-container">
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#<?php echo $tab_pane_personal_id; ?>" aria-expanded="true"> Data Personal</a></li>
                            <li class=""><a data-toggle="tab" href="#<?php echo $tab_pane_keluarga; ?>" aria-expanded="false">Keluarga</a></li>
                            <li class=""><a data-toggle="tab" href="#<?php echo $tab_pendidikan; ?>" aria-expanded="false">Pendidikan</a></li>
                            <li class=""><a data-toggle="tab" href="#<?php echo $tab_pane_penilaian; ?>" aria-expanded="false">Penilaian</a></li>
                            <li class=""><a data-toggle="tab" href="#<?php echo $tab_pane_riwayat; ?>" aria-expanded="false">Riwayat</a></li>
                            <li class=""><a data-toggle="tab" href="#<?php echo $tab_pane_lain; ?>" aria-expanded="false">Lain-lain</a></li>
                        </ul>
                        <div class="tab-content">
                        <?php 
                            if($model=="update"){
                              $this->load->view('kepegawaian/tab_pane_personaledit',array('TAB_ID'=>$tab_pane_personal_id));
                            }else{
                              $this->load->view('kepegawaian/tab_pane_personal',array('TAB_ID'=>$tab_pane_personal_id));  
                            }                       
                            $this->load->view('kepegawaian/tabkeluarga',array('TAB_ID'=>$tab_pane_keluarga));
                            $this->load->view('kepegawaian/tabpendidikan',array('TAB_ID'=>$tab_pendidikan));
                            $this->load->view('kepegawaian/tab_pane_penilaian',array('TAB_ID'=>$tab_pane_penilaian));
                            $this->load->view('kepegawaian/tab_pane_riwayat',array('TAB_ID'=>$tab_pane_riwayat));
                            $this->load->view('kepegawaian/tab_pane_lain',array('TAB_ID'=>$tab_pane_lain));
                        ?>
                        </div>
                    </div>
                </div>
            
        </div>
                
 
    </div>
</div>


 <script>
    $(document).ready(function(){
        $('.nav-tabs').scrollingTabs();
        // Javascript to enable link to tab
        var url = document.location.toString();
        if (url.match('#')) {
            console.log( $('.nav-tabs a[href="#' + url.split('#')[1] + '"]'));
            $('.nav-tabs a[href="#' + url.split('#')[1] + '"]').tab('show');
        } //add a suffix

        // Change hash for page-reload
        $('.nav-tabs a').on('shown.bs.tab', function (e) {
            window.location.hash = e.target.hash;
        })
    });
    
 </script>
