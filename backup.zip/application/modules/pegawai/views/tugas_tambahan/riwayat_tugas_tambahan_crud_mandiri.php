<link href="<?php echo base_url(); ?>themes/admin/plugins/bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url(); ?>themes/admin/plugins/bootstrap-fileinput-master/themes/explorer/theme.css" media="all" rel="stylesheet" type="text/css"/>
<style type="text/css">
    .select2-container {
    z-index: 99999;
}
.select2-container {
    width: 100% !important;
    padding: 0;
}
</style>
<?php 
    $id = isset($detail_riwayat->ID) ? $detail_riwayat->ID : '';
?>
<div class='box box-warning' id="form-riwayat-tb-add">
	<div class="box-body">
        <div class="messages">
        </div>
    <?php echo form_open($this->uri->uri_string(), 'id="form-riwayat-tugas-add"'); ?>
    <fieldset>
        
            <input id='id' type='hidden' class="form-control" name='id' maxlength='32' value="<?php echo set_value('ID', isset($detail_riwayat->ID) ? trim($detail_riwayat->ID) : ''); ?>" />
            <input type='hidden' class="form-control" name='PNS_ID' maxlength='32' value="<?php echo set_value('PNS_ID', isset($PNS_ID) ? trim($PNS_ID) : ''); ?>" />
            <div class="row">
                <div class="control-group<?php echo form_error('NAMA_TUGAS') ? ' error' : ''; ?> col-sm-12">
                    <?php echo form_label("NAMA TUGAS", 'NAMA_TUGAS', array('class' => 'control-label')); ?>
                    <div class='controls'>
                        <input id='NAMA_TUGAS' type='text' class="form-control" name='NAMA_TUGAS' maxlength='200' value="<?php echo set_value('NAMA_TUGAS', isset($detail_riwayat->NAMA_TUGAS) ? trim($detail_riwayat->NAMA_TUGAS) : ''); ?>" />
                        <span class='help-inline'><?php echo form_error('NAMA_TUGAS'); ?></span>
                    </div>
                </div>  
                <div class="control-group<?php echo form_error('n_gol_ruang') ? ' error' : ''; ?> col-sm-8">
                    <?php echo form_label("NOMOR SK", 'Golongan Ruang', array('class' => 'control-label')); ?>
                    <div class='controls'>
                        <input id='SK_NOMOR' type='text' class="form-control" name='SK_NOMOR' maxlength='200' value="<?php echo set_value('SK_NOMOR', isset($detail_riwayat->SK_NOMOR) ? trim($detail_riwayat->SK_NOMOR) : ''); ?>" />
                        <span class='help-inline'><?php echo form_error('SK_NOMOR'); ?></span>
                    </div>
                </div>
                <div class="control-group col-sm-4">
                    <label for="inputNAMA" class="control-label">TANGGAL SK</label>
                    <div class="input-group date">
                    <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                    </div>
                        <input type='text' class="form-control pull-right datepicker" name='SK_TANGGAL'  value="<?php echo set_value('SK_TANGGAL', isset($detail_riwayat->SK_TANGGAL) ? $detail_riwayat->SK_TANGGAL : ''); ?>" />
                        <span class='help-inline'><?php echo form_error('SK_TANGGAL'); ?></span>
                    </div>
                </div>
                <div class="control-group col-sm-9">
                <label for="inputNAMA" class="control-label">Berkas</label>
                <div class='controls'>
                    <div id="form_upload">
                      <input id="berkas" name="berkas" class="file" type="file" data-preview-file-type="pdf">
                    </div>
                    
                </div>
            </div> 
                
            </div>
             
            </fieldset>
        </div>
  		<div class="box-footer">
            <hr>
            <input type='submit' name='save' id="btnsave" class='btn btn-primary' value="Simpan Data" /> 
        </div>
    <?php echo form_close(); ?>
</div>
<script src="<?php echo base_url(); ?>themes/admin/plugins/bootstrap-fileinput-master/themes/explorer/theme.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>themes/admin/plugins/bootstrap-fileinput-master/js/fileinput.js" type="text/javascript"></script>

<script src="<?php echo base_url(); ?>themes/admin/plugins/datepicker/bootstrap-datepicker.js"></script>
<script>
	 $(".select2").select2({width: '100%'});
</script>
<script>
    $("#berkas").fileinput({
        'showUpload': false
    });
    var form = $("#form-riwayat-tugas-add");
    //Date picker
    $('.datepicker').datepicker({
      autoclose: true,format: 'yyyy-mm-dd'
    }).on("input change", function (e) {
        var date = $(this).datepicker('getDate');
    });
</script>
<script>
	$("#btnsave").click(function(){
		submitdata();
		return false; 
	});	
	$("#frmA").submit(function(){
		submitdata();
		return false; 
	});	
     
	function submitdata(){
		var the_data = new FormData(document.getElementById("form-riwayat-tugas-add"));
		var json_url = "<?php echo base_url() ?>pegawai/riwayattugas_tambahan/save_mandiri";
		 $.ajax({    
		 	type: "POST",
			url: json_url,
			data: the_data,
            dataType: "json",
            processData: false, // tell jQuery not to process the data
            contentType: false, // tell jQuery not to set contentType
			success: function(data){ 
                if(data.success){
                    swal("Pemberitahuan!", data.msg, "success");
                    $("#modal-custom-global").trigger("sukses-tambah-riwayat-tt");
					$("#modal-global").modal("hide");
                    $("#modal-custom-global").modal("hide");
                    $grid_daftar.ajax.reload();
                }
                else {
                    $("#form-riwayat-tb-add .messages").empty().append(data.msg);
                }
			}});
		return false; 
	}
</script>