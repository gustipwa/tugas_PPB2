<?php defined('BASEPATH') || exit('No direct script access allowed');

class Riwayat_tugasbelajar_model extends BF_Model
{
    protected $table_name	= 'rwt_tugas_belajar';
	protected $key			= 'ID';
	protected $date_format	= 'datetime';

	protected $log_user 	= false;
	protected $set_created	= false;
	protected $set_modified = false;
	protected $soft_deletes	= false;


	// Customize the operations of the model without recreating the insert,
    // update, etc. methods by adding the method names to act as callbacks here.
	protected $before_insert 	= array();
	protected $after_insert 	= array();
	protected $before_update 	= array();
	protected $after_update 	= array();
	protected $before_find 	    = array();
	protected $after_find 		= array();
	protected $before_delete 	= array();
	protected $after_delete 	= array();

	// For performance reasons, you may require your model to NOT return the id
	// of the last inserted row as it is a bit of a slow method. This is
    // primarily helpful when running big loops over data.
	protected $return_insert_id = true;

	// The default type for returned row data.
	protected $return_type = 'object';

	// Items that are always removed from data prior to inserts or updates.
	protected $protected_attributes = array();

	// You may need to move certain rules (like required) into the
	// $insert_validation_rules array and out of the standard validation array.
	// That way it is only required during inserts, not updates which may only
	// be updating a portion of the data.
	protected $validation_rules 		= array(
		array(
			'field' => 'NIP',
			'label' => 'NIP',
			'rules' => 'max_length[32]|required',
		), 
	);
	protected $insert_validation_rules  = array();
	protected $skip_validation 			= true;

    /**
     * Constructor
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
	}
	public function first_row(){
		return $this->db->get($this->db->schema.".".$this->table_name)->first_row();
	}
    public function find_all($PNS_NIP ="")
	{
		
		if(empty($this->selects))
		{
			$this->select($this->table_name .'.*');
		}
		if($PNS_NIP!=""){
			$this->db->where('NIP',$PNS_NIP);
		}
		return parent::find_all();
	}
	
	public function getnotif_6bulan($unor_id='',$tanggal = ""){
		$tanggal_sekarang = date("Y-m-d");
		if($unor_id!=''){
			$this->db->where("(unitkerja.ID = '".$unor_id."' or unitkerja.ESELON_1 = '".$unor_id."' or unitkerja.ESELON_2 = '".$unor_id."' or unitkerja.ESELON_3 = '".$unor_id."' or unitkerja.ESELON_4 = '".$unor_id."')");
		}
		$this->db->select('pegawai.*');
		$this->db->where("AKHIR_BELAJAR <= '".$tanggal."'");
		$this->db->where("AKHIR_BELAJAR >= '".$tanggal_sekarang."'");
		$this->db->join("hris.pegawai ","pegawai.NIP_BARU = rwt_tugas_belajar.NIP", 'left');
		$this->db->join("hris.unitkerja ","pegawai.UNOR_ID=unitkerja.ID", 'left');
		
		return parent::count_all();
	}
	public function get_data_6bulan($unor_id='',$tanggal = ""){
		$tanggal_sekarang = date("Y-m-d");
		if($unor_id!=''){
			$this->db->where("(unitkerja.ID = '".$unor_id."' or unitkerja.ESELON_1 = '".$unor_id."' or unitkerja.ESELON_2 = '".$unor_id."' or unitkerja.ESELON_3 = '".$unor_id."' or unitkerja.ESELON_4 = '".$unor_id."')");
		}
		$this->db->select('pegawai.NIP_BARU,pegawai.NAMA,UNIVERSITAS,PNS_ID,NOMOR_SK,TANGGAL_SK,MULAI_BELAJAR,AKHIR_BELAJAR');
		$this->db->where("AKHIR_BELAJAR <= '".$tanggal."'");
		$this->db->where("AKHIR_BELAJAR >= '".$tanggal_sekarang."'");
		$this->db->join("hris.pegawai ","pegawai.NIP_BARU = rwt_tugas_belajar.NIP", 'left');
		$this->db->join("hris.unitkerja ","pegawai.UNOR_ID=unitkerja.ID", 'left');
		
		return parent::find_all();
	}
	public function find_all_admin()
	{
		
		if(empty($this->selects))
		{
			$this->select($this->table_name .'.*,pegawai.NAMA,pegawai.PNS_ID');
		}
		if($PNS_ID!=""){
			$this->db->where('pegawai.PNS_ID',$PNS_ID);
		}
		$this->db->order_by('ID',"DESC");
		$this->db->join("pegawai","rwt_tugas_belajar.NIP=pegawai.NIP_BARU", 'inner');
		$this->db->join("vw_unit_list as vw", "pegawai.\"UNOR_ID\"=vw.\"ID\" $where_clause ", 'left', false);
		return parent::find_all();
	}
	public function count_all_admin()
	{
		
		if(empty($this->selects))
		{
			$this->select($this->table_name .'.*,pegawai.NAMA,pegawai.PNS_ID');
		}
		if($PNS_ID!=""){
			$this->db->where('pegawai.PNS_ID',$PNS_ID);
		}
		$this->db->join("pegawai","rwt_tugas_belajar.NIP=pegawai.NIP_BARU", 'inner');
		$this->db->join("vw_unit_list as vw", "pegawai.\"UNOR_ID\"=vw.\"ID\" $where_clause ", 'left', false);
		return parent::count_all();
	}
}