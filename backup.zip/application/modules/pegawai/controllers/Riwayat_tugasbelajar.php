<?php defined('BASEPATH') || exit('No direct script access allowed');

/**
 * Kepegawaian controller
 */
class Riwayat_tugasbelajar extends Admin_Controller
{
    protected $permissionCreate = 'Riwayattb.Kepegawaian.Create';
    protected $permissionDelete = 'Riwayattb.Kepegawaian.Delete';
    protected $permissionEdit   = 'Riwayattb.Kepegawaian.Edit';
    protected $permissionView   = 'Riwayattb.Kepegawaian.View';
    protected $permissionUpdateMandiri   = 'Riwayattb.Kepegawaian.UpdateMandiri';
    protected $permissionVerifikasi   = 'Riwayattb.Kepegawaian.VerifikasiS';
    
    /**
     * Constructor
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('pegawai/riwayat_tugasbelajar_model');
        $this->load->model('pegawai/pegawai_model');
		$this->load->model('pegawai/update_mandiri_model');
    }
    public function ajax_list(){
        $this->load->library('convert');
 		$convert = new convert();
        $draw = $this->input->post('draw');
		$iSortCol = $this->input->post('iSortCol_1');
		$sSortCol = $this->input->post('sSortDir_1');
        $NIP_BARU = $this->input->post('NIP_BARU');
       
		$length= $this->input->post('length');
		$start= $this->input->post('start');

		$search = isset($_REQUEST['search']["value"]) ? $_REQUEST['search']["value"] : "";
		$this->riwayat_tugasbelajar_model->where("NIP",$NIP_BARU);
        if($search!=""){
            $this->riwayat_tugasbelajar_model->where('upper("NOMOR_SK") LIKE \''.strtoupper($search).'%\'');
        }
		$total= $this->riwayat_tugasbelajar_model->count_all();;
		$output=array();
		$output['draw']=$draw;

		
		$output['recordsTotal']= $output['recordsFiltered']=$total;
		$output['data']=array();
        
		$this->riwayat_tugasbelajar_model->where("NIP",$NIP_BARU); 
        if($search!=""){
			$this->riwayat_tugasbelajar_model->where('upper("NOMOR_SK") LIKE \''.strtoupper($search).'%\'');
		}
		$this->riwayat_tugasbelajar_model->limit($length,$start);
		
        $records=$this->riwayat_tugasbelajar_model->find_all();
            
		 
		$this->load->helper('dikbud');
		$nomor_urut=$start+1;
		if(isset($records) && is_array($records) && count($records)):
			foreach ($records as $record) {
                $STATUS_SATKER  = $record->STATUS_SATKER;
                $STATUS_BIRO    = $record->STATUS_BIRO;
                $msgverifikasi = "";
                if($STATUS_SATKER == "0")
                    $msgverifikasi = "<br><b class='text-red'>(Perlu Verifikasi)</b>";
                if($STATUS_BIRO == "0")
                    $msgverifikasi = "<br><b class='text-red'>(Perlu Verifikasi)</b>";
                elseif($STATUS_BIRO == "1")
                    $msgverifikasi = "<br><b class='text-blue'>(Sudah diverifikasi)</b>";
                $nomorpengajuan = "";
                if($record->ID_PENGAJUAN != "")
                    $nomorpengajuan = "<br>No Pengajuan :<i>".$record->ID_PENGAJUAN."</i>";
                $row = array();
                $row []  = $nomor_urut;
                $row []  = $record->NOMOR_SK."<br><i>TANGGAL : ".$convert->fmtDate($record->TANGGAL_SK,"dd-mm-yyyy")."</i>".$nomorpengajuan.$msgverifikasi;
                $row []  = $record->UNIVERSITAS;
                $row []  = $record->FAKULTAS."<BR><i>".$record->PROGRAM_STUDI."</i>";
                $row []  = $record->KATEGORI;
                $btn_actions = array();
                $btn_actions  [] = "<a href='".base_url()."pegawai/riwayat_tugasbelajar/detil/".$record->ID."' class='btn btn-sm btn-info show-modal-custom'><i class='glyphicon glyphicon-search'></i> </a>";
                if($record->BASE64_BERKAS != "")
                    $btn_actions  [] = "<a href='".base_url()."pegawai/riwayat_tugasbelajar/viewdoc/".$record->ID."' class='btn btn-sm btn-success show-modal-custom' tooltip='Lihat dokumen' title='Lihat dokumen'><i class='glyphicon glyphicon-eye-open'></i> </a>";
                if($this->auth->has_permission("Riwayattb.Kepegawaian.Edit")){
                    $btn_actions  [] = "<a href='".base_url()."pegawai/riwayat_tugasbelajar/edit/".$record->ID."' class='btn btn-sm btn-warning show-modal-custom'><i class='glyphicon glyphicon-edit'></i> </a>";
                }
                if($this->auth->has_permission("Riwayattb.Kepegawaian.Delete")){
                $btn_actions  [] = "<a kode='$record->ID' class='btn btn-sm btn-danger btn-hapus' data-toggle='tooltip' data-placement='top' data-original-title='Hapus data' title='Hapus data' tooltip='Hapus'><i class='glyphicon glyphicon-remove'></i> </a>";
                }
                $row[] = "<div class='btn-group'>".implode(" ",$btn_actions)."</div>";
                $output['data'][] = $row;
				$nomor_urut++;
			}
		endif;
		echo json_encode($output);
		die();
    }
    public function show($NIP_BARU = "",$record_id=''){
        if(empty($record_id)){
            $this->auth->restrict($this->permissionCreate);
            Template::set_view("kepegawaian/riwayat_tb_crud");
            Template::set('NIP_BARU', $NIP_BARU);
            Template::set('toolbar_title', "Tambah Riwayat Tugas Belajar");
            Template::render();
        }
        else {
    		$datadetil = $this->riwayat_tugasbelajar_model->find($record_id); 
            $this->auth->restrict($this->permissionEdit);
            Template::set_view("kepegawaian/riwayat_tb_crud");
           
            Template::set('detail_riwayat', $datadetil);    
            Template::set('NIP_BARU', $NIP_BARU);
            Template::set('toolbar_title', "Ubah Riwayat Tugas Belajar");

            Template::render();
        }
    }
    public function showmandiri($NIP_BARU = "",$record_id=''){
        if(empty($record_id)){
            $this->auth->restrict($this->permissionUpdateMandiri);
            Template::set_view("kepegawaian/riwayat_tb_crud_mandiri");
            Template::set('NIP_BARU', $NIP_BARU);
            Template::set('toolbar_title', "Tambah Riwayat Tugas Belajar");
            Template::render();
        }
        else {
            $datadetil = $this->riwayat_tugasbelajar_model->find($record_id); 
            $this->auth->restrict($this->permissionEdit);
            Template::set_view("kepegawaian/riwayat_tb_crud_mandiri");
           
            Template::set('detail_riwayat', $datadetil);    
            Template::set('NIP_BARU', $NIP_BARU);
            Template::set('toolbar_title', "Ubah Riwayat Tugas Belajar");

            Template::render();
        }
    }
    public function viewdoc($record_id=''){
        $data = $this->riwayat_tugasbelajar_model->find($record_id);
        $base64 = $data->BASE64_BERKAS;
        $output = $this->load->view('kepegawaian/viewdoc',array('data'=>$data,'base64'=>$base64),true);   
         
        echo $output;
    }
    public function add($NIP_BARU = ""){
        $this->show($NIP_BARU);
    }
    public function addmandiri($NIP_BARU = ""){
        $this->showmandiri($NIP_BARU);
    }
    public function edit($ID=''){
        $this->riwayat_tugasbelajar_model->where("ID",$ID);
        $tb_data = $this->riwayat_tugasbelajar_model->first_row();  

        Template::set_view("kepegawaian/riwayat_tb_crud");
        Template::set('detail_riwayat', $tb_data);    
        Template::set('NIP_BARU', $tb_data->NIP);
        Template::set('toolbar_title', "Ubah Riwayat Tugas Belajar"); 
        Template::render();
    }
    public function detil($ID=''){
        
        $this->riwayat_tugasbelajar_model->where("ID",$ID);
        $tb_data = $this->riwayat_tugasbelajar_model->first_row();  
        $this->pegawai_model->where("NIP_BARU",$tb_data->NIP);
        $pegawai_data = $this->pegawai_model->find_first_row();  
        Template::set_view("kepegawaian/riwayat_tb_view");
        Template::set('detail_riwayat', $tb_data);    
        Template::set('NIP_BARU', $pegawai_data->NIP_BARU);
        Template::set('toolbar_title', "Lihat Riwayat Tugas Belajar"); 
		Template::render();
    }
    public function save(){
        //Validate the data
        $this->auth->restrict($this->permissionCreate);
        $this->form_validation->set_rules($this->riwayat_tugasbelajar_model->get_validation_rules());
        $response = array(
            'success'=>false,
            'msg'=>'Unknown error'
        );
        if ($this->form_validation->run() === false) {
            $response['msg'] = "
            <div class='alert alert-block alert-error alert-danger fade in'>
                <a class='close' data-dismiss='alert'>&times;</a>
                <h4 class='alert-heading'>
                    Error
                </h4>
                ".validation_errors()."
            </div>
            ";
            echo json_encode($response);
            exit();
        }
		
		
        $data = $this->riwayat_tugasbelajar_model->prep_data($this->input->post());
        // upload berkas
        $nama_berkas = "";
        //die($this->settings_lib->item('site.pathuploadedberkas'));
        $this->load->helper('handle_upload');
        $status_kp = false;
        $direktori = trim($this->settings_lib->item('site.pathuploaded'));
        if (isset($_FILES['berkas']) && $_FILES['berkas']['name']) {
            $uploadData = handle_upload('berkas',$direktori);
            if (isset($uploadData['error']) && !empty($uploadData['error']))
             {
                $tipefile = $_FILES['berkas']['type'];
                log_activity($this->input->post('nip'), 'Gagal error: '.$uploadData['error'].$tipefile.$this->input->ip_address(), 'upload berkas');
             }else{
                $nama_berkas = $uploadData['data']['file_name'];

                $fileupload = $direktori.$nama_berkas;
                $base64data = "";
                if (file_exists($fileupload)) {
                    $base64data = chunk_split(base64_encode(file_get_contents($fileupload)));
                }
                if($base64data != ""){
                    $data["BASE64_BERKAS"]      = $base64data;    
                }
                $data["BERKAS"]      = $nama_berkas;    
             }
        }
        // end upload berkas
       	$this->pegawai_model->where("NIP_BARU",$this->input->post("NIP"));
        $pegawai_data = $this->pegawai_model->find_first_row();  
        
        if(empty($data["TANGGAL_SK"])){
            unset($data["TANGGAL_SK"]);
        }
        if(empty($data["MULAI_BELAJAR"])){
            unset($data["MULAI_BELAJAR"]);
        }
        if(empty($data["AKHIR_BELAJAR"])){
            unset($data["AKHIR_BELAJAR"]);
        }
        $id_data = $this->input->post("id");
        if(isset($id_data) && !empty($id_data)){
            // Update status pada update data mandiri untuk riwayat pendidikan berdasarkan ID
            $dataupdate = array();
            $data_update['STATUS']          = $data["STATUS_BIRO"];
            $data_update['VERIFIKASI_BY']   = $this->auth->user_id();
            $data_update['VERIFIKASI_TGL']  = date("Y-m-d");
            $this->update_mandiri_model->where("KOLOM","RIWAYAT_TB");
            $result = $this->update_mandiri_model->update_where("ID_TABEL",$id_data,$data_update);
            // end update histori update mandiri
            $this->riwayat_tugasbelajar_model->update($id_data,$data);
        }
        else $this->riwayat_tugasbelajar_model->insert($data);
        $msgtb = "";
        // Aktif Kembali
        if($this->input->post("STATUS_TB") == "1"){
            $datapegawai['KEDUDUKAN_HUKUM_ID'] = "01";
            $result = $this->pegawai_model->update($pegawai_data->ID, $datapegawai);
            if($result){
                $msgtb = "Status Pegawai menjadi aktif Kembali";
            }
        }
        // Aktif Tugas Belajar
        if($this->input->post("STATUS_TB") == "2"){
            $datapegawai['KEDUDUKAN_HUKUM_ID'] = "03";
            $result = $this->pegawai_model->update($pegawai_data->ID, $datapegawai);  
            if($result){
                $msgtb = "Status Pegawai menjadi tugas belajar";
            }          
        }
        $response ['success']= true;
        $response ['msg']= "Berhasil ".$msgtb;
        echo json_encode($response);    

    }
    public function savemandiri(){
        $this->auth->restrict($this->permissionUpdateMandiri);
        //Validate the data
        $this->form_validation->set_rules($this->riwayat_tugasbelajar_model->get_validation_rules());
        $response = array(
            'success'=>false,
            'msg'=>'Unknown error'
        );
        if ($this->form_validation->run() === false) {
            $response['msg'] = "
            <div class='alert alert-block alert-error alert-danger fade in'>
                <a class='close' data-dismiss='alert'>&times;</a>
                <h4 class='alert-heading'>
                    Error
                </h4>
                ".validation_errors()."
            </div>
            ";
            echo json_encode($response);
            exit();
        }
        
        
        $data = $this->riwayat_tugasbelajar_model->prep_data($this->input->post());
        // upload berkas
        $nama_berkas = "";
        //die($this->settings_lib->item('site.pathuploadedberkas'));
        $this->load->helper('handle_upload');
        $status_kp = false;
        $direktori = trim($this->settings_lib->item('site.pathuploaded'));
        if (isset($_FILES['berkas']) && $_FILES['berkas']['name']) {
            $uploadData = handle_upload('berkas',$direktori);
            if (isset($uploadData['error']) && !empty($uploadData['error']))
             {
                $tipefile = $_FILES['berkas']['type'];
                log_activity($this->input->post('nip'), 'Gagal error: '.$uploadData['error'].$tipefile.$this->input->ip_address(), 'upload berkas');
             }else{
                $nama_berkas = $uploadData['data']['file_name'];

                $fileupload = $direktori.$nama_berkas;
                $base64data = "";
                if (file_exists($fileupload)) {
                    $base64data = chunk_split(base64_encode(file_get_contents($fileupload)));
                }
                if($base64data != ""){
                    $data["BASE64_BERKAS"]      = $base64data;    
                }
                $data["BERKAS"]      = $nama_berkas;    
             }
        }
        // end upload berkas
        $this->pegawai_model->where("NIP_BARU",$this->input->post("NIP"));
        $pegawai_data = $this->pegawai_model->find_first_row();  
        
        if(empty($data["TANGGAL_SK"])){
            unset($data["TANGGAL_SK"]);
        }
        if(empty($data["MULAI_BELAJAR"])){
            unset($data["MULAI_BELAJAR"]);
        }
        if(empty($data["AKHIR_BELAJAR"])){
            unset($data["AKHIR_BELAJAR"]);
        }
        $id_data = $this->input->post("id");
        if(isset($id_data) && !empty($id_data)){
            $this->riwayat_tugasbelajar_model->update($id_data,$data);
        }
        else {
            $data["STATUS_SATKER"]  = 0;
            $data["STATUS_BIRO"]    = 0;
            $insert_id  = $this->riwayat_tugasbelajar_model->insert($data);
            $PNS_ID     = $this->input->post('PNS_ID');
            $NOMOR_SK   = $this->input->post('NOMOR_SK');
            if($ID_JABATAN != ""){
                $data_update = array();
                $data_update['PNS_ID']      = $PNS_ID;
                $data_update['KOLOM']       = "RIWAYAT_TB";
                $data_update['DARI']        = "-";
                $data_update['PERUBAHAN']   = "ID : ".$insert_id.", Nomor SK : ".$NOMOR_SK;
                $data_update['NAMA_KOLOM']  = "RIWAYAT TUGAS BELAJAR";
                $data_update['LEVEL_UPDATE']= 1; // LEVEL BIRO
                $data_update['UPDATE_TGL']  = date("Y-m-d");
                $data_update['ID_TABEL']    = $insert_id;
                $data_update['UPDATED_BY']  = $this->auth->user_id();
                $id_update = $this->update_mandiri_model->insert($data_update);
            }

            
        }
        $msgtb = "";
         
        $response ['success']= true;
        $response ['msg']= "Berhasil ".$msgtb;
        echo json_encode($response);    

    }
    public function delete($record_id = null){
        $this->auth->restrict($this->permissionDelete);
        if($record_id == null)
            $record_id = $this->input->post('kode');
		if ($this->riwayat_tugasbelajar_model->delete($record_id)) {
			 log_activity($this->auth->user_id(), 'delete data Riwayat Tugas Belajar : ' . $record_id . ' : ' . $this->input->ip_address(), 'pegawai');
			 Template::set_message("Sukses Hapus data", 'success');
			 echo "Sukses";
		}else{
			echo "Gagal";
		}

		exit();
    }
    public function index($NIP_BARU=''){
        Template::set_view("kepegawaian/tab_pane_tugasbelajar");
        Template::set('NIP_BARU', $NIP_BARU);
        Template::set('TAB_ID', uniqid("TAB_CONTOH"));
        Template::render();
    }
    public function daftar()
    {    
        Template::set_view("kepegawaian/daftar_tugasbelajar");
        Template::set('toolbar_title', "Diklat Teknis");
        Template::render();
    }
    public function daftar_ajax_list()
    {
        $this->load->library('convert');
        $convert = new convert();
        $draw = $this->input->post('draw');
        $iSortCol = $this->input->post('iSortCol_1');
        $sSortCol = $this->input->post('sSortDir_1');
        
        $length= $this->input->post('length');
        $start= $this->input->post('start');
        $this->db->start_cache();
        $advanced_search_filters  = $this->input->post("search[advanced_search_filters]");
        if($advanced_search_filters){
            $filters = array();
            foreach($advanced_search_filters as  $filter){
                $filters[$filter['name']] = $filter["value"];
            }
             
            if($filters['nama_key']){
                $this->riwayat_tugasbelajar_model->like('upper("NAMA")',strtoupper(trim($filters['nama_key'])),"BOTH"); 
            }
            if($filters['nip_key']){
                $this->riwayat_tugasbelajar_model->like('NIP',strtoupper(trim($filters['nip_key'])),"BOTH");  
            }
            if($filters['jenis_satker'] != ""){
                    $this->db->where('vw.JENIS_SATKER',$filters['jenis_satker']);   
            }
        }
        
        $this->db->stop_cache();
        
        $output=array();
        $output['draw']=$draw;
        $total= $this->riwayat_tugasbelajar_model->count_all_admin();;
        $output['recordsTotal']= $output['recordsFiltered']=$total;
        $output['data']=array();

        $this->riwayat_tugasbelajar_model->limit($length,$start);
        $records = $this->riwayat_tugasbelajar_model->find_all_admin();
        $this->db->flush_cache();
        $nomor_urut=$start+1;
        if(isset($records) && is_array($records) && count($records)):
            foreach ($records as $record) {
                $STATUS_SATKER  = $record->STATUS_SATKER;
                $STATUS_BIRO    = $record->STATUS_BIRO;
                $msgverifikasi = "";
                if($STATUS_SATKER == "0")
                    $msgverifikasi = "<br><b class='text-red'>(Perlu Verifikasi)</b>";
                if($STATUS_BIRO == "0")
                    $msgverifikasi = "<br><b class='text-red'>(Perlu Verifikasi)</b>";
                elseif($STATUS_BIRO == "1")
                    $msgverifikasi = "<br><b class='text-blue'>(Sudah diverifikasi)</b>";
                $row = array();
                $row []  = $nomor_urut;
                $row []  = $record->NIP;
                $row []  = $record->NOMOR_SK.$msgverifikasi;
                $row []  = $record->UNIVERSITAS."<br><i>".$record->PROGRAM_STUDI."</i>";
                $row []  = $record->AKHIR_BELAJAR;
                
                $btn_actions = array();
                if($record->BASE64_BERKAS != "")
                    $btn_actions  [] = "<a href='".base_url()."pegawai/riwayat_tugasbelajar/viewdoc/".$record->ID."' class='btn btn-sm btn-success show-modal-custom' tooltip='Lihat dokumen' title='Lihat dokumen'><i class='glyphicon glyphicon-eye-open'></i> </a>";
                if($this->auth->has_permission($this->permissionEdit)){
                    $btn_actions  [] = "<a href='".base_url()."pegawai/riwayat_tugasbelajar/edit/".$record->ID."' class='btn btn-sm btn-warning show-modal'><i class='glyphicon glyphicon-edit'></i> </a>";
                }
                if($this->auth->has_permission($this->permissionDelete)){
                $btn_actions  [] = "<a kode='$record->ID' class='btn btn-sm btn-danger btn-hapus-tb' data-toggle='tooltip' data-placement='top' data-original-title='Hapus data' title='Hapus data' tooltip='Hapus'><i class='glyphicon glyphicon-remove'></i> </a>";
                }
                $row[] = "<div class='btn-group'>".implode(" ",$btn_actions)."</div>";
                

                $output['data'][] = $row;
                $nomor_urut++;
            }
        endif;
        echo json_encode($output);
        die();
    }
}
