<link rel="stylesheet" href="<?php echo base_url(); ?>themes/admin/plugins/select2/select2.min.css">
<div class="callout callout-info">
   <h4>Bezzeting!</h4>
   <p>Silahkan cari Unitkerja untuk melihat bezzeting pegawai pada unit tersebut.</p>
 </div>
<div class="admin-box box box-primary">
	<div class="box-header">
	  
         <div class="control-group">
             <div class='controls'>
                 <select name="Unit_Kerja_ID" id="Unit_Kerja_ID" class="form-control select2" style="width:700px">
                        <?php 
                            if($selectedLokasiPegawai){
                                echo "<option selected value='".$selectedLokasiPegawai->ID."'>".$selectedLokasiPegawai->NAMA."</option>";
                            }
                        ?>
                    </select>
             </div>
         </div>
	</div>
	<div class="box-body" id="divcontent">
	
	</div>
</div>
<script>
	$("#Unit_Kerja_ID").change(function(){
		showdata();
	 }); 
	//alert('<?php echo site_url("admin/masters/unitkerja/ajaxkodeinternal");?>');
    $("#Unit_Kerja_ID").select2({
        placeholder: 'Cari Unit Kerja...',
        width: '100%',
        minimumInputLength: 3,
        allowClear: true,
        ajax: {
            url: '<?php echo site_url("pegawai/manage_unitkerja/ajaxkodeinternal");?>',
            dataType: 'json',
            data: function(params) {
                return {
                    term: params.term || '',
                    page: params.page || 1
                }
            },
            cache: true
        }
    });
    function showdata(){
    	 var ValUnit_Kerja_ID = $("#Unit_Kerja_ID").val();
		 var json_url = "<?php echo base_url() ?>admin/reports/bezzeting/viewdata?unitkerja="+ValUnit_Kerja_ID;
		 $.ajax({    type: "GET",
			url: json_url,
			data: "unitkerja="+ValUnit_Kerja_ID,
			success: function(data){ 
				$('#divcontent').html(data);
			}});
		 return false; 
	  return false;
    }
</script>