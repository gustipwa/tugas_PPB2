<?php defined('BASEPATH') || exit('No direct script access allowed');

class Izin_pegawai_model extends BF_Model
{
    protected $table_name	= 'izin';
	protected $key			= 'ID';
	protected $date_format	= 'datetime';

	protected $log_user 	= false;
	protected $set_created	= false;
	protected $set_modified = false;
	protected $soft_deletes	= false;


	// Customize the operations of the model without recreating the insert,
    // update, etc. methods by adding the method names to act as callbacks here.
	protected $before_insert 	= array();
	protected $after_insert 	= array();
	protected $before_update 	= array();
	protected $after_update 	= array();
	protected $before_find 	    = array();
	protected $after_find 		= array();
	protected $before_delete 	= array();
	protected $after_delete 	= array();

	// For performance reasons, you may require your model to NOT return the id
	// of the last inserted row as it is a bit of a slow method. This is
    // primarily helpful when running big loops over data.
	protected $return_insert_id = true;

	// The default type for returned row data.
	protected $return_type = 'object';

	// Items that are always removed from data prior to inserts or updates.
	protected $protected_attributes = array();

	// You may need to move certain rules (like required) into the
	// $insert_validation_rules array and out of the standard validation array.
	// That way it is only required during inserts, not updates which may only
	// be updating a portion of the data.
	protected $validation_rules 		= array(
		array(
			'field' => 'NIP_PNS',
			'label' => 'lang:izin_pegawai_field_NIP_PNS',
			'rules' => 'required|max_length[18]',
		),
		array(
			'field' => 'NAMA',
			'label' => 'lang:izin_pegawai_field_NAMA',
			'rules' => 'max_length[100]',
		),
		array(
			'field' => 'JABATAN',
			'label' => 'lang:izin_pegawai_field_JABATAN',
			'rules' => 'max_length[100]',
		),
		array(
			'field' => 'UNIT_KERJA',
			'label' => 'lang:izin_pegawai_field_UNIT_KERJA',
			'rules' => 'max_length[100]',
		),
		array(
			'field' => 'MASA_KERJA_TAHUN',
			'label' => 'lang:izin_pegawai_field_MASA_KERJA_TAHUN',
			'rules' => '',
		),
		array(
			'field' => 'MASA_KERJA_BULAN',
			'label' => 'lang:izin_pegawai_field_MASA_KERJA_BULAN',
			'rules' => '',
		),
		array(
			'field' => 'GAJI_POKOK',
			'label' => 'lang:izin_pegawai_field_GAJI_POKOK',
			'rules' => 'max_length[10]',
		),
		array(
			'field' => 'KODE_IZIN',
			'label' => 'lang:izin_pegawai_field_KODE_IZIN',
			'rules' => 'required|max_length[5]',
		),
		array(
			'field' => 'DARI_TANGGAL',
			'label' => 'lang:izin_pegawai_field_DARI_TANGGAL',
			'rules' => '',
		),
		array(
			'field' => 'SAMPAI_TANGGAL',
			'label' => 'lang:izin_pegawai_field_SAMPAI_TANGGAL',
			'rules' => '',
		),
		array(
			'field' => 'TAHUN',
			'label' => 'lang:izin_pegawai_field_TAHUN',
			'rules' => 'max_length[4]',
		),
		array(
			'field' => 'JUMLAH',
			'label' => 'lang:izin_pegawai_field_JUMLAH',
			'rules' => '',
		),
		array(
			'field' => 'SATUAN',
			'label' => 'lang:izin_pegawai_field_SATUAN',
			'rules' => 'max_length[10]',
		),
		array(
			'field' => 'KETERANGAN',
			'label' => 'lang:izin_pegawai_field_KETERANGAN',
			'rules' => 'max_length[255]',
		),
		array(
			'field' => 'ALAMAT_SELAMA_CUTI',
			'label' => 'lang:izin_pegawai_field_ALAMAT_SELAMA_CUTI',
			'rules' => 'max_length[255]',
		),
		array(
			'field' => 'TLP_SELAMA_CUTI',
			'label' => 'lang:izin_pegawai_field_TLP_SELAMA_CUTI',
			'rules' => 'max_length[20]',
		),
		array(
			'field' => 'TGL_DIBUAT',
			'label' => 'lang:izin_pegawai_field_TGL_DIBUAT',
			'rules' => '',
		),
		array(
			'field' => 'LAMPIRAN_FILE',
			'label' => 'lang:izin_pegawai_field_LAMPIRAN_FILE',
		),
		array(
			'field' => 'SISA_CUTI_TAHUN_N2',
			'label' => 'lang:izin_pegawai_field_SISA_CUTI_TAHUN_N2',
			'rules' => '',
		),
		array(
			'field' => 'SISA_CUTI_TAHUN_N1',
			'label' => 'lang:izin_pegawai_field_SISA_CUTI_TAHUN_N1',
			'rules' => '',
		),
		array(
			'field' => 'SISA_CUTI_TAHUN_N',
			'label' => 'lang:izin_pegawai_field_SISA_CUTI_TAHUN_N',
			'rules' => '',
		),
		array(
			'field' => 'ANAK_KE',
			'label' => 'lang:izin_pegawai_field_ANAK_KE',
			'rules' => 'max_length[1]',
		),
		 
		array(
			'field' => 'NIP_ATASAN',
			'label' => 'lang:izin_pegawai_field_NIP_ATASAN',
			'rules' => 'max_length[25]',
		),
		array(
			'field' => 'STATUS_ATASAN',
			'label' => 'lang:izin_pegawai_field_STATUS_ATASAN',
			'rules' => '',
		),
		array(
			'field' => 'CATATAN_ATASAN',
			'label' => 'lang:izin_pegawai_field_CATATAN_ATASAN',
			'rules' => 'max_length[255]',
		),
		array(
			'field' => 'NIP_PYBMC',
			'label' => 'lang:izin_pegawai_field_NIP_PYBMC',
			'rules' => 'max_length[25]',
		),
		array(
			'field' => 'STATUS_PYBMC',
			'label' => 'lang:izin_pegawai_field_STATUS_PYBMC',
			'rules' => '',
		),
		array(
			'field' => 'CATATAN_PYBMC',
			'label' => 'lang:izin_pegawai_field_CATATAN_PYBMC',
			'rules' => 'max_length[255]',
		),
	);
	protected $insert_validation_rules  = array();
	protected $skip_validation 			= false;

    /**
     * Constructor
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }
    public function find_all()
	{
		
		if(empty($this->selects))
		{
			$this->select($this->table_name .'.ID,
				KODE_IZIN,
				NIP_PNS,pegawai.NAMA,NAMA_IZIN,TAHUN,
				DARI_TANGGAL,SAMPAI_TANGGAL,
				STATUS_ATASAN,STATUS_PYBMC,
				NAMA_ATASAN,NAMA_PYBMC,
				CATATAN_ATASAN,CATATAN_PYBMC,
				LAMPIRAN_FILE,
				JUMLAH,SATUAN,
				izin.KETERANGAN,
				ALASAN_CUTI,TGL_DIBUAT
				SELAMA_JAM,SELAMA_MENIT,
				STATUS_PENGAJUAN,PHOTO');
		}
		$this->db->join('pegawai', 'izin.NIP_PNS = pegawai.NIP_BARU', 'left');
		$this->db->join('jenis_izin', 'izin.KODE_IZIN = jenis_izin.ID', 'left');
		return parent::find_all();
	}
	public function count_all()
	{
		 
		if(empty($this->selects))
		{
			$this->select($this->table_name .'.ID,
				KODE_IZIN,
				NIP_PNS,pegawai.NAMA,NAMA_IZIN,TAHUN,
				DARI_TANGGAL,SAMPAI_TANGGAL,
				STATUS_ATASAN,STATUS_PYBMC,
				NAMA_ATASAN,NAMA_PYBMC,
				CATATAN_ATASAN,CATATAN_PYBMC,
				LAMPIRAN_FILE,
				JUMLAH,SATUAN,
				izin.KETERANGAN,
				ALASAN_CUTI,TGL_DIBUAT
				SELAMA_JAM,SELAMA_MENIT,
				STATUS_PENGAJUAN,PHOTO');
		}
		$this->db->join('pegawai', 'izin.NIP_PNS = pegawai.NIP_BARU', 'left');
		$this->db->join('jenis_izin', 'izin.KODE_IZIN = jenis_izin.ID', 'left');
		return parent::count_all();
	}
	public function find_all_unit($satker_id = "")
	{
		$where_clause = "";
		if ($satker_id) {
			if (is_array($satker_id) && sizeof($satker_id) > 0) {
				$where_clause = 'AND ( 1=2 ';
				foreach ($satker_id as $u_id) {
					$where_clause .= ' OR vw."ESELON_1" = \'' . $u_id . '\' OR vw."ESELON_2" = \'' . $u_id . '\' OR vw."ESELON_3" = \'' . $u_id . '\' OR vw."ESELON_4" = \'' . $u_id . '\' ';
				}
				$where_clause .= ')';
			} else $where_clause = 'AND (vw."ESELON_1" = \'' . $satker_id . '\' OR vw."ESELON_2" = \'' . $satker_id . '\' OR vw."ESELON_3" = \'' . $satker_id . '\' OR vw."ESELON_4" = \'' . $satker_id . '\')';
		}
		
		if(empty($this->selects))
		{
			$this->select($this->table_name .'.ID,
				KODE_IZIN,
				NIP_PNS,pegawai.NAMA,NAMA_IZIN,TAHUN,
				DARI_TANGGAL,SAMPAI_TANGGAL,
				STATUS_ATASAN,STATUS_PYBMC,
				NAMA_ATASAN,NAMA_PYBMC,
				CATATAN_ATASAN,CATATAN_PYBMC,
				LAMPIRAN_FILE,
				JUMLAH,SATUAN,
				izin.KETERANGAN,
				ALASAN_CUTI,TGL_DIBUAT
				SELAMA_JAM,SELAMA_MENIT,
				STATUS_PENGAJUAN,PHOTO');
		}
		$this->db->where("(NIP_PNS != '') " . $where_clause);
		$this->db->join('pegawai', 'izin.NIP_PNS = pegawai.NIP_BARU', 'left');
		$this->db->join("vw_unit_list as vw", "pegawai.\"UNOR_ID\"=vw.\"ID\" $where_clause ", 'left', false);
		$this->db->join('jenis_izin', 'izin.KODE_IZIN = jenis_izin.ID', 'left');
		return parent::find_all();
	}
	public function count_all_unit($satker_id = "")
	{
		$where_clause = "";
		if ($satker_id) {
			if (is_array($satker_id) && sizeof($satker_id) > 0) {
				$where_clause = 'AND ( 1=2 ';
				foreach ($satker_id as $u_id) {
					$where_clause .= ' OR vw."ESELON_1" = \'' . $u_id . '\' OR vw."ESELON_2" = \'' . $u_id . '\' OR vw."ESELON_3" = \'' . $u_id . '\' OR vw."ESELON_4" = \'' . $u_id . '\' ';
				}
				$where_clause .= ')';
			} else $where_clause = 'AND (vw."ESELON_1" = \'' . $satker_id . '\' OR vw."ESELON_2" = \'' . $satker_id . '\' OR vw."ESELON_3" = \'' . $satker_id . '\' OR vw."ESELON_4" = \'' . $satker_id . '\')';
		}
		
		
		if(empty($this->selects))
		{
			$this->select($this->table_name .'.ID,
				KODE_IZIN,
				NIP_PNS,pegawai.NAMA,NAMA_IZIN,TAHUN,
				DARI_TANGGAL,SAMPAI_TANGGAL,
				STATUS_ATASAN,STATUS_PYBMC,
				NAMA_ATASAN,NAMA_PYBMC,
				CATATAN_ATASAN,CATATAN_PYBMC,
				LAMPIRAN_FILE,
				JUMLAH,SATUAN,
				izin.KETERANGAN,
				ALASAN_CUTI,TGL_DIBUAT
				SELAMA_JAM,SELAMA_MENIT,
				STATUS_PENGAJUAN,PHOTO');
		}
		$this->db->where("(NIP_PNS != '') " . $where_clause);
		$this->db->join('pegawai', 'izin.NIP_PNS = pegawai.NIP_BARU', 'left');
		$this->db->join("vw_unit_list as vw", "pegawai.\"UNOR_ID\"=vw.\"ID\" $where_clause ", 'left', false);
		$this->db->join('jenis_izin', 'izin.KODE_IZIN = jenis_izin.ID', 'left');
		return parent::count_all();
	}
	public function find_all_pegawai($nip = "")
	{
		if(empty($this->selects))
		{
			$this->select($this->table_name .'.ID,
				KODE_IZIN,
				NIP_PNS,NAMA,NAMA_IZIN,TAHUN,
				DARI_TANGGAL,SAMPAI_TANGGAL,
				STATUS_ATASAN,STATUS_PYBMC,
				NAMA_ATASAN,NAMA_PYBMC,
				CATATAN_ATASAN,CATATAN_PYBMC,
				LAMPIRAN_FILE,
				JUMLAH,SATUAN,
				izin.KETERANGAN,
				ALASAN_CUTI,
				TGL_DIBUAT,
				SELAMA_JAM,
				SELAMA_MENIT,
				STATUS_PENGAJUAN');
		}
		$this->db->where("NIP_PNS",$nip);
		$this->db->join('jenis_izin', 'izin.KODE_IZIN = jenis_izin.ID', 'left');
		return parent::find_all();
	}
	public function count_all_pegawai($nip = "")
	{
		
		if(empty($this->selects))
		{
			$this->select($this->table_name .'.ID,
				KODE_IZIN,
				NIP_PNS,NAMA,NAMA_IZIN,TAHUN,
				DARI_TANGGAL,SAMPAI_TANGGAL,
				STATUS_ATASAN,STATUS_PYBMC,
				NAMA_ATASAN,NAMA_PYBMC,
				CATATAN_ATASAN,CATATAN_PYBMC,
				LAMPIRAN_FILE,
				JUMLAH,SATUAN,
				izin.KETERANGAN');
		}
		$this->db->where("NIP_PNS",$nip);
		return parent::count_all();
	}
	public function find_all_satker($unit_kerja = "")
	{
		
		if(empty($this->selects))
		{
			$this->select($this->table_name .'.ID,
				KODE_IZIN,
				NIP_PNS,NAMA,NAMA_IZIN,TAHUN,
				DARI_TANGGAL,SAMPAI_TANGGAL,
				STATUS_ATASAN,STATUS_PYBMC,
				NAMA_ATASAN,NAMA_PYBMC,
				CATATAN_ATASAN,CATATAN_PYBMC,
				LAMPIRAN_FILE,
				JUMLAH,SATUAN,
				izin.KETERANGAN,
				STATUS_PENGAJUAN
				');
		}
		$this->db->where("UNIT_KERJA",$unit_kerja);
		$this->db->join('jenis_izin', 'izin.KODE_IZIN = jenis_izin.ID', 'left');
		return parent::find_all();
	}
	public function count_all_satker($unit_kerja = "")
	{
		
		if(empty($this->selects))
		{
			$this->select($this->table_name .'.ID,
				KODE_IZIN,
				NIP_PNS,NAMA,NAMA_IZIN,TAHUN,
				DARI_TANGGAL,SAMPAI_TANGGAL,
				STATUS_ATASAN,STATUS_PYBMC,
				NAMA_ATASAN,NAMA_PYBMC,
				CATATAN_ATASAN,CATATAN_PYBMC,
				LAMPIRAN_FILE,
				JUMLAH,SATUAN,
				izin.KETERANGAN');
		}
		$this->db->where("UNIT_KERJA",$unit_kerja);
		return parent::count_all();
	}
	public function find_all_atasan($nip = "")
	{
		
		if(empty($this->selects))
		{
			$this->select($this->table_name .'.ID,
				izin_verifikasi.ID AS "ID_VERIFIKASI",
				KODE_IZIN,
				NIP_PNS,NAMA,NAMA_IZIN,TAHUN,
				DARI_TANGGAL,SAMPAI_TANGGAL,
				STATUS_ATASAN,STATUS_PYBMC,
				NAMA_ATASAN,NAMA_PYBMC,
				CATATAN_ATASAN,CATATAN_PYBMC,
				LAMPIRAN_FILE,
				JUMLAH,SATUAN,
				izin.KETERANGAN,
				STATUS_PENGAJUAN,
				STATUS_VERIFIKASI
				');
		}
		$this->db->where("izin_verifikasi.NIP_ATASAN",$nip);
		$this->db->where("izin_verifikasi.STATUS_VERIFIKASI","1");
		$this->db->join('jenis_izin', 'izin.KODE_IZIN = jenis_izin.ID', 'left');
		$this->db->join('izin_verifikasi', 'izin_verifikasi.ID_PENGAJUAN = izin.ID', 'left');
		return parent::find_all();
	}
	public function count_all_atasan($nip = "")
	{
		
		if(empty($this->selects))
		{
			$this->select($this->table_name .'.ID,
				KODE_IZIN,
				NIP_PNS,NAMA,NAMA_IZIN,TAHUN,
				DARI_TANGGAL,SAMPAI_TANGGAL,
				STATUS_ATASAN,STATUS_PYBMC,
				NAMA_ATASAN,NAMA_PYBMC,
				CATATAN_ATASAN,CATATAN_PYBMC,
				LAMPIRAN_FILE,
				JUMLAH,SATUAN,
				izin.KETERANGAN');
		}
		$this->db->where("izin_verifikasi.NIP_ATASAN",$nip);
		$this->db->where("izin_verifikasi.STATUS_VERIFIKASI","1");
		$this->db->join('jenis_izin', 'izin.KODE_IZIN = jenis_izin.ID', 'left');
		$this->db->join('izin_verifikasi', 'izin_verifikasi.ID_PENGAJUAN = izin.ID', 'left');
		
		return parent::count_all();
	}
	public function find_all_ppk($nip = "")
	{
		
		if(empty($this->selects))
		{
			$this->select($this->table_name .'.ID,
				KODE_IZIN,
				NIP_PNS,NAMA,NAMA_IZIN,TAHUN,
				DARI_TANGGAL,SAMPAI_TANGGAL,
				STATUS_ATASAN,STATUS_PYBMC,
				NAMA_ATASAN,NAMA_PYBMC,
				CATATAN_ATASAN,CATATAN_PYBMC,
				LAMPIRAN_FILE,
				JUMLAH,SATUAN,
				izin.KETERANGAN,
				STATUS_PENGAJUAN');
		}
		$this->db->where("NIP_PYBMC",$nip);
		$this->db->join('jenis_izin', 'izin.KODE_IZIN = jenis_izin.ID', 'left');
		return parent::find_all();
	}
	public function count_all_ppk($nip = "")
	{
		
		if(empty($this->selects))
		{
			$this->select($this->table_name .'.ID,
				KODE_IZIN,
				NIP_PNS,NAMA,NAMA_IZIN,TAHUN,
				DARI_TANGGAL,SAMPAI_TANGGAL,
				STATUS_ATASAN,STATUS_PYBMC,
				NAMA_ATASAN,NAMA_PYBMC,
				CATATAN_ATASAN,CATATAN_PYBMC,
				LAMPIRAN_FILE,
				JUMLAH,SATUAN,
				izin.KETERANGAN');
		}
		$this->db->where("NIP_PYBMC",$nip);
		return parent::count_all();
	}
	public function grupby_jenis($nip = '')
	{
		 
		if (empty($this->selects)) {
			$this->select('KODE_IZIN,NAMA_IZIN,count(*) as jumlah');
		}
		$this->db->group_by('KODE_IZIN');
		$this->db->group_by('NAMA_IZIN');
		$this->db->where("NIP_PNS",$nip);
		$this->db->join('jenis_izin', 'izin.KODE_IZIN = jenis_izin.ID', 'left');
		return parent::find_all();
	}
	public function sum_hari_grupby_jenis($nip = '')
	{
		 
		if (empty($this->selects)) {
			$this->select('KODE_IZIN,NAMA_IZIN,sum("JUMLAH") as jumlah');
		}
		$this->db->group_by('KODE_IZIN');
		$this->db->group_by('NAMA_IZIN');
		$this->db->where("NIP_PNS",$nip);
		$this->db->join('jenis_izin', 'izin.KODE_IZIN = jenis_izin.ID', 'left');
		return parent::find_all();
	}
	public function grupby_status($nip = '')
	{
		 
		if (empty($this->selects)) {
			$this->select('STATUS_PENGAJUAN,count(*) as jumlah');
		}
		$this->db->group_by('STATUS_PENGAJUAN');
		if($nip != ""){
			$this->db->where("NIP_PNS",$nip);
		}
		return parent::find_all();
	}
}