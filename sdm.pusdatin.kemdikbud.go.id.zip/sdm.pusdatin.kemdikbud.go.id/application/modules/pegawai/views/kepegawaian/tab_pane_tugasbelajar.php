
<style>
	.dt-center {
		text-align:center;
	}
</style>
<!--tab-pane-->
<div class="tab-pane" id="<?php echo $TAB_ID;?>">
    <div class=" panel-body">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-21 col-xs-12">
            	<div class="mail-tools tooltip-demo m-t-md pull-right">
            		<?php if ($this->auth->has_permission('Riwayattb.Kepegawaian.UpdateMandiri')) : ?>
			            <a type="button" class="show-modal-custom btn btn-sm btn-success  " href="<?php echo base_url(); ?>pegawai/riwayat_tugasbelajar/addmandiri/<?php echo $NIP_BARU ?>" tooltip="Tambah Riwayat Tugas Belajar (Mandiri)" title="Tambah Riwayat Tugas Belajar">
							<i class="fa fa-plus"></i> Tambah Mandiri
			            </a>
		            <?php endif; ?>
		            <?php if ($this->auth->has_permission('Riwayattb.Kepegawaian.Create')) : ?>
			            <a type="button" class="show-modal-custom btn btn-sm btn-warning margin" href="<?php echo base_url(); ?>pegawai/riwayat_tugasbelajar/add/<?php echo $NIP_BARU ?>" tooltip="Tambah Riwayat Tugas Belajar" title="Tambah Riwayat Tugas Belajar">
							<i class="fa fa-plus"></i> Tambah
			            </a>
		            <?php endif; ?>
		            
	        	</div>
	            <table class="table table-datatable">
		            <thead>
		                <tr>
		                    <th width='20px' >No</th>
		                    <th width='40px' >NOMOR/ TANGGAL SK</th>
		                    <th width='70px' >UNIVERSITAS</th>
							<th>FAKULTAS <br> PROGRAM STUDI</th>
							<th width='40px' >STAT</th>
		                    <th width='130px' align="center">AKSI</th>
		                </tr>
		            </thead>
		            <tfoot>
		                <tr>
		                        
		                </tr>
		            </tfoot>
		            <tbody>
		               
		            </tbody>
		        </table>  
	        </div>
        </div>
    </div>
</div>
<!--tab-pane-->


<script type="text/javascript">

	(function($){
		var $container = $("#<?php echo $TAB_ID;?>");
		var grid_daftar = $(".table-datatable",$container).DataTable({
				ordering: false,
				processing: true,
				"bFilter": false,
				"bLengthChange": false,
				serverSide: true,
				"columnDefs": [
					//{"className": "dt-center", "targets": "_all"}
					{"className": "dt-center", "targets": [0,2,5]}
				],
				ajax: {
					url: "<?php echo base_url() ?>pegawai/riwayat_tugasbelajar/ajax_list",
					type:'POST',
					data : {
						NIP_BARU:'<?php echo $NIP_BARU;?>'
					}
				}
		});
		$container.on('click','.show-modal-custom',function(event){
			showModalX.call(this,'sukses-tambah-riwayat-tb',function(){
				grid_daftar.ajax.reload();
			},this);
			event.preventDefault();
		});
		$container.on('click','.show-modal',showModalX);

		$container.on('click','.btn-hapus',function(event){
			event.preventDefault();
			var kode =$(this).attr("kode");
				swal({
					title: "Anda Yakin?",
					text: "Hapus data Riwayat Tugas Belajar!",
					type: "warning",
					showCancelButton: true,
					confirmButtonClass: 'btn-danger',
					confirmButtonText: 'Ya, Hapus!',
					cancelButtonText: "Tidak, Batalkan!",
					closeOnConfirm: false,
					closeOnCancel: false
				},
				function (isConfirm) {
					if (isConfirm) {
						var post_data = "kode="+kode;
						$.ajax({
								url: "<?php echo base_url() ?>pegawai/riwayat_tugasbelajar/delete/"+kode,
								dataType: "html",
								timeout:180000,
								success: function (result) {
									swal("Data berhasil di hapus!", result, "success");
									grid_daftar.ajax.reload();
							},
							error : function(error) {
								alert(error);
							} 
						});        
						
					} else {
						swal("Batal", "", "error");
					}
				});
		});
				
	})(jQuery);
</script>
