<link rel="stylesheet" href="<?php echo base_url(); ?>themes/admin/plugins/daterangepicker/daterangepicker.css">
<!-- bootstrap datepicker -->
<link rel="stylesheet" href="<?php echo base_url(); ?>themes/admin/plugins/datepicker/datepicker3.css">
<?php
	$this->load->library('convert');
 	$convert = new convert();
?>
<div class="tab-pane active" id="<?php echo $TAB_ID;?>">
    <div class=" panel-body">
	<form role="form" action="#" id="frmprofile">
	<input id='ID' type='hidden' class="form-control" name='ID' maxlength='25' value="<?php echo set_value('ID', isset($pegawai->ID) ? $pegawai->ID : ''); ?>" />
	<fieldset>
            <legend> Data Pribadi</legend>

              
            <!-- /.box-header -->
            <div class="box-body">
                <div class="form-group col-sm-12">
                 <div class="row">
                     <div class="col-sm-4">
                         NIK
                     </div>
                     <div class="col-sm-6">
                             <b><?php echo isset($pegawai->NIK) ? $pegawai->NIK : ''; ?></b>
                     </div>
                 </div>
             </div>
			  <div class="form-group col-sm-12">
				  <div class="row">
					  <div class="col-sm-4">
						  Tempat/Tanggal Lahir
					  </div>
					  <div class="col-sm-6">
						  <b><?php echo isset($selectedTempatLahirPegawai->NAMA) ? $selectedTempatLahirPegawai->NAMA : ""; ?></b>/
						  <b><?php echo isset($pegawai->TGL_LAHIR) ? $convert->fmtDate($pegawai->TGL_LAHIR,"dd month yyyy") : 'TGL_LAHIR'; ?></b>
					  </div>
				  </div>
			  </div>

			 <div class="form-group col-sm-12">
				 <div class="row">
					 <div class="col-sm-4">
						 EMAIL
					 </div>
					 <div class="col-sm-6">
							 <b><?php echo isset($pegawai->EMAIL) ? $pegawai->EMAIL : ''; ?></b>
					 </div>
				 </div>
			 </div>
			 <div class="form-group col-sm-12">
				 <div class="row">
					 <div class="col-sm-4">
						 ALAMAT
					 </div>
					 <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
							 <b><?php echo isset($pegawai->ALAMAT) ? $pegawai->ALAMAT : ''; ?></b>
					 </div>
				 </div>
			 </div>
			 <div class="form-group col-sm-12">
				 <div class="row">
					 <div class="col-sm-4">
						 NO HP
					 </div>
					 <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
							 <b><?php echo isset($pegawai->NOMOR_HP) ? $pegawai->NOMOR_HP : ''; ?></b>
					 </div>
				 </div>
			 </div>
			  
			 <div class="form-group col-sm-6">
				 <div class="row">
					 <div class="col-sm-8">
						 Status Pegawai
					 </div>
					 <div class="col-sm-4">
							 PPNPN
					 </div>
				 </div>
			 </div>
			 <div class="form-group col-sm-6">
				 <div class="row">
					 <div class="col-sm-4">
						 TMT
					 </div>
					 <div class="col-sm-4">
							 <b><?php echo isset($pegawai->TGL_SK_CPNS) ? $convert->fmtDate($pegawai->TGL_SK_CPNS,"dd month yyyy"): ''; ?></b>
					 </div>
				 </div>
			 </div>
			 <div class="form-group col-sm-12">
				 <div class="row">
					 <div class="col-sm-4">
						 Pendidikan Terakhir/ Tahun Lulus
					 </div>
					 <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
							 <b><?php echo isset($pegawai->PENDIDIKAN) ? $pegawai->PENDIDIKAN : ''; ?>/<?php echo isset($pegawai->TAHUN_LULUS) ? $pegawai->TAHUN_LULUS : ''; ?></b>
					 </div>
				 </div>
			 </div>
              <!-- /.table-responsive -->
             
            <!-- /.box-body -->
            
            <!-- /.box-footer -->
          </div>
    </fieldset>
	<fieldset>
            <legend> Posisi & Jabatan</legend>
 
	  <!-- /.box-header -->
	   
        <div class="form-group col-sm-12">
            <div class="row">
                <div class="col-sm-3">
                    Jabatan
                </div>
                <div class="col-sm-6">
                    <b><?php echo isset($pegawai->JABATAN_PPNPN) ? $pegawai->JABATAN_PPNPN  : ""; ?></b>
                </div>
            </div>
        </div>
         
         
         
        <div class="form-group col-sm-12">
            <div class="row">
                <div class="col-sm-3">
                     
                </div>
                <div class="col-sm-9">
                  
                </div>
            </div>
        </div>
          
	
	  </fieldset> 
	  <!-- /.box-header -->
      <fieldset>
        <legend>Data Lainnya</legend>

			   <div class="control-group<?php echo form_error('JENIS_KAWIN_ID') ? ' error' : ''; ?> col-sm-12">
				   <?php echo form_label("Status Kawin", 'JENIS_KAWIN_ID', array('class' => 'control-label')); ?>
				   <div class='controls'>
					   <select name="JENIS_KAWIN_ID" id="JENIS_KAWIN_ID" class="form-control select2">
						   <option value="">-- Silahkan Pilih --</option>
						   <?php if (isset($jenis_kawins) && is_array($jenis_kawins) && count($jenis_kawins)):?>
						   <?php foreach($jenis_kawins as $record):?>
							   <option value="<?php echo $record->ID?>" <?php if(isset($pegawai->JENIS_KAWIN_ID))  echo  ($pegawai->JENIS_KAWIN_ID==$record->ID) ? "selected" : ""; ?>><?php echo $record->NAMA; ?></option>
							   <?php endforeach;?>
						   <?php endif;?>
					   </select>
					   <span class='help-inline'><?php echo form_error('JENIS_KAWIN_ID'); ?></span>
				   </div>
			   </div>
			   <div class="control-group<?php echo form_error('NO_SURAT_DOKTER') ? ' error' : ''; ?> col-sm-6">
				   <?php echo form_label("NO SURAT KETERANGAN SEHAT DOKTER", 'NO_SURAT_DOKTER', array('class' => 'control-label')); ?>
				   <div class='controls'>
					   <input id='NO_SURAT_DOKTER' type='text' class="form-control" name='NO_SURAT_DOKTER' maxlength='25' value="<?php echo set_value('NO_SURAT_DOKTER', isset($pegawai->NO_SURAT_DOKTER) ? $pegawai->NO_SURAT_DOKTER : ''); ?>" />
					   <span class='help-inline'><?php echo form_error('NO_SURAT_DOKTER'); ?></span>
				   </div>
			   </div>
			   <div class="control-group col-sm-6">
				   <label for="inputNAMA" class="control-label">TANGGAL</label>
				   <div class="input-group date">
					 <div class="input-group-addon">
					   <i class="fa fa-calendar"></i>
					 </div>
					   <input id='TGL_SURAT_DOKTER' type='text' class="form-control pull-right datepicker" name='TGL_SURAT_DOKTER' maxlength='25' value="<?php echo set_value('TGL_SURAT_DOKTER', isset($pegawai->TGL_SURAT_DOKTER) ? $pegawai->TGL_SURAT_DOKTER : ''); ?>" />
					   <span class='help-inline'><?php echo form_error('TGL_SURAT_DOKTER'); ?></span>
				   </div>
			   </div> 
			   <div class="control-group<?php echo form_error('NO_BEBAS_NARKOBA') ? ' error' : ''; ?> col-sm-6">
				   <?php echo form_label("NO SURAT BEBAS NARKOBA", 'NO_BEBAS_NARKOBA', array('class' => 'control-label')); ?>
				   <div class='controls'>
					   <input id='NO_BEBAS_NARKOBA' type='text' class="form-control" name='NO_BEBAS_NARKOBA' maxlength='25' value="<?php echo set_value('NO_BEBAS_NARKOBA', isset($pegawai->NO_BEBAS_NARKOBA) ? $pegawai->NO_BEBAS_NARKOBA : ''); ?>" />
					   <span class='help-inline'><?php echo form_error('NO_BEBAS_NARKOBA'); ?></span>
				   </div>
			   </div>
			   <div class="control-group col-sm-6">
				   <label for="inputNAMA" class="control-label">TANGGAL</label>
				   <div class="input-group date">
					 <div class="input-group-addon">
					   <i class="fa fa-calendar"></i>
					 </div>
					   <input id='TGL_BEBAS_NARKOBA' type='text' class="form-control pull-right datepicker" name='TGL_BEBAS_NARKOBA' maxlength='25' value="<?php echo set_value('TGL_BEBAS_NARKOBA', isset($pegawai->TGL_BEBAS_NARKOBA) ? $pegawai->TGL_BEBAS_NARKOBA : ''); ?>" />
					   <span class='help-inline'><?php echo form_error('TGL_BEBAS_NARKOBA'); ?></span>
				   </div>
			   </div> 
			   <div class="control-group<?php echo form_error('NO_CATATAN_POLISI') ? ' error' : ''; ?> col-sm-6">
				   <?php echo form_label("NO CATATAN KEPOLISIAN", 'NO_CATATAN_POLISI', array('class' => 'control-label')); ?>
				   <div class='controls'>
					   <input id='NO_CATATAN_POLISI' type='text' class="form-control" name='NO_CATATAN_POLISI' maxlength='25' value="<?php echo set_value('NO_CATATAN_POLISI', isset($pegawai->NO_CATATAN_POLISI) ? $pegawai->NO_CATATAN_POLISI : ''); ?>" />
					   <span class='help-inline'><?php echo form_error('NO_CATATAN_POLISI'); ?></span>
				   </div>
			   </div>
			   <div class="control-group col-sm-6">
				   <label for="inputNAMA" class="control-label">TANGGAL</label>
				   <div class="input-group date">
					 <div class="input-group-addon">
					   <i class="fa fa-calendar"></i>
					 </div>
					   <input id='TGL_CATATAN_POLISI' type='text' class="form-control pull-right datepicker" name='TGL_CATATAN_POLISI' maxlength='25' value="<?php echo set_value('TGL_CATATAN_POLISI', isset($pegawai->TGL_CATATAN_POLISI) ? $pegawai->TGL_CATATAN_POLISI : ''); ?>" />
					   <span class='help-inline'><?php echo form_error('TGL_CATATAN_POLISI'); ?></span>
				   </div>
			   </div> 
			   <div class="control-group<?php echo form_error('AKTE_KELAHIRAN') ? ' error' : ''; ?> col-sm-12">
				   <?php echo form_label("AKTE KELAHIRAN", 'AKTE_KELAHIRAN', array('class' => 'control-label')); ?>
				   <div class='controls'>
					   <input id='AKTE_KELAHIRAN' type='text' class="form-control" name='AKTE_KELAHIRAN' maxlength='25' value="<?php echo set_value('AKTE_KELAHIRAN', isset($pegawai->AKTE_KELAHIRAN) ? $pegawai->AKTE_KELAHIRAN : ''); ?>" />
					   <span class='help-inline'><?php echo form_error('AKTE_KELAHIRAN'); ?></span>
				   </div>
			   </div>
			   
				<div class="control-group<?php echo form_error('BPJS') ? ' error' : ''; ?> col-sm-6">
				   <?php echo form_label(lang('pegawai_field_BPJS'), 'BPJS', array('class' => 'control-label')); ?>
				   <div class='controls'>
					   <input id='BPJS' type='text' class="form-control" name='BPJS' maxlength='25' value="<?php echo set_value('BPJS', isset($pegawai->BPJS) ? $pegawai->BPJS : ''); ?>" />
					   <span class='help-inline'><?php echo form_error('BPJS'); ?></span>
				   </div>
			   </div>
			   <div class="control-group<?php echo form_error('NO_TASPEN') ? ' error' : ''; ?> col-sm-6">
				   <?php echo form_label("NO TASPEN", 'NO_TASPEN', array('class' => 'control-label')); ?>
				   <div class='controls'>
					   <input id='NO_TASPEN' type='text' class="form-control" name='NO_TASPEN' maxlength='50' value="<?php echo set_value('NO_TASPEN', isset($pegawai->NO_TASPEN) ? $pegawai->NO_TASPEN : ''); ?>" />
					   <span class='help-inline'><?php echo form_error('NO_TASPEN'); ?></span>
				   </div>
			   </div>
			   <div class="control-group<?php echo form_error('NPWP') ? ' error' : ''; ?> col-sm-6">
				   <?php echo form_label(lang('pegawai_field_NPWP'), 'NPWP', array('class' => 'control-label')); ?>
				   <div class='controls'>
					   <input id='NPWP' type='text' class="form-control" name='NPWP' maxlength='25' value="<?php echo set_value('NPWP', isset($pegawai->NPWP) ? $pegawai->NPWP : ''); ?>" />
					   <span class='help-inline'><?php echo form_error('NPWP'); ?></span>
				   </div>
			   </div>
			   <div class="control-group col-sm-6">
				   <label for="inputNAMA" class="control-label">TGL NPWP</label>
				   <div class="input-group date">
					 <div class="input-group-addon">
					   <i class="fa fa-calendar"></i>
					 </div>
					   <input id='TGL_NPWP' type='text' class="form-control pull-right datepicker" name='TGL_NPWP' maxlength='25' value="<?php echo set_value('TGL_NPWP', isset($pegawai->TGL_NPWP) ? $pegawai->TGL_NPWP : ''); ?>" />
					   <span class='help-inline'><?php echo form_error('TGL_NPWP'); ?></span>
				   </div>
			   </div> 
		<!-- /.table-responsive -->
	  	<?php if ($this->auth->has_permission('Pegawai.Kepegawaian.Updatemandiri')) : ?>
            <div class="control-group col-sm-6">
            <br>
			 <input type='button' name='save' id="btnsaveprofile" class='btn btn-warning' value="Simpan" />
            </div>
			<?PHP endif; ?>
	  <!-- /.box-body -->
	  </fieldset>
	  <!-- /.box-footer -->    
    </form>
</div>
</div>
<script>
    //Date picker
    $('.datepicker').datepicker({
      autoclose: true,format: 'yyyy-mm-dd'
    });
</script>

<script>
	$("#btnsaveprofile").click(function(){
		submitdata();
		return false; 
	});	
	 
	function submitdata(){
		
		var json_url = "<?php echo base_url() ?>admin/kepegawaian/pegawai/updatemandiri";
		 $.ajax({    
		 	type: "post",
			url: json_url,
			data: $("#frmprofile").serialize(),
            dataType: "json",
			success: function(data){ 
                if(data.success){
                    swal("Pemberitahuan!", data.msg, "success");
                }
                else {
                    $(".messages").empty().append(data.msg);
                }
			}});
		return false; 
	}
</script>
