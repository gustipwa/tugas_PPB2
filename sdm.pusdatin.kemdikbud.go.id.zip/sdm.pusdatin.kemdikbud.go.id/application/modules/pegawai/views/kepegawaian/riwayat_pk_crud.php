<style type="text/css">
    .select2-container {
    z-index: 99999;
}
.select2-container {
    width: 100% !important;
    padding: 0;
}
</style>
<link href="<?php echo base_url(); ?>themes/admin/plugins/bootstrap-fileinput-master/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url(); ?>themes/admin/plugins/bootstrap-fileinput-master/themes/explorer/theme.css" media="all" rel="stylesheet" type="text/css"/>

<?php 
    $id = isset($detail_riwayat->ID) ? $detail_riwayat->ID : '';
?>
<div class='box box-warning' id="form-riwayat-pk-add">
	<div class="box-body">
        <div class="messages">
        </div>
    <?php echo form_open($this->uri->uri_string(), 'id="frmpk"'); ?>
    <fieldset>
       
            <input id='id' type='hidden' class="form-control" name='id' maxlength='32' value="<?php echo set_value('ID', isset($detail_riwayat->ID) ? trim($detail_riwayat->ID) : ''); ?>" />
            <input id='NIP' type='hidden' class="form-control" name='NIP' maxlength='32' value="<?php echo set_value('NIP', isset($NIP_BARU) ? trim($NIP_BARU) : ''); ?>" />
            <div class="control-group<?php echo form_error('n_gol_ruang') ? ' error' : ''; ?> col-sm-12">
                <?php echo form_label("TAHUN", 'Golongan Ruang', array('class' => 'control-label')); ?>
                <div class='controls'>
                    <input type='number' class="form-control" name='TAHUN' maxlength='4' value="<?php echo set_value('TAHUN', isset($detail_riwayat->TAHUN) ? trim($detail_riwayat->TAHUN) : ''); ?>" />
                    <span class='help-inline'><?php echo form_error('TAHUN'); ?></span>
                </div>
            </div>   
            <div class="control-group col-sm-9">
                    <label for="inputNAMA" class="control-label">Berkas</label>
                    <div class='controls'>
                        <div id="form_upload">
                          <input id="berkas" name="berkas" class="file" type="file" data-preview-file-type="pdf">
                        </div>
                        
                    </div>
                </div> 
                <div class="control-group col-sm-3">
                    <label for="inputNAMA" class="control-label"><br></label>
                    <div class='controls'>
                        <?php if(isset($detail_riwayat->BASE64_BERKAS) && $detail_riwayat->BASE64_BERKAS != ""){ ?>
                            <a href="<?php echo base_url(); ?>pegawai/riwayat_perjanjian_kinerja/viewdoc/<?php echo $detail_riwayat->ID; ?>" class="btn btn-warning show-modal"><span class="fa fa-file"></span> Lihat</a>
                        <?php } ?>  
                    </div>
                </div> 
            </fieldset>
            <?php if ($this->auth->has_permission('Riwayatpk.Kepegawaian.VerifikasiS')) { ?>
            <fieldset>
                <legend>Verifikasi Data</legend>
                
                <div class="control-group col-sm-6">
                    <label for="inputNAMA" class="control-label">TERIMA DATA?</label>
                    <div class='controls'>
                        <input id='STATUS_BIRO' type='checkbox' name='STATUS_BIRO' value="1" <?php echo $detail_riwayat->STATUS_BIRO == "1" ? "checked" : ""; ?> />
                        <span class='help-inline'><?php echo form_error('STATUS_BIRO'); ?></span>
                    </div>
                </div> 
                 
            <?php } ?>
        </div>
  		<div class="box-footer">
            <hr>
            <input type='submit' name='save' id="btnsavepk" class='btn btn-primary' value="Simpan Data" /> 
        </div>
    <?php echo form_close(); ?>
</div>
<script src="<?php echo base_url(); ?>themes/admin/plugins/bootstrap-fileinput-master/themes/explorer/theme.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>themes/admin/plugins/bootstrap-fileinput-master/js/fileinput.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>themes/admin/plugins/datepicker/bootstrap-datepicker.js"></script>
<script>
	 $(".select2").select2({width: '100%'});
</script>
<script>
  
    var form = $("#form-riwayat-kgb-add");
    //Date picker
    $('.datepicker').datepicker({
      autoclose: true,format: 'yyyy-mm-dd'
    }).on("input change", function (e) {
        var date = $(this).datepicker('getDate');
    });
</script>
<script>
    $("#berkas").fileinput({
        'showUpload': false
    });
	$("#btnsavepk").click(function(){
		submitdatapk();
		return false; 
	});	
	 
    $(document).ready(function(){
        $(".lazy-select2").each(function(i,o){
            $(this).select2(
                {
                    placeholder: $(this).data('placeholder'),
                    width: '100%',
                    minimumInputLength: $(this).data('minimum'),
                    allowClear: true,
                    ajax: {
                        url: $(this).data('url'),
                        dataType: 'json',
                        data: function(params) {
                            return {
                                term: params.term || '',
                                page: params.page || 1
                            }
                        },
                        cache: true
                    }
                }
            );
        });
    });
	function submitdatapk(){
		var the_data = new FormData(document.getElementById("frmpk"));
		var json_url = "<?php echo base_url() ?>pegawai/riwayat_perjanjian_kinerja/save";
		 $.ajax({    
		 	type: "POST",
			url: json_url,
			data: the_data,
            dataType: "json",
            processData: false, // tell jQuery not to process the data
            contentType: false, // tell jQuery not to set contentType
			success: function(data){ 
                if(data.success){
                    swal("Pemberitahuan!", data.msg, "success");
                    $("#modal-custom-global").trigger("sukses-tambah-riwayat-pk");
					$("#modal-custom-global").modal("hide");
                    $("#modal-global").modal("hide");
                    $grid_daftar_pk.ajax.reload();
                }
                else {
                    $("#form-riwayat-pk-add .messages").empty().append(data.msg);
                }
			}});
		return false; 
	}
</script>