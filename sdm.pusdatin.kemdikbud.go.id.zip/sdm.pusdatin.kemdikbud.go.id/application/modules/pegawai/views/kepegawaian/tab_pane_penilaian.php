
<?php 
	$this->load->library('convert');
 	$convert = new convert();
    $tab_pane_prestasi_kerja = "tab_pane_prestasi_kerja";
    $tab_pane_rwt_tugas_tambahan = "tab_pane_rwt_tugas_tambahan";
    
?>
<?php
$id = isset($pegawai->ID) ? $pegawai->ID : '';
$PNS_ID = isset($pegawai->PNS_ID) ? $pegawai->PNS_ID : '';

?>
 <div class="tab-pane" id="<?php echo $TAB_ID;?>">
    <div class=" panel-body">
        <div class="nav-tabs-custom">
            <ul id="tab-insides-penilaian" class="nav nav-tabs">
                <?php if($this->auth->has_permission("RiwayatPrestasiKerja.Kepegawaian.View")){ ?>
                <li class="active">
                    <a href="#<?php echo $tab_pane_prestasi_kerja;?>" data-toggle="tab" aria-expanded="false"> Prestasi Kerja </a>
                </li>
                <?php } ?>
                <?php if($this->auth->has_permission("Riwayattugas_tambahan.Kepegawaian.View")){ ?>
                <li>
                    <a href="#<?php echo $tab_pane_rwt_tugas_tambahan;?>" data-toggle="tab" aria-expanded="false"> Tugas Tambahan </a>
                </li>
                <?php } ?>
                  
            </ul>
            <div class="tab-content">
                <?php 
                if($this->auth->has_permission("RiwayatPrestasiKerja.Kepegawaian.View")){
                    $this->load->view('kepegawaian/tab_pane_riwayat_prestasi_kerja',array('TAB_ID'=>$tab_pane_prestasi_kerja));
                }
                if($this->auth->has_permission("Riwayattugas_tambahan.Kepegawaian.View")){
                    $this->load->view('kepegawaian/tab_pane_rwt_tugas',array('TAB_ID'=>$tab_pane_rwt_tugas_tambahan));
                }
                
                ?>
            </div>
        </div>
    </div>
</div>                  
  