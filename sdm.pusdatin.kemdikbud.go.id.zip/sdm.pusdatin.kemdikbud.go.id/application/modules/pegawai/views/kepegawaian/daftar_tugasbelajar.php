<?php
$checkSegment = $this->uri->segment(4);
$areaUrl = SITE_AREA . '/izin/sisa_cuti';
$num_columns	= 44;

?>
<div class="row">

    <div class="col-lg-12">
        <div class="ibox float-e-margins">
            <div class="ibox-title">
                <h5>TUGAS BELAJAR</h5>
                <div class="ibox-tools">
                    <a class="collapse-link">
                        <i class="fa fa-chevron-up"></i>
                    </a>
                     
                </div>
            </div>
            <div class="ibox-content">
                <div class="row">
                    <div class="col-sm-12 m-b-xs">
                        
                        <?php echo form_open($this->uri->uri_string(),"id=form_search_pegawai","form"); ?>
						
						<table class="filter_pegawai" sborder=0 width='100%' cellpadding="10">
							<tr>
								<td width="200px"><label for="example-text-input" class="col-form-label">Jenis Satker</label></td>
								<td colspan=2>
									<select id="jenis_satker" name="jenis_satker" width="100%" class="form-control">
										<option value="">Silahkan Pilih</option>
										<option value="PUSAT">PUSAT</option>
										<option value="UPT">UPT</option>
									</select>
								</td>
							</tr>
							<tr>
								<td width="100px"><label for="example-text-input" class="col-form-label">NAMA</label></td>
								<td colspan=2><input class="form-control" type="text" name="nama_key" value="" ></td>
							</tr>
							<tr>
								<td width="100px"><label for="example-text-input" class="col-form-label">NIP</label></td>
								<td colspan=2><input class="form-control" type="text" name="nip_key" value="" ></td>
							</tr>
							  
							<tr>
								<td colspan=4>
									<br>
									<button type="submit" class="btn btn-success pull-right" id="btnsearch"><i class="fa fa-search"></i> Cari</button>
									
								</td>
							</tr>
						</table>
					<?php
					echo form_close();    
					?>
                    </div>
                </div>
                <div class="table-responsive">
                   <table class="slug-table table table-bordered table-striped table-responsive dt-responsive table-data table-hover">
					<thead>
					<tr>
						<th style="width:10px">No</th>
						<th width="20%">NIP</th>
						<th>NAMA</th>
						<th>UNIVERSITAS</th>
						<th width="10%">SELESAI</th>
						<th width="70px" align="center">#</th>
					</tr>
					</thead>
					<body>
						
					</body>
					
				</table>
                </div>
            </div>
        </div>
    </div>

</div>
 
<script type="text/javascript">

$table = $(".table-data").DataTable({
	
	dom : "<'row'<'col-sm-6'><'col-sm-6'>>" +
	"<'row'<'col-sm-12'tr>>" +
	"<'row'<'col-sm-2'l><'col-sm-3'i><'col-sm-7'p>>",
	processing: true,
	serverSide: true,
	"columnDefs": [
					{"className": "text-center", "targets": [0]},
					{ "targets": [0,5], "orderable": false }
				],
	ajax: {
	  url: "<?php echo base_url() ?>pegawai/riwayat_tugasbelajar/daftar_ajax_list",
	  type:'POST',
	  "data": function ( d ) {
			d.search['advanced_search_filters']=  $("#form_search_pegawai").serializeArray();
		}
	}
});
$("#form_search_pegawai").submit(function(){
	$table.ajax.reload(null,true);
	return false;
});
$('body').on('click','.btn-hapus-tb',function () { 
	var kode =$(this).attr("kode");
	swal({
		title: "Anda Yakin?",
		text: "Delete data Tugas Belajar!",
		type: "warning",
		showCancelButton: true,
		confirmButtonClass: 'btn-danger',
		confirmButtonText: 'Ya, Delete!',
		cancelButtonText: "Tidak, Batalkan!",
		closeOnConfirm: false,
		closeOnCancel: false
	},
	function (isConfirm) {
		if (isConfirm) {
			var post_data = "kode="+kode;
			$.ajax({
					url: "<?php echo base_url() ?>pegawai/riwayat_tugasbelajar/delete",
					type:"POST",
					data: post_data,
					dataType: "html",
					timeout:180000,
					success: function (result) {
						 swal("Deleted!", result, "success");
						 $table.ajax.reload(null,true);
				},
				error : function(error) {
					alert(error);
				} 
			});        
			
		} else {
			swal("Batal", "", "error");
		}
	});
});
</script>