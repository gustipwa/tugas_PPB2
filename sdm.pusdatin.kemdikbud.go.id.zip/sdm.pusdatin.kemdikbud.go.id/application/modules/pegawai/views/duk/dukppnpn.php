<?php 
	$TAB_ID = "DUK_CONTAINER";
?>
<style>
	.dt-center {
		text-align:center;
	}
</style>
<!--tab-pane-->
<div class="row">
	<div class="ibox-content">
<div id="<?=$TAB_ID ?>" class="admin-box box box-primary">
	<div class="box-body">	
		<div class="form-group">
			<div class="row">
				  <center>
				  	DAFTAR NOMINATIF PPNPN
				  </center>
			</div>
			<div class="row">
				<div class="col-md-12">

				&nbsp;<button class='btn btn-danger download_xls pull-right' target="_blank"><i class="fa fa-download" aria-hidden="true"></i> Download .xls</button>
					<table id="duk_table" class="table table-data">
						<thead>
							<tr>
								<th class="bordertopbottom" width="35" valign="top" align="center">No</th>
								
								<th class="bordertop" width="183" align="center"> NAMA</th>
								<th class="bordertop" width="183" align="center"> Tempat<br>Tgl Lahir</th>
								<th class="bordertop" width="196" align="center">JK </th>
								<th class="bordertop" width="196" align="center">PENDIDIKAN </th>
								<th class="bordertop" width="61" align="center"> NPWP </th>
								<th class="bordertop" width="61" align="center"> BPJS </th>
								<th class="bordertopbottom" width="183" align="center"> Unitkerja</th> 
							</tr>
							 
						</thead>
						<tfoot>
							<tr>
									
							</tr>
						</tfoot>
						<tbody>
						
						</tbody>
					</table>  
					</div>
				</div>
			</div>
		</div>
	</div>
<!--tab-pane-->
	</div>
</div>

<script type="text/javascript">
	$(".download_xls").click(function(){
		var xyz = $("#form_search_pegawai").serialize();
		window.open("<?php echo base_url('pegawai/duk/dukppnpn_download');?>?"+xyz);
	});
	(function($){
		var $container = $("#<?php echo $TAB_ID;?>");
		var grid_daftar = $(".table-data",$container).DataTable({
				ordering: false,
				processing: true,
				"bFilter": false,
				"bLengthChange": false,
				serverSide: true,
				"columnDefs": [
					{"className": "dt-center", "targets": [0]},
					{"className": "dt-left", "targets": [2,3]},
				],
				ajax: {
					url: "<?php echo base_url() ?>pegawai/duk/ajax_list_ppnpn",
					type:'POST',
					data : function(d){
						d.unit_id = $("#unit_id").val();
					}
				}
		});		
	})(jQuery);
</script>
