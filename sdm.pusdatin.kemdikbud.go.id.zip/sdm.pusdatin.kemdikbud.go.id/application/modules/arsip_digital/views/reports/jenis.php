<div class="admin-box box box-primary expanded-box">
        <div class="box-header">
            <center>REKAPITULASI JUMLAH ARSIP BY JENIS</center>
         </div>
        <div class="box-body">
            
            <table class="slug-table table table-bordered table-striped table-responsive dt-responsive table-data table-hover">
                <thead>
                <tr>
                    <th style="width:5px">No</th>
                    <th>JENIS</th>
                    <th width="10%">Jumlah Dokumen</th>
                   
                </thead>
                <body>
                    <?php
                    $no = 1;
                    $jmldok = 0;
                    if(isset($jenis_arsip) && is_array($jenis_arsip) && count($jenis_arsip)):
                        foreach ($jenis_arsip as $record) {
                    ?>
                        <tr>
                            <td>
                                <?php echo $no; ?>
                            </td>
                            <td>
                                <?php echo $record->NAMA_JENIS; ?>
                            </td>
                            <td align="center">
                                <?php
                                    $jmldok = $jmldok + $adata_arsip[$record->ID];
                                    echo $adata_arsip[$record->ID]; 
                                ?>
                            </td>
                        </tr>
                    <?php
                        $no++;
                        }
                    endif;
                    ?>
                </body>
                <tfoot align="right">
                <tr>
                    <th colspan="2" style="text-align:right">Total:</th>
                    <th align="center"><?php echo $jmldok; ?></th>
                        
                </tr>
            </table>
        </div>
     
<script type="text/javascript">
    $grid_daftararsip = $(".table-data").DataTable({
        "pageLength": 50,
    });
$(".download_xls").click(function(){
    var xyz = $("#form_search").serialize();
    window.open("<?php echo base_url('admin/reports/arsip_digital/download');?>?"+xyz);
});
</script>