<div class="row">
    <div class="col-lg-12">
        <div class="ibox float-e-margins">
            <div class="ibox-title">
                <h5>Struktur Organisasi</h5>
                <div class="ibox-tools">
                    <a class="collapse-link">
                        <i class="fa fa-chevron-up"></i>
                    </a>
                     
                </div>
            </div>
            <div class="ibox-content">
                <div class="row">
                    <div class="col-sm-12 m-b-xs">
                        
                        
                     
                    </div>
                </div>
                <div class="table-responsive">
                   <img src="<?php echo isset($unitkerja->STRUKTUR) ? $unitkerja->STRUKTUR : base_url()."assets/images/noimage.jpg"; ?>" class="img-responsive" width="100%"> 
                    <br>   
                </div>
            </div>
        </div>
        <div class="ibox float-e-margins">
            <div class="ibox-title">
                <h5>Struktur Organisasi -1</h5>
                <div class="ibox-tools">
                    <a class="collapse-link">
                        <i class="fa fa-chevron-up"></i>
                    </a>
                     
                </div>
            </div>
            <div class="ibox-content" style="display: none;">
                <div class="row">
                    <div class="col-sm-12 m-b-xs">
                    </div>
                </div>
                <div class="table-responsive">
                   <img src="<?php echo isset($unitkerja->STRUKTUR1) ? $unitkerja->STRUKTUR1 : base_url()."assets/images/noimage.jpg"; ?>" class="img-responsive" width="100%"> 
                    <br>   
                </div>
            </div>
        </div>
        <div class="ibox float-e-margins">
            <div class="ibox-title">
                <h5>Struktur Organisasi -2</h5>
                <div class="ibox-tools">
                    <a class="collapse-link">
                        <i class="fa fa-chevron-up"></i>
                    </a>
                     
                </div>
            </div>
            <div class="ibox-content" style="display: none;">
                <div class="row">
                    <div class="col-sm-12 m-b-xs">
                    </div>
                </div>
                <div class="table-responsive">
                   <img src="<?php echo isset($unitkerja->STRUKTUR2) ? $unitkerja->STRUKTUR2 : base_url()."assets/images/noimage.jpg"; ?>" class="img-responsive" width="100%"> 
                    <br>   
                </div>
            </div>
        </div>
    </div>

</div>
