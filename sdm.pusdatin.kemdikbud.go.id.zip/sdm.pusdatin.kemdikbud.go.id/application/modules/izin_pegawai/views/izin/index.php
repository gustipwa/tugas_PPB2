
<?php
$checkSegment = $this->uri->segment(4);
$areaUrl = SITE_AREA . '/izin/izin_pegawai';
$num_columns	= 44;
$can_delete	= $this->auth->has_permission('Izin_pegawai.Izin.Delete');
$can_edit		= $this->auth->has_permission('Izin_pegawai.Izin.Edit');

if ($can_delete) {
    $num_columns++;
}
?>
<div class="row">

    <div class="col-lg-12">
        <div class="ibox float-e-margins">
            <div class="ibox-title">
                <h5>Daftar Izin anda</h5>
                <div class="ibox-tools">
                    <a class="collapse-link">
                        <i class="fa fa-chevron-up"></i>
                    </a>
                     
                </div>
            </div>
            <div class="ibox-content">
                <div class="row">
                    <div class="col-sm-12 m-b-xs">
                        
                        <?php echo form_open($this->uri->uri_string(),"id=form_search_pegawai","form"); ?>
						
						<table class="filter_pegawai" sborder=0 width='100%' cellpadding="10">
							 <tr>
								<td width="100px"><label for="example-text-input" class="col-form-label">Status</label></td>
								<td colspan=2>
									<select name="STATUS_ATASAN" id="STATUS_ATASAN" class="form-control">
			                            <option value="">Silahkan Pilih</option>
			                            <option value="1" <?php echo $izin_pegawai->STATUS_ATASAN == "1" ? "selected" : ""; ?> >PENGAJUAN</option>
			                            <option value="2" <?php echo $izin_pegawai->STATUS_ATASAN == "2" ? "selected" : ""; ?> >DISETUJUI</option>
			                            <option value="3" <?php echo $izin_pegawai->STATUS_ATASAN == "3" ? "selected" : ""; ?> >PERUBAHAN</option>
			                            <option value="4" <?php echo $izin_pegawai->STATUS_ATASAN == "4" ? "selected" : ""; ?>>DITANGGUHKAN</option>
			                            <option value="5" <?php echo $izin_pegawai->STATUS_ATASAN == "5" ? "selected" : ""; ?>>TIDAK DISETUJUI</option>
			                        </select>
								</td>
							</tr>
							  
							<tr>
								<td colspan=4 align="right">
									<BR>
									<button type="submit" class="btn btn-w-m btn-success">Cari</button>
									 
									<button type="button" class="btn btn-warning"><a href="<?php echo site_url($areaUrl . '/perizinan/'); ?>" class="show-modal">Ajukan Baru</a></button>
								</td>
							</tr>
						</table>
					<?php
					echo form_close();    
					?>
                    </div>
                </div>
                <div class="table-responsive">
                   <table class="slug-table table table-bordered table-striped table-responsive dt-responsive table-data table-hover">
			            <thead>
			            <tr>
			                <th style="width:10px">No</th>
			                <th>JENIS PENGAJUAN</th>
			                <th>TANGGAL PENGAJUAN</th>
			                <th>TANGGAL PELAKSANAAN</th>
			                <th>ALASAN/<BR>KETERANGAN</th>
			                <th>STATUS</th>
			                <th width="120px" align="center">#</th></tr>
			            </thead>
			        </table>	
                </div>
            </div>
        </div>
    </div>

</div>
 

<script type="text/javascript">

$table = $(".table-data").DataTable({
    
    dom : "<'row'<'col-sm-6'><'col-sm-6'>>" +
    "<'row'<'col-sm-12'tr>>" +
    "<'row'<'col-sm-2'l><'col-sm-3'i><'col-sm-7'p>>",
    processing: true,
    serverSide: true,
    "columnDefs": [
                    {"className": "text-center", "targets": [0,5,6]},
                    { "targets": [0,4], "orderable": false }
                ],
    ajax: {
      url: "<?php echo base_url() ?>admin/izin/izin_pegawai/getdata_izin",
      type:'POST',
      "data": function ( d ) {
            d.search['advanced_search_filters']=  $("#form_search_pegawai").serializeArray();
        }
    }
});
$("#form_search_pegawai").submit(function(){
	$table.ajax.reload(null,true);
	return false;
});


$('body').on('click','.btn-hapus',function () { 
	var kode =$(this).attr("kode");
	swal({
		title: "Anda Yakin?",
		text: "Delete pengajuan izin!",
		type: "warning",
		showCancelButton: true,
		confirmButtonClass: 'btn-danger',
		confirmButtonText: 'Ya, Delete!',
		cancelButtonText: "Tidak, Batalkan!",
		closeOnConfirm: false,
		closeOnCancel: false
	},
	function (isConfirm) {
		if (isConfirm) {
			var post_data = "kode="+kode;
			$.ajax({
					url: "<?php echo base_url() ?>admin/izin/izin_pegawai/deletedata",
					type:"POST",
					data: post_data,
					dataType: "json",
					timeout:180000,
					success: function (result) {
						if(result.success)
						{
							swal("Deleted!", result.msg, "success");
						 	$table.ajax.reload(null,true);
						}else{
							swal("Deleted!", result.msg, "error");
						}
						 
				},
				error : function(error) {
					alert(error);
				} 
			});        
			
		} else {
			swal("Batal", "", "error");
		}
	});
});
let workingDaysBetweenDates = (d0, d1,holidays) => {
  /* Two working days and an sunday (not working day) */
  //var holidays = holidays;
  var startDate = parseDate(d0);
  var endDate = parseDate(d1);  

// Validate input
  if (endDate < startDate) {
    return 0;
  }

// Calculate days between dates
  var millisecondsPerDay = 86400 * 1000; // Day in milliseconds
  startDate.setHours(0, 0, 0, 1);  // Start just after midnight
  endDate.setHours(23, 59, 59, 999);  // End just before midnight
  var diff = endDate - startDate;  // Milliseconds between datetime objects    
  var days = Math.ceil(diff / millisecondsPerDay);

  // Subtract two weekend days for every week in between
  var weeks = Math.floor(days / 7);
  days -= weeks * 2;

  // Handle special cases
  var startDay = startDate.getDay();
  var endDay = endDate.getDay();
    
  // Remove weekend not previously removed.   
  if (startDay - endDay > 1) {
    days -= 2;
  }
  // Remove start day if span starts on Sunday but ends before Saturday
  if (startDay == 0 && endDay != 6) {
    days--;  
  }
  // Remove end day if span ends on Saturday but starts after Sunday
  if (endDay == 6 && startDay != 0) {
    days--;
  }
  /* Here is the code */
  holidays.forEach(day => {

    if ((day >= d0) && (day <= d1)) {
      /* If it is not saturday (6) or sunday (0), substract it */
      if ((parseDate(day).getDay() % 6) != 0) {
        days--;
      }
    }
  });
  return days;
}
</script>