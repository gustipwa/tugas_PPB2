<?php defined('BASEPATH') || exit('No direct script access allowed');

/**
 * Izin controller
 */
class Izin extends Admin_Controller
{
    protected $permissionCreate = 'Izin_pegawai.Izin.Create';
    protected $permissionDelete = 'Izin_pegawai.Izin.Delete';
    protected $permissionEdit   = 'Izin_pegawai.Izin.Edit';
    protected $permissionView   = 'Izin_pegawai.Izin.View';
    protected $permissionVerifikasi   = 'Izin_pegawai.Izin.Verifikasi';
    protected $permissionPybmc   = 'Izin_pegawai.Izin.Persetujuan';
    protected $permissionViewSatker   = 'Izin_pegawai.Izin.ViewSatker';
    protected $permissionViewAll   = 'Izin_pegawai.Izin.ViewAll';

    protected $permissionSettingView   = 'Setting_atasan.Izin.View';
    protected $permissionSettingAdd   = 'Setting_atasan.Izin.Add';
    protected $permissionSettingDelete   = 'Setting_atasan.Izin.Delete';

    protected $permissionSettingKirimAbsen   = 'Izin_pegawai.KirimAbsen.View';
    protected $permissionLaporanPegawai   = 'Izin_pegawai.Izin.LaporanPegawai';
    protected $permissionFiltersatker   = 'Pegawai.Kepegawaian.Filtersatker';
    public $UNOR_ID = "";//"8ae483c66fc5c935016fd53ac5144d9a";
    /**
     * Constructor
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        
        date_default_timezone_set("Asia/Jakarta");
        $this->load->model('izin_pegawai/izin_pegawai_model');
        $this->load->model('izin_pegawai/mv_pegawai_cuti_model');
        $this->load->model('izin_pegawai/pegawai_atasan_model');
        $this->load->model('sisa_cuti/sisa_cuti_model');
        $this->load->model('jenis_izin/jenis_izin_model');
        $this->load->model('pegawai/pegawai_model');
        $this->load->model('izin_pegawai/absen_model');
        $this->load->model('izin_pegawai/line_approval_model');
        $this->load->model('izin_pegawai/izin_alasan_model');
        $this->load->model('izin_pegawai/izin_verifikasi_model');
        $this->lang->load('izin_pegawai');
        $this->load->helper('dikbud');
            Assets::add_css('flick/jquery-ui-1.8.13.custom.css');
            Assets::add_js('jquery-ui-1.8.13.min.js');
            $this->form_validation->set_error_delimiters("<span class='error'>", "</span>");
        
        Template::set_block('sub_nav', 'izin/_sub_nav');

        Assets::add_module_js('izin_pegawai', 'izin_pegawai.js');

        if($this->auth->has_permission($this->permissionFiltersatker)){
            $this->UNOR_ID = $this->pegawai_model->getunor_induk($this->auth->username());
        }
    }

    /**
     * Display a list of izin pegawai data.
     *
     * @return void
     */
    public function index()
    {
        $this->auth->restrict($this->permissionView);
        $jenis_izin = $this->jenis_izin_model->find_all();
        Template::set('jenis_izin', $jenis_izin);
        Template::set('toolbar_title', lang('izin_pegawai_manage'));
        Template::render();
    }
    public function viewall()
    {
        $this->auth->restrict($this->permissionViewAll);
        $jenis_izin = $this->jenis_izin_model->find_all();
        Template::set('jenis_izin', $jenis_izin);
        Template::set('toolbar_title', "Lihat semua Izin");
        Template::render();
    }
    public function viewallsatker()
    {
        $this->auth->restrict($this->permissionViewSatker);
        $jenis_izin = $this->jenis_izin_model->find_all();
        Template::set('jenis_izin', $jenis_izin);
        Template::set('toolbar_title', "Lihat semua Izin (Satker)");
        Template::render();
    }
    public function verifikasi()
    {
        $this->auth->restrict($this->permissionVerifikasi);
        $this->load->helper('dikbud');
        $data_status_izin = Liststatus_izin();
        Template::set('data_status_izin', $data_status_izin);
        Template::set('toolbar_title', "Verifikasi Izin");
        Template::render();
    }
    public function pybmc()
    {
        $this->auth->restrict($this->permissionPybmc);
        Template::set('toolbar_title', "Persetujuan PYBMC");
        Template::render();
    }
    public function setting()
    {
        $this->auth->restrict($this->permissionSettingView);
        $jenis_izin = $this->jenis_izin_model->find_all();
        Template::set('jenis_izin', $jenis_izin);
        Template::set('toolbar_title', "Setting Atasan");
        Template::render();
    }
    public function pilihpejabat()
    {
        $this->auth->restrict($this->permissionSettingAdd);
        
        Template::set('toolbar_title', "Pilih Pejabat");
        Template::render();
    }
    
    /**
     * Create a izin pegawai object.
     *
     * @return void
     */
    public function create()
    {
        $this->auth->restrict($this->permissionCreate);
        $this->load->model('pegawai/Pns_aktif_model');
        $this->load->model('pegawai/unitkerja_model');
        $this->load->model('ref_jabatan/jabatan_model');
        $this->load->library('Convert');
        $convert = new Convert;
        $id = $this->uri->segment(5);
        $ses_nip    = trim($this->auth->username());
        $TAHUN      = trim(date("Y")." ");
        $jenis_izin = $this->jenis_izin_model->find($id);
        $nama_izin  = isset($jenis_izin->NAMA_IZIN) ? $jenis_izin->NAMA_IZIN : "";
        $keterangan_izin = isset($jenis_izin->KETERANGAN) ? $jenis_izin->KETERANGAN : "";
        $level      = isset($jenis_izin->PERSETUJUAN) ? $jenis_izin->PERSETUJUAN : "";
        $ahari_libur = $this->get_json_harilibur_tahunan($TAHUN);
        Template::set('ahari_libur', json_encode($ahari_libur));
        //print_r($ahari_libur);
         
        // get atasan langsung
        $dataatasan     = $this->get_data_pejabat($ses_nip);
        $NIP_ATASAN     = isset($dataatasan[2]->NIP_ATASAN) ? $dataatasan[2]->NIP_ATASAN : "";
        
        $alasan_izin = $this->izin_alasan_model->find_all($id);
        Template::set('alasan_izin', $alasan_izin);
        if($id == "1"){
            $this->sisa_cuti_model->where("TAHUN = '".$TAHUN."'");
            $data_cuti = $this->sisa_cuti_model->find_by("PNS_NIP",$ses_nip);
            if($data_cuti->ID == ""){
                $SISA_N = 0;
                $SISA_N_1 = 0;
                $SISA_N_2 = 0;
                $SISA = 0;
                $tahun_1 = $TAHUN - 1;
                $this->sisa_cuti_model->where("TAHUN = '".$tahun_1."'");
                $data_cuti_1 = $this->sisa_cuti_model->find_by("PNS_NIP",$ses_nip);
                if($data_cuti_1->ID != ""){
                    if($data_cuti_1->SISA_N >= 6){
                        $SISA_N_1 = 6;
                        $SISA_N = 12;
                        $SISA = 12 + 6;
                    }
                    if($data_cuti_1->SISA_N >= 12 && $data_cuti_1->SISA_N_1 >= 12){
                        $SISA_N_1 = 6;
                        $SISA_N_2 = 6;
                        $SISA_N = 12;
                        $SISA = 12 + 12;
                    }
                }else{
                    $SISA_N_1 = 0;
                    $SISA_N_2 = 0;
                    $SISA_N = 12;
                    $SISA = 12;
                }

                $data_pegawai = $this->pegawai_model->find_by("NIP_BARU",$ses_nip);
                $NAMA_PEGAWAI = isset($data_pegawai->NAMA) ? $data_pegawai->NAMA : "";
                $data['PNS_NIP'] = $ses_nip;
                $data['NAMA'] = $NAMA_PEGAWAI;
                $data['TAHUN'] = $TAHUN;
                $data['SISA_N'] = (int)$SISA_N;
                $data['SISA_N_1'] = (int)$SISA_N_1;
                $data['SISA_N_2'] = (int)$SISA_N_2;
                $data['SISA'] = (int)$SISA;
                $this->sisa_cuti_model->skip_validation(true);
                if($insert_id = $this->sisa_cuti_model->insert($data)){
                    log_activity($this->auth->user_id(), 'Save data sisa cuti : ' . $insert_id . ' : ' . $this->input->ip_address(), 'sisa_cuti');    
                }
            }

            $this->sisa_cuti_model->where("TAHUN = '".$TAHUN."'");
            $data_cuti = $this->sisa_cuti_model->find_by("PNS_NIP",$ses_nip);
        }
        if($id == "5"){
            
        }
        if($id == "12"){
            $tanggal = date("Y-m-d");
            $data_absen = $this->absen_model->getdata_absen($ses_nip,$tanggal);
            Template::set("data_absen",$data_absen);
        }
        $file_view = 'application/modules/izin_pegawai/views/izin/'.$id.'.php'; 

        if (file_exists($file_view))  
        { 
            Template::set_view("izin/".$id);
        } 
        else 
        { 
            Template::set_view("izin/create");
        } 

        $pegawai = $this->pegawai_model->find_detil_with_nip($ses_nip);
        $recpns_aktif = $this->Pns_aktif_model->find($pegawai->ID);
        Template::set("parent_path_array_unor",$this->unitkerja_model->get_parent_path($pegawai->UNOR_ID,true,true));

        $JABATAN_ID = $pegawai->JABATAN_INSTANSI_ID;
        $JABATAN_INSTANSI_REAL_ID = $pegawai->JABATAN_INSTANSI_REAL_ID;
        if($JABATAN_INSTANSI_REAL_ID != ""){
            $recjabatan = $this->jabatan_model->find_by("KODE_JABATAN",TRIM($JABATAN_INSTANSI_REAL_ID));
            Template::set('NAMA_JABATAN_REAL', $recjabatan->NAMA_JABATAN);
        }
        if($JABATAN_ID != ""){
            $recjabatan = $this->jabatan_model->find_by("KODE_JABATAN",TRIM($JABATAN_ID));
            Template::set('NAMA_JABATAN', $recjabatan->NAMA_JABATAN);
            Template::set('NAMA_JABATAN_BKN', $recjabatan->NAMA_JABATAN_BKN);
        }
        $foto_pegawai = trim($this->settings_lib->item('site.urlphoto'))."noimage.jpg";
        if(file_exists(trim($this->settings_lib->item('site.urlphoto')).$pegawai->PHOTO)){
            $foto_pegawai =  trim($this->settings_lib->item('site.urlphoto')).$pegawai->PHOTO;
        }
        Template::set('foto_pegawai', $foto_pegawai);
        // CEK DI TABEL UNITKERJA
        $unor = $this->unitkerja_model->find_by("ID",trim($pegawai->UNOR_ID));
        
        Template::set('unit_kerja',$unor->NAMA_UNOR);
        $unor_induk = $this->unitkerja_model->find_by("ID",$unor->UNOR_INDUK);
        Template::set('unor_induk_id',$unor_induk->ID);
        Template::set('unor_induk',$unor_induk->NAMA_UNOR);

         
        $tanggal = date("Y-m-d");
        $tanggal_indonesia = $convert->fmtDate($tanggal,"dd month yyyy");
        $hari = $convert->Gethari($tanggal);
        Template::set('tanggal_indonesia', $tanggal_indonesia);
        Template::set('hari', $hari);
        Template::set('NIP_ATASAN', $NIP_ATASAN);
        Template::set('data_cuti',$data_cuti);
        Template::set('pegawai', $pegawai);
        Template::set('recpns_aktif', $recpns_aktif);
        Template::set('keterangan_izin', $keterangan_izin);
        Template::set('kode_izin', $id);
        Template::set('NIP_PNS', $ses_nip);
        Template::set('nama_izin', $nama_izin);
        Template::set('toolbar_title', "Ajukan Izin ".$nama_izin);

        Template::render();
    }
    public function createselect($id_jenis_izin = "")
    {
        $this->auth->restrict($this->permissionCreate);
        $this->load->model('pegawai/Pns_aktif_model');
        $this->load->model('pegawai/unitkerja_model');
        $this->load->model('ref_jabatan/jabatan_model');

        $jenis_izin = $this->jenis_izin_model->find_all();
        Template::set('jenis_izin', $jenis_izin);
        Template::set('id_jenis_izin', $id_jenis_izin); 
        Template::set('toolbar_title', "Ajukan Izin ");

        Template::render();
    }
    public function viewalur()
    {
        $this->auth->restrict($this->permissionCreate);
        $this->load->model('pegawai/Pns_aktif_model');
        $this->load->model('pegawai/unitkerja_model');
        $this->load->model('ref_jabatan/jabatan_model');
        $id = $this->uri->segment(5);
        $kode_tabel = $this->uri->segment(6);
        $izin_pegawai = $this->izin_pegawai_model->find($kode_tabel);
        Template::set('izin_pegawai', $izin_pegawai);

        $ses_nip    = trim($this->auth->username());
        $data_pegawai = $this->pegawai_model->find_by("NIP_BARU",$ses_nip);
        $NAMA_PEGAWAI = isset($data_pegawai->NAMA) ? $data_pegawai->NAMA : "";

        $TAHUN      = trim(date("Y")." ");
        $jenis_izin = $this->jenis_izin_model->find($id);
        $nama_izin  = isset($jenis_izin->NAMA_IZIN) ? $jenis_izin->NAMA_IZIN : "";
        $keterangan_izin = isset($jenis_izin->KETERANGAN) ? $jenis_izin->KETERANGAN : "";
        $PERSETUJUAN      = isset($jenis_izin->PERSETUJUAN) ? $jenis_izin->PERSETUJUAN : "";
        Template::set('NAMA_PEGAWAI', $NAMA_PEGAWAI);
        Template::set('aatasan', $this->get_data_pejabat($ses_nip));
        Template::set('line_approval', $line_approval);
        Template::set('PERSETUJUAN', $PERSETUJUAN);

        Template::set_view("izin/_lineapproval");

        Template::render();
    }
    
    private function cek_kelengkapan_atasan($nip = "",$jenis_izin = ""){
        $dataatasan     = $this->get_data_pejabat($nip);
        $persetujuan    = $this->getpersetujuan($jenis_izin);
        $return = true;
        foreach($persetujuan as $values)
        {
            if(!isset($dataatasan[$values])){
                return false;
            }
        }
        return $return;
    }
    /**
     * Allows editing of izin pegawai data.
     *
     * @return void
     */
    public function edit()
    {
        $this->auth->restrict($this->permissionCreate);
        $this->load->model('pegawai/Pns_aktif_model');
        $this->load->model('pegawai/unitkerja_model');
        $this->load->model('ref_jabatan/jabatan_model');
        $id = $this->uri->segment(5);
        $kode_tabel = $this->uri->segment(6);
        $izin_pegawai = $this->izin_pegawai_model->find($kode_tabel);
        Template::set('izin_pegawai', $izin_pegawai);

        $ses_nip    = trim($this->auth->username());
        $TAHUN      = trim(date("Y")." ");
        $jenis_izin = $this->jenis_izin_model->find($id);
        $nama_izin  = isset($jenis_izin->NAMA_IZIN) ? $jenis_izin->NAMA_IZIN : "";
        $keterangan_izin = isset($jenis_izin->KETERANGAN) ? $jenis_izin->KETERANGAN : "";
        $level      = isset($jenis_izin->PERSETUJUAN) ? $jenis_izin->PERSETUJUAN : "";

        if($level != ""){
            $this->line_approval_model->limit($level);   
        }
        $line_approval = $this->line_approval_model->find_all($ses_nip);
        Template::set('line_approval', $line_approval);
        
        $ahari_libur = $this->get_json_harilibur_tahunan($TAHUN);
        Template::set('ahari_libur', json_encode($ahari_libur));
        $alasan_izin = $this->izin_alasan_model->find_all($id);
        Template::set('alasan_izin', $alasan_izin);
        if($id == "1"){
            $this->sisa_cuti_model->where("TAHUN = '".$TAHUN."'");
            $data_cuti = $this->sisa_cuti_model->find_by("PNS_NIP",$ses_nip);
            if($data_cuti->ID == ""){
                $SISA_N = 0;
                $SISA_N_1 = 0;
                $SISA_N_2 = 0;
                $SISA = 0;
                $tahun_1 = $TAHUN - 1;
                $this->sisa_cuti_model->where("TAHUN = '".$tahun_1."'");
                $data_cuti_1 = $this->sisa_cuti_model->find_by("PNS_NIP",$ses_nip);
                if($data_cuti_1->ID != ""){
                    if($data_cuti_1->SISA_N >= 6){
                        $SISA_N_1 = 6;
                        $SISA_N = 12;
                        $SISA = 12 + 6;
                    }
                    if($data_cuti_1->SISA_N >= 12 && $data_cuti_1->SISA_N_1 >= 12){
                        $SISA_N_1 = 6;
                        $SISA_N_2 = 6;
                        $SISA_N = 12;
                        $SISA = 12 + 12;
                    }
                }else{
                    $SISA_N_1 = 0;
                    $SISA_N_2 = 0;
                    $SISA_N = 12;
                    $SISA = 12;
                }

                $data_pegawai = $this->pegawai_model->find_by("NIP_BARU",$ses_nip);
                $NAMA_PEGAWAI = isset($data_pegawai->NAMA) ? $data_pegawai->NAMA : "";
                $data['PNS_NIP'] = $ses_nip;
                $data['NAMA'] = $NAMA_PEGAWAI;
                $data['TAHUN'] = $TAHUN;
                $data['SISA_N'] = (int)$SISA_N;
                $data['SISA_N_1'] = (int)$SISA_N_1;
                $data['SISA_N_2'] = (int)$SISA_N_2;
                $data['SISA'] = (int)$SISA;
                $this->sisa_cuti_model->skip_validation(true);
                if($insert_id = $this->sisa_cuti_model->insert($data)){
                    log_activity($this->auth->user_id(), 'Save data sisa cuti : ' . $insert_id . ' : ' . $this->input->ip_address(), 'sisa_cuti');    
                }
            }

            $this->sisa_cuti_model->where("TAHUN = '".$TAHUN."'");
            $data_cuti = $this->sisa_cuti_model->find_by("PNS_NIP",$ses_nip);
        }
        if($id == "12"){
            $tanggal = date("Y-m-d");
            $data_absen = $this->absen_model->getdata_absen($ses_nip,$tanggal);
            print_r($data_absen);
            $jam_checkin = isset($data_absen[0]->JAM) ? $data_absen[0]->JAM : "";
            $jam_checkout = "";
            if(isset($data_absen[0]->JAM) and count($data_absen) > 1){
                $index_checkout =  count($data_absen) - 1;
                $jam_checkout = isset($data_absen[$index_checkout]->JAM) ? $data_absen[$index_checkout]->JAM : "";
            }
            Template::set("jam_checkin",$jam_checkin);
            Template::set("jam_checkout",$jam_checkout);
        }
        $file_view = 'application/modules/izin_pegawai/views/izin/'.$id.'.php'; 
        if (file_exists($file_view))  
        { 
            Template::set_view("izin/".$id);
        } 
        else 
        { 
            Template::set_view("izin/create");
        } 

        $pegawai = $this->pegawai_model->find_detil_with_nip($ses_nip);
        $recpns_aktif = $this->Pns_aktif_model->find($pegawai->ID);
        Template::set("parent_path_array_unor",$this->unitkerja_model->get_parent_path($pegawai->UNOR_ID,true,true));

        $JABATAN_ID = $pegawai->JABATAN_INSTANSI_ID;
        $JABATAN_INSTANSI_REAL_ID = $pegawai->JABATAN_INSTANSI_REAL_ID;
        if($JABATAN_INSTANSI_REAL_ID != ""){
            $recjabatan = $this->jabatan_model->find_by("KODE_JABATAN",TRIM($JABATAN_INSTANSI_REAL_ID));
            Template::set('NAMA_JABATAN_REAL', $recjabatan->NAMA_JABATAN);
        }
        if($JABATAN_ID != ""){
            $recjabatan = $this->jabatan_model->find_by("KODE_JABATAN",TRIM($JABATAN_ID));
            Template::set('NAMA_JABATAN', $recjabatan->NAMA_JABATAN);
            Template::set('NAMA_JABATAN_BKN', $recjabatan->NAMA_JABATAN_BKN);
        }
        $foto_pegawai = trim($this->settings_lib->item('site.urlphoto'))."noimage.jpg";
        if(file_exists(trim($this->settings_lib->item('site.urlphoto')).$pegawai->PHOTO)){
            $foto_pegawai =  trim($this->settings_lib->item('site.urlphoto')).$pegawai->PHOTO;
        }
        Template::set('foto_pegawai', $foto_pegawai);
        // CEK DI TABEL UNITKERJA
        $unor = $this->unitkerja_model->find_by("ID",trim($pegawai->UNOR_ID));
        
        Template::set('unit_kerja',$unor->NAMA_UNOR);
        $unor_induk = $this->unitkerja_model->find_by("ID",$unor->UNOR_INDUK);
        Template::set('unor_induk_id',$unor_induk->ID);
        Template::set('unor_induk',$unor_induk->NAMA_UNOR);

        // CEK PEJABAT DI TABEL SETTING PEJABAT
        $recdata_pejabat = $this->pegawai_atasan_model->find_by("PNS_NIP",trim($ses_nip));
        $NIP_ATASAN = "";
        $NAMA_ATASAN = "";
        $NIP_PPK = "";
        $NAMA_PPK = "";
        if($recdata_pejabat->ID != ""){
            $NIP_ATASAN = $recdata_pejabat->NIP_ATASAN;
            $NAMA_ATASAN = $recdata_pejabat->NAMA_ATASAN;
            $NIP_PPK = $recdata_pejabat->PPK;
            $NAMA_PPK = $recdata_pejabat->NAMA_PPK;
        }else{
            
        }
        Template::set('NIP_ATASAN',$NIP_ATASAN);
        Template::set('NAMA_ATASAN',$NAMA_ATASAN);
        Template::set('NIP_PPK',$NIP_PPK);
        Template::set('NAMA_PPK',$NAMA_PPK);

        Template::set('data_cuti',$data_cuti);
        Template::set('pegawai', $pegawai);
        Template::set('recpns_aktif', $recpns_aktif);
        Template::set('level', $level);
        Template::set('keterangan_izin', $keterangan_izin);
        Template::set('kode_izin', $id);
        Template::set('NIP_PNS', $ses_nip);
        Template::set('nama_izin', $nama_izin);
        Template::set('toolbar_title', "Ajukan Izin ".$nama_izin);

        Template::render();
    }
    public function lineaproval()
    {
        $this->auth->restrict($this->permissionCreate);
        $ses_nip    = trim($this->auth->username());
        $this->load->helper('dikbud');
        $this->load->model('pegawai/Pns_aktif_model');
        $this->load->model('pegawai/unitkerja_model');
        $this->load->model('ref_jabatan/jabatan_model');
        $id = $this->uri->segment(5);
        $kode_tabel = $this->uri->segment(6);
        $izin_pegawai = $this->izin_pegawai_model->find($kode_tabel);
        $ses_nip    = $izin_pegawai->NIP_PNS; 
        Template::set('izin_pegawai', $izin_pegawai);
        $verifikasidata = $this->get_data_verifikasi_izin($izin_pegawai->ID);
        Template::set('verifikasidata', $verifikasidata);

        $jenis_izin = $this->jenis_izin_model->find($id);
        $nama_izin  = isset($jenis_izin->NAMA_IZIN) ? $jenis_izin->NAMA_IZIN : "";
        $PERSETUJUAN      = isset($jenis_izin->PERSETUJUAN) ? $jenis_izin->PERSETUJUAN : "";

        $adata_pejabat = $this->get_data_pejabat($ses_nip);
        Template::set('NAMA_PEGAWAI', $this->getnama_pegawai_session($ses_nip));
        Template::set('aatasan', $adata_pejabat);
        Template::set('PERSETUJUAN', $PERSETUJUAN);

        Template::set('toolbar_title', "Line Approval ".$nama_izin);

        Template::render();
    }
    private function getnama_pegawai_session($ses_nip = ""){
        $this->pegawai_model->select("NAMA");
        $data_pegawai = $this->pegawai_model->find_by("NIP_BARU",$ses_nip);
        $NAMA_PEGAWAI = isset($data_pegawai->NAMA) ? $data_pegawai->NAMA : "";
        return $NAMA_PEGAWAI;
    }
    private function list_status(){
        $status_arr = Liststatus_izin();
        foreach($status_arr as $row){
            $data[] = array(
                'id'=>$row['id'],
                'text'=>$row['value'],
            );
        }
        $output = array(
            'results'=>$data 
        );
        return json_encode($output);
    }
    private function get_data_pejabat($ses_nip = ""){
        $line_approval = $this->getatasan($ses_nip);
        $aatasan = array();
        if(isset($line_approval) && is_array($line_approval) && count($line_approval)):
            foreach ($line_approval as $record) {
                $aatasan[$record->SEBAGAI] = $record;
            }
        endif;
        return $aatasan;
    }
    private function getpersetujuan($id){
        $jenis_izin = $this->jenis_izin_model->find($id);
        $level      = isset($jenis_izin->PERSETUJUAN) ? json_decode($jenis_izin->PERSETUJUAN) : "";
        return $level;
    }
    public function verifikasiusulan()
    {
        $this->auth->restrict($this->permissionVerifikasi);
        $this->load->model('pegawai/Pns_aktif_model');
        $this->load->model('pegawai/unitkerja_model');
        $this->load->model('ref_jabatan/jabatan_model');
        $id = $this->uri->segment(5);
        $kode_tabel = $this->uri->segment(6);

        $izin_verifikasi_detil = $this->izin_verifikasi_model->find($kode_tabel);
        $kode_pengajuan = isset($izin_verifikasi_detil->ID_PENGAJUAN) ? $izin_verifikasi_detil->ID_PENGAJUAN : "";

        $izin_pegawai = $this->izin_pegawai_model->find($kode_pengajuan);
        $ses_nip = isset($izin_pegawai->NIP_PNS) ? $izin_pegawai->NIP_PNS : "-";
        $DARI_TANGGAL = isset($izin_pegawai->DARI_TANGGAL) ? $izin_pegawai->DARI_TANGGAL : "-";
        Template::set('izin_pegawai', $izin_pegawai);

        $TAHUN      = date('Y', strtotime($DARI_TANGGAL));;
        $jenis_izin = $this->jenis_izin_model->find($id);
        $nama_izin  = isset($jenis_izin->NAMA_IZIN) ? $jenis_izin->NAMA_IZIN : "";
        $keterangan_izin = isset($jenis_izin->KETERANGAN) ? $jenis_izin->KETERANGAN : "";
        $level      = isset($jenis_izin->PERSETUJUAN) ? $jenis_izin->PERSETUJUAN : "";
        $KODE_JENIS_IZIN      = isset($jenis_izin->KODE) ? $jenis_izin->KODE : "";
        Template::set('KODE_JENIS_IZIN',$KODE_JENIS_IZIN);    
        if($id != ""){
            $this->sisa_cuti_model->where("TAHUN = '".$TAHUN."'");
            $data_cuti = $this->sisa_cuti_model->find_by("PNS_NIP",$ses_nip);
            Template::set('data_cuti',$data_cuti);    
        }
        $pegawai = $this->pegawai_model->find_detil_with_nip($ses_nip);
        $recpns_aktif = $this->Pns_aktif_model->find($pegawai->ID);
        Template::set("parent_path_array_unor",$this->unitkerja_model->get_parent_path($pegawai->UNOR_ID,true,true));

        $JABATAN_ID = $pegawai->JABATAN_INSTANSI_ID;
        $JABATAN_INSTANSI_REAL_ID = $pegawai->JABATAN_INSTANSI_REAL_ID;
        if($JABATAN_INSTANSI_REAL_ID != ""){
            $recjabatan = $this->jabatan_model->find_by("KODE_JABATAN",TRIM($JABATAN_INSTANSI_REAL_ID));
            Template::set('NAMA_JABATAN_REAL', $recjabatan->NAMA_JABATAN);
        }
        if($JABATAN_ID != ""){
            $recjabatan = $this->jabatan_model->find_by("KODE_JABATAN",TRIM($JABATAN_ID));
            Template::set('NAMA_JABATAN', $recjabatan->NAMA_JABATAN);
            Template::set('NAMA_JABATAN_BKN', $recjabatan->NAMA_JABATAN_BKN);
        }
        $foto_pegawai = trim($this->settings_lib->item('site.urlphoto'))."noimage.jpg";
        if(file_exists(trim($this->settings_lib->item('site.urlphoto')).$pegawai->PHOTO)){
            $foto_pegawai =  trim($this->settings_lib->item('site.urlphoto')).$pegawai->PHOTO;
        }
        Template::set('foto_pegawai', $foto_pegawai);
        // CEK DI TABEL UNITKERJA
        $unor = $this->unitkerja_model->find_by("ID",trim($pegawai->UNOR_ID));
        
        Template::set('unit_kerja',$unor->NAMA_UNOR);
        $unor_induk = $this->unitkerja_model->find_by("ID",$unor->UNOR_INDUK);
        Template::set('unor_induk_id',$unor_induk->ID);
        Template::set('unor_induk',$unor_induk->NAMA_UNOR);

        Template::set('ID_VERIFIKASI', $kode_tabel);
        Template::set('pegawai', $pegawai);
        Template::set('recpns_aktif', $recpns_aktif);
        Template::set('level', $level);
        Template::set('keterangan_izin', $keterangan_izin);
        Template::set('kode_izin', $id);
        Template::set('NIP_PNS', $ses_nip);
        Template::set('nama_izin', $nama_izin);
        Template::set('toolbar_title', "Verifikasi Izin ".$nama_izin);

        Template::render();
    }
    public function verifikasipybmc()
    {
        $this->auth->restrict($this->permissionPybmc);
        $this->load->model('pegawai/Pns_aktif_model');
        $this->load->model('pegawai/unitkerja_model');
        $this->load->model('ref_jabatan/jabatan_model');
        $id = $this->uri->segment(5);
        $kode_tabel = $this->uri->segment(6);
        $izin_pegawai = $this->izin_pegawai_model->find($kode_tabel);
        $ses_nip = isset($izin_pegawai->NIP_PNS) ? $izin_pegawai->NIP_PNS : "";
        Template::set('izin_pegawai', $izin_pegawai);

        $TAHUN      = trim(date("Y")." ");
        $jenis_izin = $this->jenis_izin_model->find($id);
        $nama_izin  = isset($jenis_izin->NAMA_IZIN) ? $jenis_izin->NAMA_IZIN : "";
        $keterangan_izin = isset($jenis_izin->KETERANGAN) ? $jenis_izin->KETERANGAN : "";
        $level      = isset($jenis_izin->PERSETUJUAN) ? $jenis_izin->PERSETUJUAN : "";
        
        if($id != ""){
            $this->sisa_cuti_model->where("TAHUN = '".$TAHUN."'");
            $data_cuti = $this->sisa_cuti_model->find_by("PNS_NIP",$ses_nip);
            Template::set('data_cuti',$data_cuti);    
        }
        $pegawai = $this->pegawai_model->find_detil_with_nip($ses_nip);
        $recpns_aktif = $this->Pns_aktif_model->find($pegawai->ID);
        Template::set("parent_path_array_unor",$this->unitkerja_model->get_parent_path($pegawai->UNOR_ID,true,true));

        $JABATAN_ID = $pegawai->JABATAN_INSTANSI_ID;
        $JABATAN_INSTANSI_REAL_ID = $pegawai->JABATAN_INSTANSI_REAL_ID;
        if($JABATAN_INSTANSI_REAL_ID != ""){
            $recjabatan = $this->jabatan_model->find_by("KODE_JABATAN",TRIM($JABATAN_INSTANSI_REAL_ID));
            Template::set('NAMA_JABATAN_REAL', $recjabatan->NAMA_JABATAN);
        }
        if($JABATAN_ID != ""){
            $recjabatan = $this->jabatan_model->find_by("KODE_JABATAN",TRIM($JABATAN_ID));
            Template::set('NAMA_JABATAN', $recjabatan->NAMA_JABATAN);
            Template::set('NAMA_JABATAN_BKN', $recjabatan->NAMA_JABATAN_BKN);
        }
        $foto_pegawai = trim($this->settings_lib->item('site.urlphoto'))."noimage.jpg";
        if(file_exists(trim($this->settings_lib->item('site.pathphoto')).$pegawai->PHOTO)){
            $foto_pegawai =  trim($this->settings_lib->item('site.urlphoto')).$pegawai->PHOTO;
        }
        Template::set('foto_pegawai', $foto_pegawai);
        // CEK DI TABEL UNITKERJA
        $unor = $this->unitkerja_model->find_by("ID",trim($pegawai->UNOR_ID));
        
        Template::set('unit_kerja',$unor->NAMA_UNOR);
        $unor_induk = $this->unitkerja_model->find_by("ID",$unor->UNOR_INDUK);
        Template::set('unor_induk_id',$unor_induk->ID);
        Template::set('unor_induk',$unor_induk->NAMA_UNOR);

        Template::set('pegawai', $pegawai);
        Template::set('recpns_aktif', $recpns_aktif);
        Template::set('level', $level);
        Template::set('keterangan_izin', $keterangan_izin);
        Template::set('kode_izin', $id);
        Template::set('NIP_PNS', $ses_nip);
        Template::set('nama_izin', $nama_izin);
        Template::set('toolbar_title', "Verifikasi Izin ".$nama_izin);

        Template::render();
    }
    public function formpdf()
    {
        //$this->auth->restrict($this->permissionVerifikasi);
        $this->load->model('pegawai/Pns_aktif_model');
        $this->load->model('pegawai/unitkerja_model');
        $this->load->model('ref_jabatan/jabatan_model');
        $id = $this->uri->segment(5);
        $kode_tabel = $this->uri->segment(6);
        $izin_pegawai = $this->izin_pegawai_model->find($kode_tabel);
        $ses_nip = isset($izin_pegawai->NIP_PNS) ? $izin_pegawai->NIP_PNS : "";
        Template::set('izin_pegawai', $izin_pegawai);

        $TAHUN      = trim(date("Y")." ");
        $jenis_izin = $this->jenis_izin_model->find($id);
        $nama_izin  = isset($jenis_izin->NAMA_IZIN) ? $jenis_izin->NAMA_IZIN : "";
        $keterangan_izin = isset($jenis_izin->KETERANGAN) ? $jenis_izin->KETERANGAN : "";
        $PERSETUJUAN      = isset($jenis_izin->PERSETUJUAN) ? $jenis_izin->PERSETUJUAN : "";
        
        if($id != ""){
            $this->sisa_cuti_model->where("TAHUN = '".$TAHUN."'");
            $data_cuti = $this->sisa_cuti_model->find_by("PNS_NIP",$ses_nip);
            Template::set('data_cuti',$data_cuti);    
        }
        $pegawai = $this->pegawai_model->find_detil_with_nip($ses_nip);
        $recpns_aktif = $this->Pns_aktif_model->find($pegawai->ID);
        Template::set("parent_path_array_unor",$this->unitkerja_model->get_parent_path($pegawai->UNOR_ID,true,true));

        $JABATAN_ID = $pegawai->JABATAN_INSTANSI_ID;
        $JABATAN_INSTANSI_REAL_ID = $pegawai->JABATAN_INSTANSI_REAL_ID;
        if($JABATAN_INSTANSI_REAL_ID != ""){
            $recjabatan = $this->jabatan_model->find_by("KODE_JABATAN",TRIM($JABATAN_INSTANSI_REAL_ID));
            Template::set('NAMA_JABATAN_REAL', $recjabatan->NAMA_JABATAN);
        }
        if($JABATAN_ID != ""){
            $recjabatan = $this->jabatan_model->find_by("KODE_JABATAN",TRIM($JABATAN_ID));
            Template::set('NAMA_JABATAN', $recjabatan->NAMA_JABATAN);
            Template::set('NAMA_JABATAN_BKN', $recjabatan->NAMA_JABATAN_BKN);
        }
        $foto_pegawai = trim($this->settings_lib->item('site.urlphoto'))."noimage.jpg";
        if(file_exists(trim($this->settings_lib->item('site.urlphoto')).$pegawai->PHOTO)){
            $foto_pegawai =  trim($this->settings_lib->item('site.urlphoto')).$pegawai->PHOTO;
        }
        Template::set('foto_pegawai', $foto_pegawai);
        // CEK DI TABEL UNITKERJA
        $unor = $this->unitkerja_model->find_by("ID",trim($pegawai->UNOR_ID));
        $unor_induk = $this->unitkerja_model->find_by("ID",$unor->UNOR_INDUK);
        $verifikasidata = $this->get_data_verifikasi_izin($izin_pegawai->ID);
        $adata_pejabat = $this->get_data_pejabat($ses_nip);

        $this->load->library('pdf');
        $this->pdf->load_view('izin/formpdf',array("izin_pegawai" => $izin_pegawai,"aatasan" => $adata_pejabat,"verifikasidata" => $verifikasidata,"pegawai" => $pegawai,"recjabatan" => $recjabatan,"unor_induk" => $unor_induk,"jenis_izin"=>$jenis_izin),true);
        // print_r($izin_pegawai);
        // die();
        // $output .= $this->load->view('izin/formpdf',array("izin_pegawai" => $izin_pegawai,"aatasan" => $adata_pejabat,"verifikasidata" => $verifikasidata,"pegawai" => $pegawai,"recjabatan" => $recjabatan,"unor_induk" => $unor_induk,"jenis_izin"=>$jenis_izin),true);   
         
        //echo $output;
        $this->pdf->render();
        ob_end_clean();
        $this->pdf->stream("formcuti.pdf", array("Attachment" => false));
        exit();
    }
    public function formpdfhtml()
    {
        //$this->auth->restrict($this->permissionVerifikasi);
        $this->load->model('pegawai/Pns_aktif_model');
        $this->load->model('pegawai/unitkerja_model');
        $this->load->model('ref_jabatan/jabatan_model');
        $id = $this->uri->segment(5);
        $kode_tabel = $this->uri->segment(6);
        $izin_pegawai = $this->izin_pegawai_model->find($kode_tabel);
        $ses_nip = isset($izin_pegawai->NIP_PNS) ? $izin_pegawai->NIP_PNS : "";
        Template::set('izin_pegawai', $izin_pegawai);

        $TAHUN      = trim(date("Y")." ");
        $jenis_izin = $this->jenis_izin_model->find($id);
        $nama_izin  = isset($jenis_izin->NAMA_IZIN) ? $jenis_izin->NAMA_IZIN : "";
        $keterangan_izin = isset($jenis_izin->KETERANGAN) ? $jenis_izin->KETERANGAN : "";
        $PERSETUJUAN      = isset($jenis_izin->PERSETUJUAN) ? $jenis_izin->PERSETUJUAN : "";
        
        if($id != ""){
            $this->sisa_cuti_model->where("TAHUN = '".$TAHUN."'");
            $data_cuti = $this->sisa_cuti_model->find_by("PNS_NIP",$ses_nip);
            Template::set('data_cuti',$data_cuti);    
        }
        $pegawai = $this->pegawai_model->find_detil_with_nip($ses_nip);
        $recpns_aktif = $this->Pns_aktif_model->find($pegawai->ID);
        Template::set("parent_path_array_unor",$this->unitkerja_model->get_parent_path($pegawai->UNOR_ID,true,true));

        $JABATAN_ID = $pegawai->JABATAN_INSTANSI_ID;
        $JABATAN_INSTANSI_REAL_ID = $pegawai->JABATAN_INSTANSI_REAL_ID;
        if($JABATAN_INSTANSI_REAL_ID != ""){
            $recjabatan = $this->jabatan_model->find_by("KODE_JABATAN",TRIM($JABATAN_INSTANSI_REAL_ID));
            Template::set('NAMA_JABATAN_REAL', $recjabatan->NAMA_JABATAN);
        }
        if($JABATAN_ID != ""){
            $recjabatan = $this->jabatan_model->find_by("KODE_JABATAN",TRIM($JABATAN_ID));
            Template::set('NAMA_JABATAN', $recjabatan->NAMA_JABATAN);
            Template::set('NAMA_JABATAN_BKN', $recjabatan->NAMA_JABATAN_BKN);
        }
        $foto_pegawai = trim($this->settings_lib->item('site.urlphoto'))."noimage.jpg";
        if(file_exists(trim($this->settings_lib->item('site.urlphoto')).$pegawai->PHOTO)){
            $foto_pegawai =  trim($this->settings_lib->item('site.urlphoto')).$pegawai->PHOTO;
        }
        Template::set('foto_pegawai', $foto_pegawai);
        // CEK DI TABEL UNITKERJA
        $unor = $this->unitkerja_model->find_by("ID",trim($pegawai->UNOR_ID));
        $unor_induk = $this->unitkerja_model->find_by("ID",$unor->UNOR_INDUK);
        $verifikasidata = $this->get_data_verifikasi_izin($izin_pegawai->ID);
        $adata_pejabat = $this->get_data_pejabat($ses_nip);

        $this->load->library('pdf');
        // $this->pdf->load_view('izin/formpdf',array("izin_pegawai" => $izin_pegawai,"aatasan" => $adata_pejabat,"verifikasidata" => $verifikasidata,"pegawai" => $pegawai,"recjabatan" => $recjabatan,"unor_induk" => $unor_induk,"jenis_izin"=>$jenis_izin),true);
        // print_r($izin_pegawai);
        // die();
        $output .= $this->load->view('izin/formpdf',array("izin_pegawai" => $izin_pegawai,"aatasan" => $adata_pejabat,"verifikasidata" => $verifikasidata,"pegawai" => $pegawai,"recjabatan" => $recjabatan,"unor_induk" => $unor_induk,"jenis_izin"=>$jenis_izin),true);   
         
        echo $output;
        // $this->pdf->render();
        // ob_end_clean();
        // $this->pdf->stream("formcuti.pdf", array("Attachment" => false));
        exit();
    }
    public function testgeneratepdf(){
        ob_start();
        ini_set('display_errors', 1);

        try {
            $this->load->library('pdf');
            
            //$this->pdf->load_view('izin/formpdf',true);
            // print_r($izin_pegawai);
            // die();
            $this->pdf->load_view('izin/formpdf',array(),true);   
             
            // echo $output;
            ob_end_clean();
            $this->pdf->render();
            $pdf_string =   $this->pdf->output();
        //echo $pdf_string;
            //echo $pdf_string;
            //$b64Doc = chunk_split(base64_encode($pdf_string));
            //$base_64pdf = "data:application/pdf;base64,".$b64Doc;
                file_put_contents("test.pdf", $pdf_string ); 
                // update table
                
            //ob_end_clean();
            $this->pdf->stream("formcuti.pdf", array("Attachment" => false));
        } catch(Exception $e) {
            print_r($e);
        }

        
        exit();   
    }
    public function edit1()
    {
        $id = $this->uri->segment(5);
        if (empty($id)) {
            Template::set_message(lang('izin_pegawai_invalid_id'), 'error');

            redirect(SITE_AREA . '/izin/izin_pegawai');
        }
        
        if (isset($_POST['save'])) {
            $this->auth->restrict($this->permissionEdit);

            if ($this->save_izin_pegawai('update', $id)) {
                log_activity($this->auth->user_id(), lang('izin_pegawai_act_edit_record') . ': ' . $id . ' : ' . $this->input->ip_address(), 'izin_pegawai');
                Template::set_message(lang('izin_pegawai_edit_success'), 'success');
                redirect(SITE_AREA . '/izin/izin_pegawai');
            }

            // Not validation error
            if ( ! empty($this->izin_pegawai_model->error)) {
                Template::set_message(lang('izin_pegawai_edit_failure') . $this->izin_pegawai_model->error, 'error');
            }
        }
        
        elseif (isset($_POST['delete'])) {
            $this->auth->restrict($this->permissionDelete);

            if ($this->izin_pegawai_model->delete($id)) {
                log_activity($this->auth->user_id(), lang('izin_pegawai_act_delete_record') . ': ' . $id . ' : ' . $this->input->ip_address(), 'izin_pegawai');
                Template::set_message(lang('izin_pegawai_delete_success'), 'success');

                redirect(SITE_AREA . '/izin/izin_pegawai');
            }

            Template::set_message(lang('izin_pegawai_delete_failure') . $this->izin_pegawai_model->error, 'error');
        }
        
        Template::set('izin_pegawai', $this->izin_pegawai_model->find($id));

        Template::set('toolbar_title', lang('izin_pegawai_edit_heading'));
        Template::render();
    }

    //--------------------------------------------------------------------------
    // !PRIVATE METHODS
    //--------------------------------------------------------------------------

    /**
     * Save the data.
     *
     * @param string $type Either 'insert' or 'update'.
     * @param int    $id   The ID of the record to update, ignored on inserts.
     *
     * @return boolean|integer An ID for successful inserts, true for successful
     * updates, else false.
     */
    private function save_izin_pegawai($type = 'insert', $id = 0)
    {
        if ($type == 'update') {
            $_POST['ID'] = $id;
        }

        // Validate the data
        $this->form_validation->set_rules($this->izin_pegawai_model->get_validation_rules());
        if ($this->form_validation->run() === false) {
            return false;
        }

        // Make sure we only pass in the fields we want
        
        $data = $this->izin_pegawai_model->prep_data($this->input->post());

        // Additional handling for default values should be added below,
        // or in the model's prep_data() method
        
        $data['DARI_TANGGAL']   = $this->input->post('DARI_TANGGAL') ? $this->input->post('DARI_TANGGAL') : '0000-00-00';
        $data['SAMPAI_TANGGAL'] = $this->input->post('SAMPAI_TANGGAL') ? $this->input->post('SAMPAI_TANGGAL') : '0000-00-00';
        $data['TGL_DIBUAT'] = $this->input->post('TGL_DIBUAT') ? $this->input->post('TGL_DIBUAT') : '0000-00-00';

        $return = false;
        if ($type == 'insert') {
            $id = $this->izin_pegawai_model->insert($data);

            if (is_numeric($id)) {
                $return = $id;
            }
        } elseif ($type == 'update') {
            $return = $this->izin_pegawai_model->update($id, $data);
        }

        return $return;
    }
    // List izin untuk pegawai
    public function getdata_izin(){
        $this->auth->restrict($this->permissionView);
        $this->load->library('Convert');
        $convert = new Convert;
        $this->load->helper('dikbud');
        if (!$this->input->is_ajax_request()) {
            Template::set_message("Hanya request ajax", 'error');
            redirect(SITE_AREA . '/izin/izin_pegawai');
        }
        $ses_nip    = trim($this->auth->username());
        $draw = $this->input->post('draw');
        $iSortCol = $this->input->post('iSortCol_1');
        $sSortCol = $this->input->post('sSortDir_1');
        
        $length= $this->input->post('length') != "" ? $this->input->post('length') : 10;
        $start= $this->input->post('start') != "" ? $this->input->post('start') : 0;

        $search = isset($_REQUEST['search']["value"]) ? $_REQUEST['search']["value"] : "";
        $searchKey = isset($_REQUEST['search']["key"]) ? $_REQUEST['search']["key"] : "";

        $selectedUnors = array();
        $advanced_search_filters  = $this->input->post("search[advanced_search_filters]");
        if($advanced_search_filters){
            $filters = array();
            foreach($advanced_search_filters as  $filter){
                $filters[$filter['name']] = $filter["value"];
            }
            
        }

        $this->db->start_cache();
        
        /*Jika $search mengandung nilai, berarti user sedang telah 
        memasukan keyword didalam filed pencarian*/
        $advanced_search_filters  = $this->input->post("search[advanced_search_filters]");
        if($advanced_search_filters){
            $filters = array();
            foreach($advanced_search_filters as  $filter){
                $filters[$filter['name']] = $filter["value"];
            }
             
            if($filters['nama_key']){
                $this->izin_pegawai_model->like('upper("NAMA")',strtoupper(trim($filters['nama_key'])),"BOTH"); 
            }
            if($filters['nip_key']){
                $this->izin_pegawai_model->where("NIP_PNS",trim($filters['nip_key']));  
            }
            if($filters['STATUS_ATASAN']){
                $this->izin_pegawai_model->where('STATUS_PYBMC',trim($filters['STATUS_ATASAN'])); 
            }
        }
        
        $this->db->stop_cache();
        $output=array();
        $output['draw']=$draw;
        $total= $this->izin_pegawai_model->count_all_pegawai($ses_nip);
        $orders = $this->input->post('order');
        foreach($orders as $order){
            if($order['column']==1){
                $this->izin_pegawai_model->order_by("NIP_PNS",$order['dir']);
            }
            if($order['column']==2){
                $this->izin_pegawai_model->order_by("NAMA",$order['dir']);
            }
            if($order['column']==3){
                $this->izin_pegawai_model->order_by("TAHUN",$order['dir']);
            }
            if($order['column']==4){
                $this->izin_pegawai_model->order_by("SISA",$order['dir']);
            }
        }
        $output['recordsTotal']= $output['recordsFiltered']=$total;
        $output['data']=array();
        
        $this->izin_pegawai_model->limit($length,$start);
        $records=$this->izin_pegawai_model->find_all_pegawai($ses_nip);
        $this->db->flush_cache();
        $nomor_urut=$start+1;
        if(isset($records) && is_array($records) && count($records)):
            foreach ($records as $record) {
                $row = array();

                $STATUS_ATASAN = "";
                $kode_izin = $record->KODE_IZIN;
                if($record->STATUS_ATASAN != ""){
                    $STATUS_ATASAN = "<br>".get_status_cuti($record->STATUS_ATASAN);
                }
                $CATATAN_ATASAN = "";
                if($record->CATATAN_ATASAN != ""){
                    $CATATAN_ATASAN = "<br><i>".$record->CATATAN_ATASAN."</i>";
                }
                $STATUS_PYBMC = "";
                if($record->STATUS_PYBMC != ""){
                    $STATUS_PYBMC = "<br>".get_status_cuti($record->STATUS_PYBMC);
                }

                $STATUS_PENGAJUAN = get_status_cuti($record->STATUS_PENGAJUAN);
                $CATATAN_PYBMC = "";
                if($record->CATATAN_PYBMC != ""){
                    $CATATAN_PYBMC = "<br><i>".$record->CATATAN_PYBMC."</i>";
                }
                $row []  = $nomor_urut.".";
                $row []  = $record->NAMA_IZIN;
                $row []  = $convert->fmtDate($record->TGL_DIBUAT,"dd month yyyy");
                $row []  = $convert->fmtDate($record->DARI_TANGGAL,"dd month yyyy")." s/d ".$convert->fmtDate($record->SAMPAI_TANGGAL,"dd month yyyy")."<br>".$record->JUMLAH." ".$record->SATUAN;
                //$row []  = $record->NAMA_ATASAN.$STATUS_ATASAN.$CATATAN_ATASAN;
                //$row []  = $record->NAMA_PYBMC.$STATUS_PYBMC.$CATATAN_PYBMC;
                if($record->KODE_IZIN == "11"){
                    $row []  = $record->ALASAN_CUTI."<br><i>".$record->KETERANGAN."<br><i>Dari jam ".$record->SELAMA_JAM." - ".$record->SELAMA_MENIT."</i>";
                }else{
                    $row []  = $record->ALASAN_CUTI."<br><i>".$record->KETERANGAN;    
                }
                $row []  = $STATUS_PENGAJUAN.$CATATAN_PYBMC;
                $btn_actions = array();
                //$btn_actions  [] = "<a href='".base_url()."admin/izin/izin_pegawai/lineaproval/".$record->KODE_IZIN."/".$record->ID."' class='btn btn-sm btn-warning show-modal' tooltip='Lihat status Persetujuan ".$record->NAMA_IZIN."' title='Lihat status Persetujuan' data-toggle='tooltip' data-placement='top' title='Lihat status Persetujuan'><i class='fa fa-info-circle'></i> </a>";  
                if($kode_izin != "7" and $kode_izin != "8" and $kode_izin != "9" and $kode_izin != "10" and $kode_izin != "11"){
                    $btn_actions  [] = "<a url='".base_url()."admin/izin/izin_pegawai/formpdf/".$record->KODE_IZIN."/".$record->ID."' class='btn btn-sm btn-info popup' data-toggle='tooltip' data-placement='top' title='Dokumen Cuti'><i class='glyphicon glyphicon-file'></i> </a>";  
                }
                if($record->LAMPIRAN_FILE != ""){
                    $btn_actions  [] = "<a url='".base_url()."admin/izin/izin_pegawai/viewdoc/".$record->ID."' class='btn btn-sm btn-success popup' data-toggle='tooltip' data-placement='top' title='Lihat Lampiran'><i class='glyphicon glyphicon-paperclip'></i> </a>";  
                }
                
                if($this->auth->has_permission($this->permissionEdit)){
                    $btn_actions  [] = "<a href='".base_url()."admin/izin/izin_pegawai/edit/".$record->KODE_IZIN."/".$record->ID."' class='btn btn-sm btn-warning show-modal' tooltip='Edit Permintaan Izin ".$record->NAMA_IZIN."' title='Edit Permintaan Cuti' data-toggle='tooltip' data-placement='top' title='Edit data'><i class='glyphicon glyphicon-edit'></i> </a>";  
                }
                
                if($this->auth->has_permission($this->permissionDelete)){
                    $btn_actions  [] = "<a kode='$record->ID' class='btn btn-sm btn-danger btn-hapus' data-toggle='tooltip' data-placement='top' data-original-title='Hapus data' title='Hapus data' tooltip='Hapus'><i class='glyphicon glyphicon-remove'></i> </a>";
                }
                $row[] = "<div class='btn-group'>".implode(" ",$btn_actions)."</div>";
                $output['data'][] = $row;
                $nomor_urut++;
            }
        endif;
        echo json_encode($output);        
    }
    public function getdata_izin_all(){
        $this->auth->restrict($this->permissionView);
        $this->load->helper('dikbud');
        if (!$this->input->is_ajax_request()) {
            Template::set_message("Hanya request ajax", 'error');
            redirect(SITE_AREA . '/izin/izin_pegawai');
        }
        $draw = $this->input->post('draw');
        $iSortCol = $this->input->post('iSortCol_1');
        $sSortCol = $this->input->post('sSortDir_1');
        
        $length= $this->input->post('length') != "" ? $this->input->post('length') : 10;
        $start= $this->input->post('start') != "" ? $this->input->post('start') : 0;

        $search = isset($_REQUEST['search']["value"]) ? $_REQUEST['search']["value"] : "";
        $searchKey = isset($_REQUEST['search']["key"]) ? $_REQUEST['search']["key"] : "";

        $selectedUnors = array();
        $advanced_search_filters  = $this->input->post("search[advanced_search_filters]");
        if($advanced_search_filters){
            $filters = array();
            foreach($advanced_search_filters as  $filter){
                $filters[$filter['name']] = $filter["value"];
            }
            
        }

        $this->db->start_cache();
        
        /*Jika $search mengandung nilai, berarti user sedang telah 
        memasukan keyword didalam filed pencarian*/
        $advanced_search_filters  = $this->input->post("search[advanced_search_filters]");
        if($advanced_search_filters){
            $filters = array();
            foreach($advanced_search_filters as  $filter){
                $filters[$filter['name']] = $filter["value"];
            }
             
            if($filters['nama_key']){
                $this->izin_pegawai_model->like('upper("pegawai"."NAMA")',strtoupper(trim($filters['nama_key'])),"BOTH"); 
            }
            if($filters['nip_key']){
                $this->izin_pegawai_model->where("NIP_PNS",trim($filters['nip_key']));  
            }
            if($filters['STATUS_ATASAN']){
                $this->izin_pegawai_model->where("STATUS_ATASAN",trim($filters['STATUS_ATASAN']));  
            }
            if($filters['STATUS_PYBMC']){
                $this->izin_pegawai_model->where("STATUS_PYBMC",trim($filters['STATUS_PYBMC']));  
            }
        }
        
        $this->db->stop_cache();
        $output=array();
        $output['draw']=$draw;
        $total= $this->izin_pegawai_model->count_all_unit($this->UNOR_ID);
        $orders = $this->input->post('order');
        foreach($orders as $order){
            if($order['column']==1){
                $this->izin_pegawai_model->order_by("NIP_PNS",$order['dir']);
            }
            if($order['column']==2){
                $this->izin_pegawai_model->order_by("NAMA",$order['dir']);
            }
            if($order['column']==3){
                $this->izin_pegawai_model->order_by("TAHUN",$order['dir']);
            }
            if($order['column']==4){
                $this->izin_pegawai_model->order_by("SISA",$order['dir']);
            }
        }
        $output['recordsTotal']= $output['recordsFiltered']=$total;
        $output['data']=array();
        
        $this->izin_pegawai_model->limit($length,$start);
        $records=$this->izin_pegawai_model->find_all_unit($this->UNOR_ID);
        $this->db->flush_cache();
        $nomor_urut=$start+1;
        if(isset($records) && is_array($records) && count($records)):
            foreach ($records as $record) {
                $row = array();
                $STATUS_ATASAN = "";
                if($record->STATUS_ATASAN != ""){
                    $STATUS_ATASAN = "<br>".get_status_cuti($record->STATUS_ATASAN);
                }
                $CATATAN_ATASAN = "";
                if($record->CATATAN_ATASAN != ""){
                    $CATATAN_ATASAN = "<br><i>".$record->CATATAN_ATASAN."</i>";
                }
                $STATUS_PYBMC = "";
                if($record->STATUS_PYBMC != ""){
                    $STATUS_PYBMC = "<br>".get_status_cuti($record->STATUS_PYBMC);
                }
                $CATATAN_PYBMC = "";
                if($record->CATATAN_PYBMC != "" and $record->STATUS_PYBMC != 2){
                    $CATATAN_PYBMC = "<br>Catatan : <i>".$record->CATATAN_PYBMC."</i>";
                }
                $row []  = $nomor_urut.".";
                if(file_exists(trim($this->settings_lib->item('site.pathphoto')).$record->PHOTO) and $record->PHOTO != ""){
                    $foto_pegawai =  trim($this->settings_lib->item('site.urlphoto')).$record->PHOTO;
                    $row []  = "<img src='".$foto_pegawai."' width='80xp' class='profile-userpic'/>";
                }
                else{
                    $row []  = "<img src='".base_url()."assets/images/noimage.jpg' width='80xp' class='profile-userpic'/>";
                }

                $row []  = $record->NIP_PNS."<br><i>".$record->NAMA."</i>";
                $row []  = $record->NAMA_IZIN."<br>".$record->KETERANGAN;
                $row []  = $record->DARI_TANGGAL." s/d ".$record->SAMPAI_TANGGAL;
                //$row []  = $record->NAMA_ATASAN.$STATUS_ATASAN.$CATATAN_ATASAN;
                $row []  = $STATUS_PYBMC.$CATATAN_PYBMC;
                //$row []  = $record->KETERANGAN;
                $btn_actions = array();
                if($record->LAMPIRAN_FILE != ""){
                    $btn_actions  [] = "<a url='".base_url()."admin/izin/izin_pegawai/viewdoc/".$record->ID."' class='btn btn-sm btn-success popup' data-toggle='tooltip' data-placement='top' title='Lihat Lampiran'><i class='glyphicon glyphicon-paperclip'></i> </a>";  
                }
                if($this->auth->has_permission($this->permissionEdit)){
                    $btn_actions  [] = "<a href='".base_url()."admin/izin/izin_pegawai/verifikasipybmc/".$record->KODE_IZIN."/".$record->ID."' class='btn btn-sm btn-warning show-modal' tooltip='Edit Permintaan Cuti' data-toggle='tooltip' data-placement='top' title='Edit data'><i class='glyphicon glyphicon-edit'></i> </a>";  
                }
                if($this->auth->has_permission($this->permissionDelete)){
                    $btn_actions  [] = "<a kode='$record->ID' class='btn btn-sm btn-danger btn-hapus' data-toggle='tooltip' data-placement='top' data-original-title='Hapus data' title='Hapus data' tooltip='Hapus'><i class='glyphicon glyphicon-remove'></i> </a>";
                }
                $row[] = "<div class='btn-group'>".implode(" ",$btn_actions)."</div>";
                $output['data'][] = $row;
                $nomor_urut++;
            }
        endif;
        echo json_encode($output);        
    }
    //satker
    public function getdata_izin_satker(){
        $this->auth->restrict($this->permissionView);
        $UNIT_KERJA = $this->pegawai_model->getunor_induk($this->auth->username());
        $this->load->helper('dikbud');
        if (!$this->input->is_ajax_request()) {
            Template::set_message("Hanya request ajax", 'error');
            redirect(SITE_AREA . '/izin/izin_pegawai');
        }
        $draw = $this->input->post('draw');
        $iSortCol = $this->input->post('iSortCol_1');
        $sSortCol = $this->input->post('sSortDir_1');
        
        $length= $this->input->post('length') != "" ? $this->input->post('length') : 10;
        $start= $this->input->post('start') != "" ? $this->input->post('start') : 0;

        $search = isset($_REQUEST['search']["value"]) ? $_REQUEST['search']["value"] : "";
        $searchKey = isset($_REQUEST['search']["key"]) ? $_REQUEST['search']["key"] : "";

        $selectedUnors = array();
        $advanced_search_filters  = $this->input->post("search[advanced_search_filters]");
        if($advanced_search_filters){
            $filters = array();
            foreach($advanced_search_filters as  $filter){
                $filters[$filter['name']] = $filter["value"];
            }
            
        }

        $this->db->start_cache();
        
        /*Jika $search mengandung nilai, berarti user sedang telah 
        memasukan keyword didalam filed pencarian*/
        $advanced_search_filters  = $this->input->post("search[advanced_search_filters]");
        if($advanced_search_filters){
            $filters = array();
            foreach($advanced_search_filters as  $filter){
                $filters[$filter['name']] = $filter["value"];
            }
             
            if($filters['nama_key']){
                $this->izin_pegawai_model->like('upper("NAMA")',strtoupper(trim($filters['nama_key'])),"BOTH"); 
            }
            if($filters['nip_key']){
                $this->izin_pegawai_model->where("NIP_PNS",trim($filters['nip_key']));  
            }
            if($filters['STATUS_ATASAN']){
                $this->izin_pegawai_model->where("STATUS_ATASAN",trim($filters['STATUS_ATASAN']));  
            }
            if($filters['STATUS_PYBMC']){
                $this->izin_pegawai_model->where("STATUS_PYBMC",trim($filters['STATUS_PYBMC']));  
            }
        }
        
        $this->db->stop_cache();
        $output=array();
        $output['draw']=$draw;
        $total= $this->izin_pegawai_model->count_all_satker($UNIT_KERJA);
        $orders = $this->input->post('order');
        foreach($orders as $order){
            if($order['column']==1){
                $this->izin_pegawai_model->order_by("NIP_PNS",$order['dir']);
            }
            if($order['column']==2){
                $this->izin_pegawai_model->order_by("NAMA",$order['dir']);
            }
            if($order['column']==3){
                $this->izin_pegawai_model->order_by("TAHUN",$order['dir']);
            }
            if($order['column']==4){
                $this->izin_pegawai_model->order_by("SISA",$order['dir']);
            }
        }
        $output['recordsTotal']= $output['recordsFiltered']=$total;
        $output['data']=array();
        
        $this->izin_pegawai_model->limit($length,$start);
        $records=$this->izin_pegawai_model->find_all_satker($UNIT_KERJA);
        $this->db->flush_cache();
        $nomor_urut=$start+1;
        if(isset($records) && is_array($records) && count($records)):
            foreach ($records as $record) {
                $row = array();
                $STATUS_ATASAN = "";
                if($record->STATUS_ATASAN != ""){
                    $STATUS_ATASAN = "<br>".get_status_cuti($record->STATUS_ATASAN);
                }
                $CATATAN_ATASAN = "";
                if($record->CATATAN_ATASAN != ""){
                    $CATATAN_ATASAN = "<br><i>".$record->CATATAN_ATASAN."</i>";
                }
                $STATUS_PYBMC = "";
                if($record->STATUS_PYBMC != ""){
                    $STATUS_PYBMC = "<br>".get_status_cuti($record->STATUS_PYBMC);
                }
                $CATATAN_PYBMC = "";
                if($record->CATATAN_ATASAN != ""){
                    $CATATAN_PYBMC = "<br><i>".$record->CATATAN_PYBMC."</i>";
                }
                $row []  = $nomor_urut.".";
                $row []  = $record->NIP_PNS."<br><i>".$record->NAMA."</i>";
                $row []  = $record->NAMA_IZIN;
                $row []  = $record->DARI_TANGGAL."-".$record->SAMPAI_TANGGAL;
                $row []  = $record->NAMA_ATASAN.$STATUS_ATASAN.$CATATAN_ATASAN;
                $row []  = $record->NAMA_PYBMC.$STATUS_PYBMC.$CATATAN_PYBMC;
                $row []  = $record->KETERANGAN;
                $btn_actions = array();
                if($record->LAMPIRAN_FILE != ""){
                    $btn_actions  [] = "<a url='".trim($this->settings_lib->item('site.urllampiranizin')).$record->LAMPIRAN_FILE."' class='btn btn-sm btn-success popup' data-toggle='tooltip' data-placement='top' title='Lihat Lampiran'><i class='fa fa-paperclip'></i> </a>";  
                }
                if($this->auth->has_permission($this->permissionEdit)){
                    $btn_actions  [] = "<a href='".base_url()."admin/izin/izin_pegawai/edit/".$record->KODE_IZIN."/".$record->ID."' class='btn btn-sm btn-warning' tooltip='Edit Permintaan Cuti' data-toggle='tooltip' data-placement='top' title='Edit data'><i class='glyphicon glyphicon-edit'></i> </a>";  
                }
                if($this->auth->has_permission($this->permissionDelete)){
                    $btn_actions  [] = "<a kode='$record->ID' class='btn btn-sm btn-danger btn-hapus' data-toggle='tooltip' data-placement='top' data-original-title='Hapus data' title='Hapus data' tooltip='Hapus'><i class='glyphicon glyphicon-remove'></i> </a>";
                }
                $row[] = "<div class='btn-group'>".implode(" ",$btn_actions)."</div>";
                $output['data'][] = $row;
                $nomor_urut++;
            }
        endif;
        echo json_encode($output);        
    }
    public function getdata_verifikasi_izin(){
        $this->auth->restrict($this->permissionVerifikasi);
        $ses_nip    = trim($this->auth->username());
        $this->load->helper('dikbud');
        if (!$this->input->is_ajax_request()) {
            // Template::set_message("Hanya request ajax", 'error');
            // redirect(SITE_AREA . '/izin/izin_pegawai');
        }
        $draw = $this->input->post('draw');
        $iSortCol = $this->input->post('iSortCol_1');
        $sSortCol = $this->input->post('sSortDir_1');
        
        $length= $this->input->post('length') != "" ? $this->input->post('length') : 10;
        $start= $this->input->post('start') != "" ? $this->input->post('start') : 0;

        $search = isset($_REQUEST['search']["value"]) ? $_REQUEST['search']["value"] : "";
        $searchKey = isset($_REQUEST['search']["key"]) ? $_REQUEST['search']["key"] : "";

        $selectedUnors = array();
        $advanced_search_filters  = $this->input->post("search[advanced_search_filters]");
        if($advanced_search_filters){
            $filters = array();
            foreach($advanced_search_filters as  $filter){
                $filters[$filter['name']] = $filter["value"];
            }
            
        }

        $this->db->start_cache();
        
        /*Jika $search mengandung nilai, berarti user sedang telah 
        memasukan keyword didalam filed pencarian*/
        $advanced_search_filters  = $this->input->post("search[advanced_search_filters]");
        if($advanced_search_filters){
            $filters = array();
            foreach($advanced_search_filters as  $filter){
                $filters[$filter['name']] = $filter["value"];
            }
             
            if($filters['nama_key']){
                $this->izin_pegawai_model->like('upper("NAMA")',strtoupper(trim($filters['nama_key'])),"BOTH"); 
            }
            if($filters['nip_key']){
                $this->izin_pegawai_model->where("NIP_PNS",trim($filters['nip_key']));  
            }
            if($filters['STATUS']){
                $this->izin_pegawai_model->where("STATUS_PENGAJUAN",trim($filters['STATUS']));  
            }
            
        }
        
        $this->db->stop_cache();
        $output=array();
        $output['draw']=$draw;
        $total= $this->izin_pegawai_model->count_all_atasan($ses_nip);
        $orders = $this->input->post('order');
        foreach($orders as $order){
            if($order['column']==2){
                $this->izin_pegawai_model->order_by("NIP_PNS",$order['dir']);
            }
            if($order['column']==3){
                $this->izin_pegawai_model->order_by("KODE_IZIN",$order['dir']);
            }
            if($order['column']==4){
                $this->izin_pegawai_model->order_by("DARI_TANGGAL",$order['dir']);
            }
            
            if($order['column']==6){
                $this->izin_pegawai_model->order_by("STATUS_VERIFIKASI",$order['dir']);
            }
             
        }
        $output['recordsTotal']= $output['recordsFiltered']=$total;
        $output['data']=array();
        
        $this->izin_pegawai_model->limit($length,$start);
        $records=$this->izin_pegawai_model->find_all_atasan($ses_nip);
        $this->db->flush_cache();
        $nomor_urut=$start+1;
        if(isset($records) && is_array($records) && count($records)):
            foreach ($records as $record) {
                $foto_pegawai = base_url().trim($this->settings_lib->item('site.urlphoto'))."noimage.jpg";
                if(file_exists(trim($this->settings_lib->item('site.urlphoto')).$record->PHOTO) and $record->PHOTO != ""){
                    $foto_pegawai =  base_url().trim($this->settings_lib->item('site.urlphoto')).$record->PHOTO;
                }
                $row = array();
                $STATUS_ATASAN = "";
                if($record->STATUS_ATASAN != ""){
                    $STATUS_ATASAN = "<br>".get_status_cuti($record->STATUS_ATASAN);
                }
                $CATATAN_ATASAN = "";
                if($record->CATATAN_ATASAN != ""){
                    $CATATAN_ATASAN = "<br><i>".$record->CATATAN_ATASAN."</i>";
                }
                $STATUS_PYBMC = "";
                if($record->STATUS_PYBMC != ""){
                    $STATUS_PYBMC = "<br>".get_status_cuti($record->STATUS_PYBMC);
                }
                $CATATAN_PYBMC = "";
                if($record->CATATAN_ATASAN != ""){
                    $CATATAN_PYBMC = "<br><i>".$record->CATATAN_PYBMC."</i>";
                }
                $STATUS_PENGAJUAN = get_status_cuti($record->STATUS_PENGAJUAN);
                $row []  = $nomor_urut.".";
                $row []  = "<img src='".$foto_pegawai."' width='100%'>";
                $row []  = $record->NIP_PNS."<br><i>".$record->NAMA."</i>";
                $row []  = $record->NAMA_IZIN."<br><i>".$record->JUMLAH." ".$record->SATUAN."</i>";
                $row []  = $record->DARI_TANGGAL."<br>s/d<br>".$record->SAMPAI_TANGGAL;
                //$row []  = $record->NAMA_ATASAN.$STATUS_ATASAN.$CATATAN_ATASAN;
                //$row []  = $record->NAMA_PYBMC.$STATUS_PYBMC.$CATATAN_PYBMC;
                $row []  = $record->KETERANGAN;
                $row []  = $STATUS_PENGAJUAN;
                $btn_actions = array();
                if($this->auth->has_permission($this->permissionVerifikasi)){
                    $btn_actions  [] = "<a href='".base_url()."admin/izin/izin_pegawai/verifikasiusulan/".$record->KODE_IZIN."/".$record->ID_VERIFIKASI."' class='btn btn-sm btn-success show-modal' tooltip='Verifikasi Permintaan Izin' data-toggle='tooltip' data-placement='top' title='Verifikasi Permintaan Izin'><i class='glyphicon glyphicon-pencil'></i> </a>";  
                }
                $btn_actions  [] = "<a href='".base_url()."admin/izin/izin_pegawai/lineaproval/".$record->KODE_IZIN."/".$record->ID."' class='btn btn-sm btn-warning show-modal' tooltip='Line Approval ".$record->NAMA_IZIN."' title='Line Approval' data-toggle='tooltip' data-placement='top' title='Line Approval'><i class='fa fa-info-circle'></i> </a>";  
                if($record->LAMPIRAN_FILE != ""){
                    $btn_actions  [] = "<a url='".trim($this->settings_lib->item('site.urllampiranizin')).$record->LAMPIRAN_FILE."' class='btn btn-sm btn-info popup' data-toggle='tooltip' data-placement='top' title='Lihat Lampiran'><i class='fa fa-paperclip'></i> </a>";  
                }
                if($record->ID != ""){
                    $btn_actions  [] = "<a url='".base_url()."admin/izin/izin_pegawai/formpdf/".$record->KODE_IZIN."/".$record->ID."' class='btn btn-sm btn-danger popup' data-toggle='tooltip' data-placement='top' title='Lihat Dokumen cuti'><i class='glyphicon glyphicon-open-file'></i> </a>";  
                }
                 
                $row[] = "<div class='btn-group'>".implode(" ",$btn_actions)."</div>";
                $output['data'][] = $row;
                $nomor_urut++;
            }
        endif;
        echo json_encode($output);        
    }
    public function getdata_pybmc(){
        $this->auth->restrict($this->permissionPybmc);
        $ses_nip    = trim($this->auth->username());
        $this->load->helper('dikbud');
        if (!$this->input->is_ajax_request()) {
            Template::set_message("Hanya request ajax", 'error');
            redirect(SITE_AREA . '/izin/izin_pegawai/pybmc');
        }
        $draw = $this->input->post('draw');
        $iSortCol = $this->input->post('iSortCol_1');
        $sSortCol = $this->input->post('sSortDir_1');
        
        $length= $this->input->post('length') != "" ? $this->input->post('length') : 10;
        $start= $this->input->post('start') != "" ? $this->input->post('start') : 0;

        $search = isset($_REQUEST['search']["value"]) ? $_REQUEST['search']["value"] : "";
        $searchKey = isset($_REQUEST['search']["key"]) ? $_REQUEST['search']["key"] : "";

        $selectedUnors = array();
        $advanced_search_filters  = $this->input->post("search[advanced_search_filters]");
        if($advanced_search_filters){
            $filters = array();
            foreach($advanced_search_filters as  $filter){
                $filters[$filter['name']] = $filter["value"];
            }
            
        }

        $this->db->start_cache();
        
        /*Jika $search mengandung nilai, berarti user sedang telah 
        memasukan keyword didalam filed pencarian*/
        $advanced_search_filters  = $this->input->post("search[advanced_search_filters]");
        if($advanced_search_filters){
            $filters = array();
            foreach($advanced_search_filters as  $filter){
                $filters[$filter['name']] = $filter["value"];
            }
             
            if($filters['nama_key']){
                $this->izin_pegawai_model->like('upper("NAMA")',strtoupper(trim($filters['nama_key'])),"BOTH"); 
            }
            if($filters['nip_key']){
                $this->izin_pegawai_model->where("NIP_PNS",trim($filters['nip_key']));  
            }
        }
        
        $this->db->stop_cache();
        $output=array();
        $output['draw']=$draw;
        $total= $this->izin_pegawai_model->count_all_ppk($ses_nip);
        $orders = $this->input->post('order');
        foreach($orders as $order){
            if($order['column']==2){
                $this->izin_pegawai_model->order_by("NIP_PNS",$order['dir']);
            }
            if($order['column']==3){
                $this->izin_pegawai_model->order_by("KODE_IZIN",$order['dir']);
            }
            if($order['column']==4){
                $this->izin_pegawai_model->order_by("DARI_TANGGAL",$order['dir']);
            }
            if($order['column']==5){
                $this->izin_pegawai_model->order_by("NIP_ATASAN",$order['dir']);
            }
            if($order['column']==6){
                $this->izin_pegawai_model->order_by("NIP_PYBMC",$order['dir']);
            }
            if($order['column']==7){
                $this->izin_pegawai_model->order_by("KETERANGAN",$order['dir']);
            }
        }
        $output['recordsTotal']= $output['recordsFiltered']=$total;
        $output['data']=array();
        
        $this->izin_pegawai_model->limit($length,$start);
        $records=$this->izin_pegawai_model->find_all_ppk($ses_nip);
        $this->db->flush_cache();
        $nomor_urut=$start+1;
        if(isset($records) && is_array($records) && count($records)):
            foreach ($records as $record) {
                $foto_pegawai = base_url().trim($this->settings_lib->item('site.urlphoto'))."noimage.jpg";
                if(file_exists(trim($this->settings_lib->item('site.urlphoto')).$record->PHOTO) and $record->PHOTO != ""){
                    $foto_pegawai =  base_url().trim($this->settings_lib->item('site.urlphoto')).$record->PHOTO;
                }
                $row = array();
                $STATUS_ATASAN = "";
                if($record->STATUS_ATASAN != ""){
                    $STATUS_ATASAN = "<br>".get_status_cuti($record->STATUS_ATASAN);
                }
                $CATATAN_ATASAN = "";
                if($record->CATATAN_ATASAN != ""){
                    $CATATAN_ATASAN = "<br><i>".$record->CATATAN_ATASAN."</i>";
                }
                $STATUS_PYBMC = "";
                if($record->STATUS_PYBMC != ""){
                    $STATUS_PYBMC = "<br>".get_status_cuti($record->STATUS_PYBMC);
                }
                $CATATAN_PYBMC = "";
                if($record->CATATAN_ATASAN != ""){
                    $CATATAN_PYBMC = "<br><i>".$record->CATATAN_PYBMC."</i>";
                }
                $row []  = $nomor_urut.".";
                $row []  = "<img src='".$foto_pegawai."' width='100%'>";
                $row []  = $record->NIP_PNS."<br><i>".$record->NAMA."</i>";
                $row []  = $record->NAMA_IZIN."<br><i>".$record->JUMLAH." ".$record->SATUAN."</i>";
                $row []  = $record->DARI_TANGGAL."-".$record->SAMPAI_TANGGAL;
                $row []  = $record->NAMA_ATASAN.$STATUS_ATASAN.$CATATAN_ATASAN;
                $row []  = $record->NAMA_PYBMC.$STATUS_PYBMC.$CATATAN_PYBMC;
                if($record->KODE_IZIN == "11"){
                    $row []  = $record->KETERANGAN."<br><i>Dari jam ".$record->SELAMA_JAM." - ".$record->SELAMA_MENIT."</i>";
                }else{
                    $row []  = $record->KETERANGAN;    
                }
                
                $btn_actions = array();
                if($record->ID != ""){
                    $btn_actions  [] = "<a url='".base_url()."admin/izin/izin_pegawai/formpdf/".$record->KODE_IZIN."/".$record->ID."' class='btn btn-sm btn-danger popup' data-toggle='tooltip' data-placement='top' title='Lihat Dokumen cuti'><i class='glyphicon glyphicon-open-file'></i> </a>";  
                }
                if($record->LAMPIRAN_FILE != ""){
                    $btn_actions  [] = "<a url='".trim($this->settings_lib->item('site.urllampiranizin')).$record->LAMPIRAN_FILE."' class='btn btn-sm btn-success popup' data-toggle='tooltip' data-placement='top' title='Lihat Lampiran'><i class='fa fa-paperclip'></i> </a>";  
                }
                if($this->auth->has_permission($this->permissionPybmc)){
                    $btn_actions  [] = "<a href='".base_url()."admin/izin/izin_pegawai/verifikasipybmc/".$record->KODE_IZIN."/".$record->ID."' class='btn btn-sm btn-warning show-modal' tooltip='Persetujuan Izin' data-toggle='tooltip' data-placement='top' title='Persetujuan Permintaan Izin'><i class='glyphicon glyphicon-pencil'></i> </a>";  
                }
                 
                $row[] = "<div class='btn-group'>".implode(" ",$btn_actions)."</div>";
                $output['data'][] = $row;
                $nomor_urut++;
            }
        endif;
        echo json_encode($output);        
    }
    public function getdata_setting1(){
        $this->auth->restrict($this->permissionView);
        if (!$this->input->is_ajax_request()) {
            Template::set_message("Hanya request ajax", 'error');
            redirect(SITE_AREA . '/izin/izin_pegawai/setting');
        }
        $draw = $this->input->post('draw');
        $iSortCol = $this->input->post('iSortCol_1');
        $sSortCol = $this->input->post('sSortDir_1');
        
        $length= $this->input->post('length') != "" ? $this->input->post('length') : 10;
        $start= $this->input->post('start') != "" ? $this->input->post('start') : 0;

        $search = isset($_REQUEST['search']["value"]) ? $_REQUEST['search']["value"] : "";
        $searchKey = isset($_REQUEST['search']["key"]) ? $_REQUEST['search']["key"] : "";

        $selectedUnors = array();
        $advanced_search_filters  = $this->input->post("search[advanced_search_filters]");
        if($advanced_search_filters){
            $filters = array();
            foreach($advanced_search_filters as  $filter){
                $filters[$filter['name']] = $filter["value"];
            }
            
        }

        $this->db->start_cache();
        
        /*Jika $search mengandung nilai, berarti user sedang telah 
        memasukan keyword didalam filed pencarian*/
        $pegawai = $this->input->post('pegawai');
        $advanced_search_filters  = $this->input->post("search[advanced_search_filters]");
        if($advanced_search_filters){
            $filters = array();
            foreach($advanced_search_filters as  $filter){
                $filters[$filter['name']] = $filter["value"];
            }
            if($pegawai){
                $this->db->where_in("PNS_ID",$pegawai);    
            }
            if($filters['unit_id_key']){
                $this->db->group_start();
                $this->db->where('UNOR_ID',$filters['unit_id_key']);    
                $this->db->or_where('ESELON_1',$filters['unit_id_key']);   
                $this->db->or_where('ESELON_2',$filters['unit_id_key']);   
                $this->db->or_where('ESELON_3',$filters['unit_id_key']);   
                $this->db->or_where('ESELON_4',$filters['unit_id_key']);   
                $this->db->group_end();
            } 
            if($filters['nama_key']){
                $this->mv_pegawai_cuti_model->like('upper("NAMA")',strtoupper(trim($filters['nama_key'])),"BOTH"); 
            }
            if($filters['nip_key']){
                $this->mv_pegawai_cuti_model->where("NIP_BARU",trim($filters['nip_key']));  
            }
        }
        
        $this->db->stop_cache();
        $output=array();
        $output['draw']=$draw;
        $total= $this->mv_pegawai_cuti_model->count_all();
        $orders = $this->input->post('order');
        foreach($orders as $order){
            if($order['column']==1){
                $this->mv_pegawai_cuti_model->order_by("NIP_BARU",$order['dir']);
            }
            if($order['column']==2){
                $this->mv_pegawai_cuti_model->order_by("NAMA",$order['dir']);
            }
            if($order['column']==3){
                $this->mv_pegawai_cuti_model->order_by("NAMA_ATASAN",$order['dir']);
            }
            if($order['column']==4){
                $this->mv_pegawai_cuti_model->order_by("NAMA_PPK",$order['dir']);
            }
        }
        $output['recordsTotal']= $output['recordsFiltered']=$total;
        $output['data']=array();
        
        $this->mv_pegawai_cuti_model->limit($length,$start);
        $records=$this->mv_pegawai_cuti_model->find_all();
        $this->db->flush_cache();
        $nomor_urut=$start+1;
        if(isset($records) && is_array($records) && count($records)):
            foreach ($records as $record) {
                $row = array();
                //$row []  = $nomor_urut.".";
                $row []  = "<input name='checked[]'' type='checkbox' value='".$record->NIP_BARU."'>";
                $row []  = $record->NIP_BARU."<br>".$record->NAMA;
                $row []  = $record->NAMA_UNOR_FULL;
                $row []  = $record->NAMA_ATASAN;
                $row []  = $record->NAMA_PPK;
                $row []  = $record->KETERANGAN_TAMBAHAN;
                $btn_actions = array();
                if($this->auth->has_permission($this->permissionSettingDelete) && $record->ID_PEGAWAI_ATASAN != ""){
                    $btn_actions  [] = "<a kode='$record->ID_PEGAWAI_ATASAN' class='btn btn-sm btn-danger btn-hapus' data-toggle='tooltip' data-placement='top' data-original-title='Hapus data' title='Hapus data' tooltip='Hapus'><i class='glyphicon glyphicon-remove'></i> </a>";
                }
                $row[] = "<div class='btn-group'>".implode(" ",$btn_actions)."</div>";
                $output['data'][] = $row;
                $nomor_urut++;
            }
        endif;
        echo json_encode($output);
        
    }
    public function getdata_setting(){
        $this->auth->restrict($this->permissionView);
        if (!$this->input->is_ajax_request()) {
            Template::set_message("Hanya request ajax", 'error');
            redirect(SITE_AREA . '/kepegawaian/pegawai');
        }
        $draw = $this->input->post('draw');
        $iSortCol = $this->input->post('iSortCol_1');
        $sSortCol = $this->input->post('sSortDir_1');
        
        $length= $this->input->post('length') != "" ? $this->input->post('length') : 10;
        $start= $this->input->post('start') != "" ? $this->input->post('start') : 0;

        $search = isset($_REQUEST['search']["value"]) ? $_REQUEST['search']["value"] : "";
        $searchKey = isset($_REQUEST['search']["key"]) ? $_REQUEST['search']["key"] : "";

        $selectedUnors = array();
        $advanced_search_filters  = $this->input->post("search[advanced_search_filters]");
        if($advanced_search_filters){
            $filters = array();
            foreach($advanced_search_filters as  $filter){
                $filters[$filter['name']] = $filter["value"];
            }
            
        }
        $kedudukan_hukum = "";
        $this->db->start_cache();
        
        /*Jika $search mengandung nilai, berarti user sedang telah 
        memasukan keyword didalam filed pencarian*/
        $pegawai = $this->input->post('pegawai');
        $advanced_search_filters  = $this->input->post("search[advanced_search_filters]");
        if($advanced_search_filters){
            $filters = array();
            foreach($advanced_search_filters as  $filter){
                $filters[$filter['name']] = $filter["value"];
            }
            if($pegawai){
                $this->pegawai_model->where_in("PNS_ID",$pegawai);    
            }
            if($filters['unit_id_key']){
                $this->db->group_start();
                $this->db->where('UNOR_ID',$filters['unit_id_key']);    
                $this->db->or_where('ESELON_1',$filters['unit_id_key']);   
                $this->db->or_where('ESELON_2',$filters['unit_id_key']);   
                $this->db->or_where('ESELON_3',$filters['unit_id_key']);   
                $this->db->or_where('ESELON_4',$filters['unit_id_key']);   
                $this->db->group_end();
            } 
             
        }
        $this->db->stop_cache();
        $output=array();
        $output['draw']=$draw;
        $asatkers = null;
        if($this->auth->has_permission($this->UnitkerjaTerbatas)){
            $asatkers = json_decode($this->auth->get_satkers());
            $total= $this->pegawai_model->count_all($asatkers,false,$kedudukan_hukum);
        }else{
            $total= $this->pegawai_model->count_all($this->UNOR_ID,false,$kedudukan_hukum);
        }
        
        $orders = $this->input->post('order');
        foreach($orders as $order){
            if($order['column']==1){
                $this->pegawai_model->order_by("NIP_BARU",$order['dir']);
            }
            if($order['column']==2){
                $this->pegawai_model->order_by("pegawai.NAMA",$order['dir']);
            }
            if($order['column']==3){
                $this->pegawai_model->order_by("NAMA_PANGKAT",$order['dir']);
            }
            if($order['column']==4){
                $this->pegawai_model->order_by("NAMA_UNOR",$order['dir']);
            }
        }
        $output['recordsTotal']= $output['recordsFiltered']=$total;
        $output['data']=array();
        
        $this->pegawai_model->limit($length,$start);
        if($this->auth->has_permission($this->UnitkerjaTerbatas)){
            $asatkers = json_decode($this->auth->get_satkers());
            $records=$this->pegawai_model->find_atasan($asatkers,false,$kedudukan_hukum);
        }else{
            $records=$this->pegawai_model->find_atasan($this->UNOR_ID,false,$kedudukan_hukum);
        }
        
        
        $this->db->flush_cache();
        $nomor_urut=$start+1;
        if(isset($records) && is_array($records) && count($records)):
            foreach ($records as $record) {
                $row = array();
                $row []  = "<input name='checked[]'' type='checkbox' value='".$record->NIP_BARU."'>";
                $row []  = $record->NIP_BARU."<br>".$record->NAMA;
                $row []  = $record->NAMA_UNOR_FULL;
                $str_atasan = "";
                if($record->ATASAN != ""){
                    $atasans = explode("@", $record->ATASAN);
                    foreach($atasans as $atasan) {    
                        $array_atasan = explode("-", $atasan);
                        $str_atasan .= get_pejabat_cuti($array_atasan[1])." : ".$array_atasan[0]."<br>";
                    }

                    //$jabatan = get_pejabat_cuti($atasans[])
                }
                $row []  = $str_atasan;
                $btn_actions = array();
                if($this->auth->has_permission($this->permissionSettingDelete) && $record->ATASAN != ""){
                    $btn_actions  [] = "<a kode='$record->ID_PEGAWAI_ATASAN' class='btn btn-sm btn-danger btn-hapus' data-toggle='tooltip' data-placement='top' data-original-title='Hapus data' title='Hapus data' tooltip='Hapus'><i class='glyphicon glyphicon-remove'></i> </a>";
                }
                $row[] = "<div class='btn-group'>".implode(" ",$btn_actions)."</div>";
                $output['data'][] = $row;

                $nomor_urut++;
            }
        endif;
        echo json_encode($output);
        
    }
    public function save(){
         // Validate the data
        $this->form_validation->set_rules($this->izin_pegawai_model->get_validation_rules());
        $response = array(
            'success'=>false,
            'msg'=>'Unknown error'
        );
        $kode_izin = $this->input->post("KODE_IZIN");
        $this->form_validation->set_rules('DARI_TANGGAL','DARI TANGGAL','required|max_length[30]');
        if($kode_izin != "7" and $kode_izin != "8" and $kode_izin != "9" and $kode_izin != "10" and $kode_izin != "11"){
            $this->form_validation->set_rules('SAMPAI_TANGGAL','SAMPAI TANGGAL ','required|max_length[30]');    
        }else if($kode_izin == "7" or $kode_izin == "8"){
            $this->form_validation->set_rules('SELAMA_JAM','SELAMA JAM ','required|max_length[20]');    
            $this->form_validation->set_rules('SELAMA_MENIT','SELAMA MENIT ','required|max_length[20]');    
        }else if($kode_izin == "9" or $kode_izin == "10"){
            $this->form_validation->set_rules('DARI_TANGGAL','TANGGAL','required|max_length[30]');
        }else if($kode_izin == "11"){
            $this->form_validation->set_rules('DARI_TANGGAL','TANGGAL','required|max_length[30]');
            $this->form_validation->set_rules('SELAMA_JAM','DARI JAM ','required|max_length[20]');    
            $this->form_validation->set_rules('SELAMA_MENIT','SAMPAI JAM ','required|max_length[20]');    
        }
        
        if ($this->form_validation->run() === false) {
            $response['msg'] = "
            <div class='alert alert-block alert-error fade in alert-danger'>
                <a class='close' data-dismiss='alert'>&times;</a>
                <h4 class='alert-heading'>
                    Error
                </h4>
                ".validation_errors()."
            </div>
            ";
            echo json_encode($response);
            exit();
        }
        $data = $this->izin_pegawai_model->prep_data($this->input->post());
        // SK pelantikan
        $base64data = "";
        if (isset($_FILES['lampiran']) && $_FILES['lampiran']['name']) {
            $errors=array();
            $allowed_ext= array('pdf');
            $file_name =$_FILES['lampiran']['name'];
         //   $file_name =$_FILES['image']['tmp_name'];
            $file_ext = explode('.',$file_name);
            $file_size=$_FILES['lampiran']['size'];
            $file_tmp= $_FILES['lampiran']['tmp_name'];
            $type= $_FILES['lampiran']['type'];
            //echo $file_ext[1];echo "<br>";
            $data_base = file_get_contents($file_tmp);
            $base64data = 'data:' . $type . ';base64,' . base64_encode($data_base);
            // DIE($base64data);
            if(in_array(end($file_ext),$allowed_ext) === false)
            {
                $errors[]='Extension not allowed';
                $response['msg'] = "
                <div class='alert alert-block alert-error fade in note note-danger alert-danger'>
                    <a class='close' data-dismiss='alert'>&times;</a>
                    <h4 class='alert-heading'>
                        Ada kesalahan
                    </h4>
                    <p>Extension gambar tidak diizinkan, silahkan pilih file image</p>
                </div>
                ";
                echo json_encode($response);
                exit();
            }
            if($file_size > 5097152)
            {
                $errors[]= 'File size must be under 2mb';
                $response['msg'] = "
                <div class='alert alert-block alert-error fade in note note-danger'>
                    <a class='close' data-dismiss='alert'>&times;</a>
                    <h4 class='alert-heading'>
                        Ada kesalahan
                    </h4>
                    <p>File size must be under 5mb</p>
                </div>
                ";
                echo json_encode($response);
                exit();

            }
            //$data['STRUKTUR']  = $base64data;
            if($base64data == "")
                unset($data['LAMPIRAN_FILE']);
            else
                $data['LAMPIRAN_FILE']  = $base64data;
        }

        
        $NIP_PNS = $this->input->post("NIP_PNS");
        $data_pegawai = $this->pegawai_model->find_by("NIP_BARU",$NIP_PNS);
        $NAMA_PEGAWAI = isset($data_pegawai->NAMA) ? $data_pegawai->NAMA : "";
        
        $data['NAMA'] = $NAMA_PEGAWAI;
        $data['JUMLAH'] = (int)$this->input->post("JUMLAH");

        $data['TGL_DIBUAT'] = date("Y-m-d");
        $aTAHUN_PENGAJUAN = explode("-",$this->input->post("DARI_TANGGAL"));
        $TAHUN_PENGAJUAN = isset($aTAHUN_PENGAJUAN[0]) ? $aTAHUN_PENGAJUAN[0] : date("Y");
        $data['TAHUN'] = $TAHUN_PENGAJUAN;
        $data['STATUS_ATASAN'] = 1; // menunggu persetujuan
        $data['STATUS_PYBMC'] = 1; // menunggu persetujuan
        $data['TAHUN'] = $TAHUN_PENGAJUAN;
        $data['TLP_SELAMA_CUTI'] = $this->input->post("TLP_SELAMA_CUTI");
        
        if($data['MASA_KERJA_TAHUN'] == ""){
            unset($data['MASA_KERJA_TAHUN']);
        }
        if($data['MASA_KERJA_BULAN'] == ""){
            unset($data['MASA_KERJA_BULAN']);
        }
        if($data['KODE_IZIN'] == ""){
            unset($data['KODE_IZIN']);
        }
        if($data['JUMLAH'] == ""){
            unset($data['JUMLAH']);
        }
        if($data['SISA_CUTI_TAHUN_N2'] == ""){
            unset($data['SISA_CUTI_TAHUN_N2']);
        }
        if($data['SISA_CUTI_TAHUN_N1'] == ""){
            unset($data['SISA_CUTI_TAHUN_N1']);
        }
        if($data['SISA_CUTI_TAHUN_N'] == ""){
            unset($data['SISA_CUTI_TAHUN_N']);
        }
        if($data['STATUS_ATASAN'] == ""){
            unset($data['STATUS_ATASAN']);
        }
        if($data['STATUS_PYBMC'] == ""){
            unset($data['STATUS_PYBMC']);
        }
        if($data['DARI_TANGGAL'] == ""){
            unset($data['DARI_TANGGAL']);
        }
        if($data['SAMPAI_TANGGAL'] == ""){
            unset($data['SAMPAI_TANGGAL']);
        }
        if($data['TGL_PERKIRAAN_LAHIR'] == ""){
            unset($data['TGL_PERKIRAAN_LAHIR']);
        }
        $id_data = $this->input->post("ID");
        if(isset($id_data) && !empty($id_data)){
            $this->izin_pegawai_model->skip_validation(true);
            $this->izin_pegawai_model->update($id_data,$data);
            log_activity($this->auth->user_id(), 'Edit data izin : ' . $id_data . ' : ' . $this->input->ip_address(), 'izin_pegawai');    
        }
        else{
            // $this->izin_pegawai_model->skip_validation(true);
            if($insert_id = $this->izin_pegawai_model->insert($data)){
                //$this->save_izin_verifikasi($NIP_PNS,$insert_id,$kode_izin);
                log_activity($this->auth->user_id(), 'Sukse Save data izin : ' . $insert_id . ' : ' . $this->input->ip_address(), 'izin_pegawai');    
            }else{
                log_activity($this->auth->user_id(), 'Gagal Save data izin : ' . $this->izin_pegawai_model->error . ' : ' . $this->input->ip_address(), 'izin_pegawai');    
            }
        } 
        $response ['success']= true;
        $response ['msg']= "Berhasil";
        echo json_encode($response);    

    }
    private function save_izin_verifikasi($nip_pegawai = "",$id_pengajuan = "",$id_jenis_izin = ""){
        $line_approval = $this->getpersetujuan($id_jenis_izin);
        $adata_pejabat = $this->get_data_pejabat($nip_pegawai);
        $urutan = 1;
        foreach($line_approval as $values)
         {
            $data = array();
                $data['NIP_ATASAN'] = $adata_pejabat[$values]->NIP_ATASAN;
                $data['ID_PENGAJUAN'] = $id_pengajuan;
                if($urutan == 1){
                    $data['STATUS_VERIFIKASI'] = 1;
                }
                if($insert_id = $this->izin_verifikasi_model->insert($data)){
                    log_activity($this->auth->user_id(), 'Save izin atasan : ' . $insert_id . ' : ' . $this->input->ip_address(), 'izin_pegawai');    
                }
                $urutan++;
         }
    }
    public function saveverifikasi(){
         // Validate the data
        ///$this->form_validation->set_rules($this->izin_pegawai_model->get_validation_rules());
        $response = array(
            'success'=>false,
            'msg'=>'Unknown error'
        );

        $this->form_validation->set_rules('STATUS_ATASAN','STATUS','required|max_length[30]');
        if ($this->form_validation->run() === false) {
            $response['msg'] = "
            <div class='alert alert-block alert-error fade in'>
                <a class='close' data-dismiss='alert'>&times;</a>
                <h4 class='alert-heading'>
                    Error
                </h4>
                ".validation_errors()."
            </div>
            ";
            echo json_encode($response);
            exit();
        }
        // save perubahan status izin_verifikasi
        $ID_VERIFIKASI = $this->input->post("ID_VERIFIKASI");
        $id_pengajuan = $this->input->post("ID");
        $DARI_TANGGAL = $this->input->post("DARI_TANGGAL");
        $SAMPAI_TANGGAL = $this->input->post("SAMPAI_TANGGAL");
        $NIP_PNS = $this->input->post("NIP_PNS");
        $KODE_JENIS_IZIN = $this->input->post("KODE_JENIS_IZIN");
        $KODE_IZIN      = $this->input->post("KODE_IZIN");
        $JUMLAH      = $this->input->post("JUMLAH");
        
        $atasan_selanjutnya = $this->cek_id_terakhir($ID_VERIFIKASI,$id_pengajuan);
        $msg_tambahan = "";
        if(isset($atasan_selanjutnya[0]->ID)){
            // update pengajuan menjadi proses persetujuan
            $this->save_verifikasi_atasan($ID_VERIFIKASI,$this->input->post("STATUS_ATASAN"),$this->input->post("CATATAN_ATASAN"));
            // cek jika statusnya disetujui
            if($this->input->post("STATUS_ATASAN") == "3"){
                // ubah status pengajuan menjadi di proses karena masih ada atasan selanjutnya
                $this->update_status_pengajuan($id_pengajuan,"2",$this->input->post("CATATAN_ATASAN"));
                $this->save_verifikasi_atasan($atasan_selanjutnya[0]->ID,"1"); // merubah status atasan selanjutnya menjadi siap di proses
            }else{
                // jika tidak diterima
                //$this->update_status_pengajuan($id_pengajuan,$this->input->post("STATUS_ATASAN"),$this->input->post("CATATAN_ATASAN"));
                // meskipun tidak diterima, tetapi proses izin tetap dilanjutkan ke proses selanjutnya
                $this->update_status_pengajuan($id_pengajuan,"2",$this->input->post("CATATAN_ATASAN"));
                $this->save_verifikasi_atasan($atasan_selanjutnya[0]->ID,"1"); // merubah status atasan selanjutnya menjadi siap di proses
            }
            
            // update status verifikasi selanjutnya menjadi 1 = siap di verifikasi

        }else{
            // jika level verifikasi terakhir
            $this->save_verifikasi_atasan($ID_VERIFIKASI,$this->input->post("STATUS_ATASAN"),$this->input->post("CATATAN_ATASAN"));
            // atasan terakhir
            $this->update_status_pengajuan($id_pengajuan,$this->input->post("STATUS_ATASAN"),$this->input->post("CATATAN_ATASAN"));
            // jika diterima
            if($this->input->post("STATUS_ATASAN") == "3"){
                // cuti tahunan
                if($KODE_IZIN == "1"){
                    $TAHUN      = date('Y', strtotime($DARI_TANGGAL));;
                    $this->sisa_cuti_model->where('TAHUN', $TAHUN);
                    $data_sisa = $this->sisa_cuti_model->find_by("PNS_NIP",$PNS_NIP);
                    $sisa_n = isset($data_sisa->SISA_N) ? (int)$data_sisa->SISA_N : 0;
                    $sisa_n1 = isset($data_sisa->SISA_N_1) ? (int)$data_sisa->SISA_N_1 : 0;
                    $sisa_n2 = isset($data_sisa->SISA_N_2) ? (int)$data_sisa->SISA_N_2 : 0;
                    
                    $diambil_sebelum = isset($data_sisa->SUDAH_DIAMBIL) ? $data_sisa->SUDAH_DIAMBIL : 0;
                    $jumlah_diambil = $diambil_sebelum + (int)$JUMLAH;
                    $jml_sisa = $sisa_n + $sisa_n1 + $sisa_n2 - $jumlah_diambil;

                    $dataupdate = array();
                    $dataupdate["SUDAH_DIAMBIL"] = $jumlah_diambil;
                    //$dataupdate["SISA"] = $jml_sisa;
                    $this->sisa_cuti_model->where('TAHUN', $TAHUN);
                    $this->sisa_cuti_model->skip_validation(true);
                    $this->sisa_cuti_model->update_where("PNS_NIP",$this->input->post("NIP_PNS"), $dataupdate);
                }

                // kirim update ke server kehadiran

            }
        }
        $response ['success']= true;
        $response ['msg']= "Berhasil ".$msg_tambahan;
        echo json_encode($response);    

    }
    private function cek_id_terakhir($id_verifikasi = "",$id_pengajuan = ""){
        $this->izin_verifikasi_model->where("izin_verifikasi.ID > ".$id_verifikasi."");
        $verifikasi_izin = $this->izin_verifikasi_model->find_all($id_pengajuan);
        return $verifikasi_izin;
    }
    private function get_data_verifikasi_izin($id_pengajuan = ""){
        $verifikasi_izin = $this->izin_verifikasi_model->find_all($id_pengajuan);
        $adata = array();
        if(isset($verifikasi_izin) && is_array($verifikasi_izin) && count($verifikasi_izin)):
            foreach ($verifikasi_izin as $record) {
                $adata[$record->NIP_ATASAN] = $record;
            }
        endif;

        return $adata;
    }
    private function save_verifikasi_atasan($id_verifikasi = "",$status_verifikasi = "",$catatan = ""){
        $dataverifikasi = array();
        $dataverifikasi['STATUS_VERIFIKASI']    = $status_verifikasi;
        $dataverifikasi['TANGGAL_VERIFIKASI']   = date("Y-m-d H:i:s");
        if($status_verifikasi != 3)
            $dataverifikasi['ALASAN_DITOLAK']       = $catatan;
        $this->izin_verifikasi_model->skip_validation(true);
        if($this->izin_verifikasi_model->update($id_verifikasi,$dataverifikasi)){
            log_activity($this->auth->user_id(), 'Verifikasi data izin : ' . $id_verifikasi . ' status" '.$status_verifikasi.' : ' . $this->input->ip_address(), 'izin_pegawai');    
        }

    }
    private function update_status_pengajuan($id_data = "",$status_atasan = "",$catatan_atasan = ""){
        $data['TGL_ATASAN'] = date("Y-m-d");
        $data['STATUS_PENGAJUAN'] = $status_atasan;
        if($status_verifikasi != 3){
            $data['CATATAN_ATASAN'] = $catatan_atasan;    
        }
        if(isset($id_data) && !empty($id_data)){
            $this->izin_pegawai_model->skip_validation(true);
            $this->izin_pegawai_model->update($id_data,$data);
            log_activity($this->auth->user_id(), 'Verifikasi data izin : ' . $id_data . ' status" '.$STATUS_ATASAN.' : ' . $this->input->ip_address(), 'izin_pegawai');    
        }
    }
    public function savepersetujuan(){
        $response = array(
            'success'=>false,
            'msg'=>'Unknown error'
        );
        $this->form_validation->set_rules('STATUS_PYBMC','STATUS','required|max_length[30]');
        if ($this->form_validation->run() === false) {
            $response['msg'] = "
            <div class='alert alert-block alert-error note-danger fade in'>
                <a class='close' data-dismiss='alert'>&times;</a>
                <h4 class='alert-heading'>
                    Error
                </h4>
                ".validation_errors()."
            </div>
            ";
            echo json_encode($response);
            exit();
        }
        $KODE_IZIN = $this->input->post("KODE_IZIN");
        $JUMLAH = $this->input->post("JUMLAH");
        $id_data = $this->input->post("ID");
        $data['TGL_PPK'] = date("Y-m-d");
        $data['STATUS_PYBMC'] = $this->input->post("STATUS_PYBMC");
        $data['CATATAN_PYBMC'] = $this->input->post("CATATAN_PYBMC");
        $data['STATUS_PENGAJUAN'] = $this->input->post("STATUS_PYBMC");

        $data_cuti_tahunan = $this->izin_pegawai_model->find($id_data);
        $status_pybmc = $data_cuti_tahunan->STATUS_PYBMC;

        if($KODE_IZIN == "1" && $this->input->post("STATUS_PYBMC") == "2"){

            $this->sisa_cuti_model->where('TAHUN', $this->input->post("TAHUN"));
            $data_sisa = $this->sisa_cuti_model->find_by("PNS_NIP",$this->input->post("NIP_PNS"));
            $sisa_n = isset($data_sisa->SISA_N) ? (int)$data_sisa->SISA_N : 0;
            $sisa_n1 = isset($data_sisa->SISA_N_1) ? (int)$data_sisa->SISA_N_1 : 0;
            $sisa_n2 = isset($data_sisa->SISA_N_2) ? (int)$data_sisa->SISA_N_2 : 0;
            
            $diambil_sebelum = isset($data_sisa->SUDAH_DIAMBIL) ? $data_sisa->SUDAH_DIAMBIL : 0;
            $jumlah_diambil = $diambil_sebelum + (int)$JUMLAH;
            $jml_sisa = $sisa_n + $sisa_n1 + $sisa_n2 - $jumlah_diambil;

            $dataupdate = array();
            $dataupdate["SUDAH_DIAMBIL"] = $jumlah_diambil;
            $dataupdate["SISA"] = $jml_sisa;
            $this->sisa_cuti_model->where('TAHUN', $this->input->post("TAHUN"));
            $this->sisa_cuti_model->skip_validation(true);
            if($status_pybmc != 2)
                $this->sisa_cuti_model->update_where("PNS_NIP",$this->input->post("NIP_PNS"), $dataupdate);
        }
        // jika awalnya di setujuai cuti tahunan
        if($status_pybmc == 2 and $this->input->post("STATUS_PYBMC") != "2" and $KODE_IZIN == "1"){
            $this->sisa_cuti_model->where('TAHUN', $this->input->post("TAHUN"));
            $data_sisa = $this->sisa_cuti_model->find_by("PNS_NIP",$this->input->post("NIP_PNS"));
            $sisa_n = isset($data_sisa->SISA_N) ? (int)$data_sisa->SISA_N : 0;
            $sisa_n1 = isset($data_sisa->SISA_N_1) ? (int)$data_sisa->SISA_N_1 : 0;
            $sisa_n2 = isset($data_sisa->SISA_N_2) ? (int)$data_sisa->SISA_N_2 : 0;
            
            $diambil_sebelum = isset($data_sisa->SUDAH_DIAMBIL) ? $data_sisa->SUDAH_DIAMBIL : 0;
            $jumlah_diambil = $diambil_sebelum - (int)$JUMLAH;
            $jml_sisa = $sisa_n + $sisa_n1 + $sisa_n2 - $jumlah_diambil;

            $dataupdate = array();
            $dataupdate["SUDAH_DIAMBIL"] = $jumlah_diambil;
            $dataupdate["SISA"] = $jml_sisa;
            $this->sisa_cuti_model->where('TAHUN', $this->input->post("TAHUN"));
            $this->sisa_cuti_model->skip_validation(true);
            $this->sisa_cuti_model->update_where("PNS_NIP",$this->input->post("NIP_PNS"), $dataupdate);

        }
        
        if(isset($id_data) && !empty($id_data)){
            $this->izin_pegawai_model->skip_validation(true);
            $this->izin_pegawai_model->update($id_data,$data);
            log_activity($this->auth->user_id(), 'persetujuan data izin : ' . $id_data . ' status" '.$STATUS_ATASAN.' : ' . $this->input->ip_address(), 'izin_pegawai');
        }
          
        $response ['success']= true;
        $response ['msg']= "Berhasil";
        echo json_encode($response);    

    }
    
    public function savepejabat(){
         // Validate the data
        $this->form_validation->set_rules($this->pegawai_atasan_model->get_validation_rules());
        $response = array(
            'success'=>false,
            'msg'=>'Unknown error'
        );
        //$this->form_validation->set_rules('ATASAN','ATASAN','required|max_length[30]');
        //$this->form_validation->set_rules('PPK','PPK','required|max_length[30]');
        if ($this->form_validation->run() === false) {
            $response['msg'] = "
            <div class='alert alert-block alert-error fade in'>
                <a class='close' data-dismiss='alert'>&times;</a>
                <h4 class='alert-heading'>
                    Error
                </h4>
                ".validation_errors()."
            </div>
            ";
            echo json_encode($response);
            exit();
        }
        $NIP_ATASAN = $this->input->post("ATASAN");
        $NIP_PPK = $this->input->post("PPK");
        $KETERANGAN_TAMBAHAN = $this->input->post("KETERANGAN_TAMBAHAN");
        $ATASAN_TAMBAHAN = $this->input->post("ATASAN_TAMBAHAN");
        $SEBAGAI = $this->input->post("SEBAGAI");
        
        $data_atasan = $this->pegawai_model->find_by("NIP_BARU",$NIP_ATASAN);
        $NAMA_ATASAN = isset($data_atasan->NAMA) ? $data_atasan->NAMA : "";
        $data_ppk = $this->pegawai_model->find_by("NIP_BARU",$NIP_PPK);
        $NAMA_PPK = isset($data_ppk->NAMA) ? $data_ppk->NAMA : "";
        $result = false;
        $msg = "Ada Kesalahan";
        // get nama atasan
        $index = 0;
        $anama_atasan = array();
        if (is_array($ATASAN_TAMBAHAN) && count($ATASAN_TAMBAHAN)) {
            foreach ($ATASAN_TAMBAHAN as $tambahan_atasan) {

                $data_atasan = $this->pegawai_model->find_by("NIP_BARU",$tambahan_atasan);
                $nama_atasan_tambahan = isset($data_atasan->NAMA) ? $data_atasan->NAMA : "";
                $anama_atasan[$tambahan_atasan] = $nama_atasan_tambahan;
                $index++;
            }
        }


        $checked = $this->input->post('checked');
        if (is_array($checked) && count($checked)) {
            foreach ($checked as $pid) {
                
                // save to line approval
                $index = 0;
                if (is_array($ATASAN_TAMBAHAN) && count($ATASAN_TAMBAHAN)) {
                    foreach ($ATASAN_TAMBAHAN as $tambahan_atasan) {
                        // delete line approval
                        if($SEBAGAI[$index] != ""){
                            $datadel_line_approval = array('PNS_NIP'=>$pid,'SEBAGAI'=>$SEBAGAI[$index]);
                            $this->line_approval_model->delete_where($datadel_line_approval);


                            $data = array();
                            $data['NIP_ATASAN']     = $tambahan_atasan;
                            $data['NAMA_ATASAN']    = isset($anama_atasan[$tambahan_atasan]) ? $anama_atasan[$tambahan_atasan] : "";
                            $data['SEBAGAI']        = $SEBAGAI[$index];
                            $data['PNS_NIP'] = $pid;
                            $data['KETERANGAN_TAMBAHAN'] = $KETERANGAN_TAMBAHAN;
                            if($id_line = $this->line_approval_model->insert($data)){
                                $result = true;
                                $msg = "Berhasil";
                                log_activity($this->auth->user_id(), 'Save line approval : ' . $insert_id . ' : ' . $this->input->ip_address(), 'line_approval');    
                            }
                            $index++;
                        }
                    }
                }
                 
            }
        }
        $response ['success']= $result;
        $response ['msg']= $msg;
        echo json_encode($response);    

    }
    public function savepejabat_topegawai_atasan(){
         // Validate the data
        $this->form_validation->set_rules($this->pegawai_atasan_model->get_validation_rules());
        $response = array(
            'success'=>false,
            'msg'=>'Unknown error'
        );
        $this->form_validation->set_rules('NIP_ATASAN','ATASAN','required|max_length[30]');
        $this->form_validation->set_rules('NIP_PPK','PPK','required|max_length[30]');
        if ($this->form_validation->run() === false) {
            $response['msg'] = "
            <div class='alert alert-block alert-error fade in'>
                <a class='close' data-dismiss='alert'>&times;</a>
                <h4 class='alert-heading'>
                    Error
                </h4>
                ".validation_errors()."
            </div>
            ";
            echo json_encode($response);
            exit();
        }
        $NIP_ATASAN = $this->input->post("NIP_ATASAN");
        $NIP_PPK = $this->input->post("NIP_PPK");
        $KETERANGAN_TAMBAHAN = $this->input->post("KETERANGAN_TAMBAHAN");
        $data_atasan = $this->pegawai_model->find_by("NIP_BARU",$NIP_ATASAN);
        $NAMA_ATASAN = isset($data_atasan->NAMA) ? $data_atasan->NAMA : "";
        $data_ppk = $this->pegawai_model->find_by("NIP_BARU",$NIP_PPK);
        $NAMA_PPK = isset($data_ppk->NAMA) ? $data_ppk->NAMA : "";
        $result = false;
        $msg = "Ada Kesalahan";
        $checked = $this->input->post('checked');
        if (is_array($checked) && count($checked)) {
            foreach ($checked as $pid) {
                $datadel = array('PNS_NIP'=>$pid);
                $this->pegawai_atasan_model->delete_where($datadel);

                $data = array();
                $data['NIP_ATASAN'] = $NIP_ATASAN;
                $data['NAMA_ATASAN'] = $NAMA_ATASAN;
                $data['NAMA_PPK'] = $NAMA_PPK;
                $data['PPK'] = $NIP_PPK;
                $data['PNS_NIP'] = $pid;
                $data['KETERANGAN_TAMBAHAN'] = $KETERANGAN_TAMBAHAN;
                if($insert_id = $this->pegawai_atasan_model->insert($data)){
                    $result = true;
                    $msg = "Berhasil";
                    log_activity($this->auth->user_id(), 'Save data pejabat : ' . $insert_id . ' : ' . $this->input->ip_address(), 'pegawai_atasan');    
                }
            }
        }
        $response ['success']= $result;
        $response ['msg']= $msg;
        echo json_encode($response);    

    }
    public function refreshpejabat(){
        $query = "REFRESH MATERIALIZED VIEW mv_pegawai_cuti;";
        $result = false;
        $msg = "Ada kesalahan";
        if ($this->db->query($query))
        {
            $result = true;
            $msg = "Berhasil Refresh data";
        }
        else
        {
            $result = false;
        }

        $response ['success']= $result;
        $response ['msg']= $msg;
        echo json_encode($response);   
    }
    public function deletedata()
    {
        $this->auth->restrict($this->permissionDelete);
        $id         = $this->input->post('kode');
        $data       = $this->izin_pegawai_model->find($id);
        $user_id    = $data->NIP_PNS;
        $start_date = $data->DARI_TANGGAL;
        $end_date   = $data->SAMPAI_TANGGAL;
        $lampiran   = $data->LAMPIRAN_FILE;
        $status = false;
        $msg = ""; 
        if($data->STATUS_PYBMC == "2" or $data->STATUS_PENGAJUAN == "3"){
            $response ['success']= false;
            $response ['msg']= "Data tidak bisa dihapus karena sudah melewati Persetujuan";
            echo json_encode($response);   
            exit();
        }
        if ($this->izin_pegawai_model->delete($id)) {
            $this->delete_izin_verifikasi($id);
            if($lampiran != ""){
                unlink(trim($this->settings_lib->item('site.pathlampiranizin')).$lampiran);
            }
            log_activity($this->auth->user_id(), 'delete data izin : ' . $id . ' : ' . $this->input->ip_address(), 'izin_pegawai');
            Template::set_message("Sukses Hapus data", 'success');

            $status = true;
        }else{
            $status = false;
            $msg = "Ada kesalahan"; 
        }
        $response ['success']= $status;
        $response ['msg']= $msg;
        echo json_encode($response);   
        exit();
    }
    private function delete_absen_ekehadiran($user_id = "",$start_date = "",$end_date = ""){
        $this->load->library('Api_kehadiran');
        $api_kehadiran = new Api_kehadiran;
        $return_del_absen = $api_kehadiran->del_absen($user_id,$start_date,$end_date);
        return $return_del_absen;
    }
    private function delete_izin_verifikasi($id_pengajuan = ""){
        $datadel = array('ID_PENGAJUAN'=>$id_pengajuan);
        $this->izin_verifikasi_model->delete_where($datadel);
    }
    public function deletedata_pejabat()
    {
        $this->auth->restrict($this->permissionSettingDelete);
        $id     = $this->input->post('kode');
        if ($this->pegawai_atasan_model->delete($id)) {
             
             log_activity($this->auth->user_id(), 'delete data pejabat : ' . $id . ' : ' . $this->input->ip_address(), 'pegawai_atasan');
             Template::set_message("Sukses Hapus data", 'success');
             echo "Sukses";
        }else{
            echo "Gagal";
        }

        exit();
    }
    public function absen(){
        $this->auth->restrict($this->permissionSettingKirimAbsen);
        $this->load->model('izin_pegawai/hari_libur_model');
        $this->load->library('Convert');
        $convert = new Convert;
        $ses_nip    = trim($this->auth->username());
        $tanggal = date("Y-m-d");
        //GET DATA HARI LIBUR
        $tahun = date("Y");
        $bulan = date("m");
        $record_hari_libur_tahunan = $this->hari_libur_model->find_by_tahun($tahun);
        $record_hari_libur_bulan_ini = $this->hari_libur_model->find_by_bulan($tahun,$bulan);
        Template::set("record_hari_libur_tahunan",$record_hari_libur_tahunan);
        Template::set("record_hari_libur_bulan_ini",$record_hari_libur_bulan_ini);

        $tanggal_indonesia = $convert->fmtDate($tanggal,"dd month yyyy");
        $hari = $convert->Gethari($tanggal);

        // get data atasan
        $dataatasan = $this->getatasan($ses_nip);//$this->line_approval_model->get_atasan_pegawai($ses_nip);
        $nama_atasan_langsung = isset($dataatasan[0]->NAMA_ATASAN) ? $dataatasan[0]->NAMA_ATASAN : "";
        $index_ppk = count($dataatasan) - 1;
        $nama_ppk = isset($dataatasan[$index_ppk]->NAMA_ATASAN) ? $dataatasan[$index_ppk]->NAMA_ATASAN : "";
        $tanggal = date("Y-m-d");
        $check_in = date("H:i:s");
        // cek ke data absen apakah sudah pernah kirim absen sebelumnya jika sudah pernah kirim absen berarti absen yang kedua itu adalah absen pulang/checkout
        $data_absen = $this->absen_model->getdata_absen($ses_nip,$tanggal);
        
        $jam_checkin = isset($data_absen[0]->JAM) ? $data_absen[0]->JAM : "";
        $jam_checkout = "";
        if(isset($data_absen[0]->JAM) and count($data_absen) > 1){
            $index_checkout =  count($data_absen) - 1;
            $jam_checkout = isset($data_absen[$index_checkout]->JAM) ? $data_absen[$index_checkout]->JAM : "";
        }


        Template::set_view("presensi/absen");
        Template::set('toolbar_title', "Status Presensi");
        Template::set("tanggal_indonesia",$tanggal_indonesia);
        Template::set("nip",$ses_nip);
        Template::set("hari",$hari);
        Template::set("jam_checkin",$jam_checkin);
        Template::set("jam_checkout",$jam_checkout);
        Template::set("nama_atasan_langsung",$nama_atasan_langsung);
        Template::set("nama_ppk",$nama_ppk);
        Template::render();
    }
    private function get_json_harilibur_tahunan($tahun = ""){
        $this->load->model('izin_pegawai/hari_libur_model');
        $aharilibur = array();
        $record_hari_libur_tahunan = $this->hari_libur_model->find_by_tahun($tahun);
        //print_r($record_hari_libur_tahunan);
        if(isset($record_hari_libur_tahunan) && is_array($record_hari_libur_tahunan) && count($record_hari_libur_tahunan)):
            foreach ($record_hari_libur_tahunan as $record) {
                $atanggal_libur = $this->returnBetweenDates($record->START_DATE,$record->END_DATE);
                $aharilibur = array_merge($aharilibur,$atanggal_libur);
            }
        endif;
        return json_encode($aharilibur);

    }
    function returnBetweenDates( $startDate, $endDate ){
        $startStamp = strtotime(  $startDate );
        $endStamp   = strtotime(  $endDate );

        if( $endStamp > $startStamp ){
            while( $endStamp >= $startStamp ){

                $dateArr[] = date( 'Y-m-d', $startStamp );

                $startStamp = strtotime( ' +1 day ', $startStamp );

            }
            return $dateArr;    
        }else{
            $dateArr[] = $startDate;
            return $dateArr;
        }

    }
    public function perizinan(){
        //$this->auth->restrict($this->permissionSettingKirimAbsen);
        $this->load->model('izin_pegawai/hari_libur_model');
        $this->load->library('Convert');
        $convert = new Convert;
        $ses_nip    = trim($this->auth->username());
        $tanggal = date("Y-m-d");
        //GET DATA HARI LIBUR
        $tahun = date("Y");
        $bulan = date("m");
        $record_hari_libur_tahunan = $this->hari_libur_model->find_by_tahun($tahun);
        $record_hari_libur_bulan_ini = $this->hari_libur_model->find_by_bulan($tahun,$bulan);
        Template::set("record_hari_libur_tahunan",$record_hari_libur_tahunan);
        Template::set("record_hari_libur_bulan_ini",$record_hari_libur_bulan_ini);

        $tanggal_indonesia = $convert->fmtDate($tanggal,"dd month yyyy");
        $hari = $convert->Gethari($tanggal);

        $nama_bulan = $convert->getmonth($bulan);
        Template::set('nama_bulan', $nama_bulan);
        // jenis izin
        $jenis_izin = $this->jenis_izin_model->find_all();
        Template::set('jenis_izin', $jenis_izin);

        $status_izin = $this->get_group_status($ses_nip);
        Template::set('status_izin', $status_izin);

        // get data atasan
        $dataatasan = $this->getatasan($ses_nip);//$this->line_approval_model->get_atasan_pegawai($ses_nip);
        $nama_atasan_langsung = isset($dataatasan[0]->NAMA_ATASAN) ? $dataatasan[0]->NAMA_ATASAN : "";
        $index_ppk = count($dataatasan) - 1;
        $nama_ppk = isset($dataatasan[$index_ppk]->NAMA_ATASAN) ? $dataatasan[$index_ppk]->NAMA_ATASAN : "";
        $tanggal = date("Y-m-d");
        $check_in = date("H:i:s");
        // cek ke data absen apakah sudah pernah kirim absen sebelumnya jika sudah pernah kirim absen berarti absen yang kedua itu adalah absen pulang/checkout
        $data_absen = $this->absen_model->getdata_absen($ses_nip,$tanggal);
        
        $jam_checkin = isset($data_absen[0]->JAM) ? $data_absen[0]->JAM : "";
        $jam_checkout = "";
        if(isset($data_absen[0]->JAM) and count($data_absen) > 1){
            $index_checkout =  count($data_absen) - 1;
            $jam_checkout = isset($data_absen[$index_checkout]->JAM) ? $data_absen[$index_checkout]->JAM : "";
        }

        // group by jenis 
        $data_jenisizin = $this->getgroup_byjenis($ses_nip);
        Template::set("data_jenisizin",$data_jenisizin);
        // sum hari group by jenis 
        $data_jumlah_hari = $this->get_sum_hari_group_byjenis($ses_nip);
        Template::set("data_jumlah_hari",$data_jumlah_hari);
        

        Template::set('toolbar_title', "Perizinan Pegawai");
        Template::set("tanggal_indonesia",$tanggal_indonesia);
        Template::set("nip",$ses_nip);
        Template::set("hari",$hari);
        Template::set("jam_checkin",$jam_checkin);
        Template::set("jam_checkout",$jam_checkout);
        Template::set("nama_atasan_langsung",$nama_atasan_langsung);
        Template::set("nama_ppk",$nama_ppk);
        Template::render();
    }
    public function laporanpegawai(){
        $this->auth->restrict($this->permissionLaporanPegawai);
        $this->load->model('izin_pegawai/hari_libur_model');
        $this->load->library('Convert');
        $convert = new Convert;
        $ses_nip    = trim($this->auth->username());
        $tanggal = date("Y-m-d");
        //GET DATA HARI LIBUR
        $tahun = date("Y");
        $bulan = date("m");
        $record_hari_libur_tahunan = $this->hari_libur_model->find_by_tahun($tahun);
        $record_hari_libur_bulan_ini = $this->hari_libur_model->find_by_bulan($tahun,$bulan);
        Template::set("record_hari_libur_tahunan",$record_hari_libur_tahunan);
        Template::set("record_hari_libur_bulan_ini",$record_hari_libur_bulan_ini);

        $tanggal_indonesia = $convert->fmtDate($tanggal,"dd month yyyy");
        $hari = $convert->Gethari($tanggal);

        $nama_bulan = $convert->getmonth($bulan);
        Template::set('nama_bulan', $nama_bulan);
         
        $status_izin = $this->get_group_status($ses_nip);
        Template::set('status_izin', $status_izin);

        // group by jenis 
        $data_jenisizin = $this->getgroup_byjenis($ses_nip);
        Template::set("data_jenisizin",$data_jenisizin);
        // sum hari group by jenis 
        $data_jumlah_hari = $this->get_sum_hari_group_byjenis($ses_nip);
        Template::set("data_jumlah_hari",$data_jumlah_hari);
        

        Template::set('toolbar_title', "Laporan Izin Pegawai");
        Template::set("tanggal_indonesia",$tanggal_indonesia);
        Template::set("nip",$ses_nip);
        Template::set("hari",$hari);
        Template::render();
    }
    private function getgroup_byjenis($nip = ""){
        $json_jenis = array();
        $record_jenis_izin = $this->jenis_izin_model->grupby_jenis($nip); 

        $dataprov = array();
        if (isset($record_jenis_izin) && is_array($record_jenis_izin) && count($record_jenis_izin)) :
            foreach ($record_jenis_izin as $record) :
                if($record->NAMA_IZIN != "")
                    $dataprov["NAMA"] = $record->NAMA_IZIN;
                else
                    $dataprov["NAMA"] = "-";
                $dataprov["jumlah"] = $record->jumlah;
                $json_jenis[]   = $dataprov;
            endforeach;
        endif;
        return json_encode($json_jenis);
    }
    private function get_sum_hari_group_byjenis($nip = ""){
        $json_jenis = array();
        $record_jenis_izin = $this->izin_pegawai_model->sum_hari_grupby_jenis($nip); 

        $dataprov = array();
        if (isset($record_jenis_izin) && is_array($record_jenis_izin) && count($record_jenis_izin)) :
            foreach ($record_jenis_izin as $record) :
                if($record->NAMA_IZIN != "")
                    $dataprov["NAMA"] = $record->NAMA_IZIN;
                else
                    $dataprov["NAMA"] = "-";
                $dataprov["jumlah"] = $record->jumlah;
                $json_jenis[]   = $dataprov;
            endforeach;
        endif;
        return json_encode($json_jenis);
    }
    private function get_group_status($nip = ""){
        $astatus = array();
        $record_status = $this->izin_pegawai_model->grupby_status($nip); 
        if (isset($record_status) && is_array($record_status) && count($record_status)) :
            foreach ($record_status as $record) :
                $astatus[$record->STATUS_PENGAJUAN]   = $record->jumlah;
            endforeach;
        endif;
        return $astatus;
    }
    
    private function getatasan($ses_nip = ""){
        $dataatasan = $this->line_approval_model->get_atasan_pegawai($ses_nip);
        return $dataatasan;
    }
    public function kirimkehadiran(){
        $this->auth->restrict($this->permissionSettingKirimAbsen);
        $this->load->library('Api_kehadiran');
        $api_kehadiran = new Api_kehadiran;
        $result = false;
        $msg = "";
        $response = array(
            'success'=>$result,
            'msg'=>'Unknown error'
        );
        $this->form_validation->set_rules('NIP','NIP','required|max_length[30]');
        if ($this->form_validation->run() === false) {
            $response['msg'] = "
            <div class='alert alert-block alert-error fade in'>
                <a class='close' data-dismiss='alert'>&times;</a>
                <h4 class='alert-heading'>
                    Error
                </h4>
                ".validation_errors()."
            </div>
            ";
            echo json_encode($response);
            exit();
        }

        $ses_nip    = trim($this->auth->username());
        $nip   = $this->input->post('NIP') ? $this->input->post('NIP') : $ses_nip;
        $tanggal = date("Y-m-d");
        $check_in = date("H:i:s");
        // cek ke data absen apakah sudah pernah kirim absen sebelumnya jika sudah pernah kirim absen berarti absen yang kedua itu adalah absen pulang/checkout
        $data_absen = $this->absen_model->getdata_absen($nip,$tanggal);
        if(isset($data_absen[0]->ID) && $data_absen[0]->ID != ""){
            // kirim ke server kehadiran
            log_activity($this->auth->user_id(), 'Kirim ke server kehadiran : ' .$data_absen[0]->ID. $this->input->ip_address(), 'absen');    
        }else{
            // save biasa
        }

        // save absen ke tabel absen
        $data_pegawai = $this->pegawai_model->find_by("NIP_BARU",$nip);
        $NAMA_PEGAWAI = isset($data_pegawai->NAMA) ? $data_pegawai->NAMA : "";
        if($NAMA_PEGAWAI == ""){
            $response['msg'] = "
            <div class='alert alert-block alert-error fade in'>
                <a class='close' data-dismiss='alert'>&times;</a>
                <h4 class='alert-heading'>
                    Error
                </h4>
                NIP tidak ditemukan.. silahkan hubungi administrator
            </div>
            ";
            echo json_encode($response);
            exit();
        }
        $data = array();
        $data['NIP'] = $nip;
        $data['NAMA'] = $NAMA_PEGAWAI;
        $data['TANGGAL'] = $tanggal;
        $data['JAM'] = $check_in;
        $this->absen_model->skip_validation(true);
        if($insert_id = $this->absen_model->insert($data)){
            log_activity($this->auth->user_id(), 'Save data absen dari web : ' . $insert_id . ' : ' . $this->input->ip_address(), 'absen');    
            $result = true;
            // kirim log absen ke kehdiran
            //$send_absen = $api_kehadiran->send_log_absen($nip,$tanggal,$check_in);

        }
        $response ['success']= $result;
        $response ['msg']= $msg;
        $response ['jam']= $check_in;
        echo json_encode($response);    
        // $start_date = "2020-09-01";
        // $end_date = "2020-09-20";
        
        //$json_absen = $api_kehadiran->getabsen($ses_nip,$start_date,$end_date);
        // test kirim absen
        
        
        $check_out = "16:55:03";
        $terlambat = "0";
        $pulang_cepat = "0";
        $ot_before = "0";
        $ot_after = "0";
        //$send_absen = $api_kehadiran->sendabsen($ses_nip,$tanggal,$check_in,$check_out,$terlambat,$pulang_cepat,$ot_before,$ot_after,$workinonholiday);
    }
    public function viewdoc($id)
    {
        if (empty($id)) {
            Template::set_message("ID tidak ditemukan", 'error');
        }
        $datadetil = $this->izin_pegawai_model->find($id);
        $FILE_BASE64 = $datadetil->LAMPIRAN_FILE;
        echo '<embed src="'.$FILE_BASE64.'" width="100%" height="700" alt="pdf">';
        die();
    }
}