<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Bonfire
 *
 * An open source project to allow developers get a jumpstart their development of CodeIgniter applications
 *
 * @package   Bonfire
 * @author    Bonfire Dev Team
 * @copyright Copyright (c) 2011 - 2013, Bonfire Dev Team
 * @license   http://guides.cibonfire.com/license.html
 * @link      http://cibonfire.com
 * @since     Version 1.0
 * @filesource
 */

// ------------------------------------------------------------------------

/**
 * Users Controller
 *
 * Manages the user functionality on the admin pages.
 *
 * @package    Bonfire
 * @subpackage Modules_Users
 * @category   Controllers
 * @author     Bonfire Dev Team
 * @link       http://cibonfire.com
 *
 */

class Settings extends Admin_Controller
{
	protected $permissionManage   = 'Bonfire.Users.Manage';
	protected $permissionLoginAs   = 'Bonfire.Users.LoginAs';
	
	//--------------------------------------------------------------------

	/**
	 * Setup the required permissions
	 *
	 * @return void
	 */
	var $aroles = "";
	public function __construct()
    {
		parent::__construct();
		//die("settings");
		

		$this->load->model('roles/role_model');

		$this->lang->load('users');

		Template::set_block('sub_nav', 'settings/_sub_nav');
		/*
		$this->load->model('pegawai/pegawai_model', null, true);
		$this->pegawai_model->where('no_absen != ""');
		$this->pegawai_model->order_by('nama',"asc");
		$pegawais = $this->pegawai_model->find_all();
		Template::set('pegawais', $pegawais);
		
		$this->user_model->where("users.nip != ''");
		$userrecords = $this->user_model->find_all();
		Template::set('userrecords', $userrecords);
		*/
		// Fetch roles for the filter and the list.
        $roles = $this->role_model->select('role_id, role_name')
                                  ->where('deleted', 0)
                                  ->order_by('role_name', 'asc')
                                  ->find_all();
        $orderedRoles = array();
        foreach ($roles as $role) {
            $orderedRoles[$role->role_id] = $role;
        }
        $this->aroles = $orderedRoles;
        Template::set('roles', $orderedRoles);
	}//end __construct()

	//--------------------------------------------------------------------

	/*
	 * Display the user list and manage the user deletions/banning/purge
	 *
	 * @access public
	 *
	 * @return  void
	 */
	public function index($filter = 'all', $offset = 0)
    {
    	//$this->auth->restrict('Bonfire.Users.View');
        $this->auth->restrict($this->permissionManage);

        Template::set_view('settings/indexnew');
        Template::render();
    }
	public function indexold($filter = 'all', $offset = 0)
    {
        $this->auth->restrict($this->permissionManage);

        // Fetch roles for the filter and the list.
        $roles = $this->role_model->select('role_id, role_name')
                                  ->where('deleted', 0)
                                  ->order_by('role_name', 'asc')
                                  ->find_all();
        $orderedRoles = array();
        foreach ($roles as $role) {
            $orderedRoles[$role->role_id] = $role;
        }
        Template::set('roles', $orderedRoles);

        // Perform any actions?
        foreach (array('restore', 'purge', 'delete', 'ban', 'deactivate', 'activate') as $act) {
            if (isset($_POST[$act])) {
                $action = "_{$act}";
                break;
            }
        }

        // If an action was found, get the checked users and perform the action.
        if (isset($action)) {
            $checked = $this->input->post('checked');
            if (empty($checked)) {
                // No users checked.
                Template::set_message(lang('us_empty_id'), 'error');
            } else {
                foreach ($checked as $userId) {
                    $this->$action($userId);
                }
            }
        }

        // Actions done, now display the view.
        $where = array('users.deleted' => 0);

        // Filters
        if (preg_match('{first_letter-([A-Z])}', $filter, $matches)) {
            $filterType = 'first_letter';
            $firstLetter = $matches[1];
            Template::set('first_letter', $firstLetter);
        } elseif (preg_match('{role_id-([0-9]*)}', $filter, $matches)) {
            $filterType = 'role_id';
            $roleId = (int) $matches[1];
        } else {
            $filterType = $filter;
        }

        switch ($filterType) {
            case 'inactive':
                $where['users.active'] = 0;
                break;
            case 'banned':
                $where['users.banned'] = 1;
                break;
            case 'deleted':
                $where['users.deleted'] = 1;
                break;
            case 'role_id':
                $where['users.role_id'] = $roleId;
                foreach ($roles as $role) {
                    if ($role->role_id == $roleId) {
                        Template::set('filter_role', $role->role_name);
                        break;
                    }
                }
                break;
            case 'first_letter':
                // @todo Determine whether this needs to be changed to become
                // usable with databases other than MySQL
                $where['SUBSTRING( LOWER(username), 1, 1)='] = $firstLetter;
                break;
            case 'all':
                // Nothing to do
                break;
            default:
                // Unknown/bad $filterType
                show_404("users/index/$filter/");
        }
        // Fetch the users to display
        $this->user_model->limit($this->limit, $offset)
                         ->where($where)
                         ->select(
                             array(
                                'users.id',
                                'users.role_id',
                                'username',
                                'display_name',
                                'email',
                                'last_login',
                                'banned',
                                'active',
                                'users.deleted',
                                'role_name',
                             )
                         );
        
        $nip = $this->input->get('nip');
		if($nip!=""){
			$this->user_model->where("lower(username) like '%".strtolower($nip)."%'");
			$this->user_model->or_where("lower(display_name) like '%".strtolower($nip)."%'");
		}
        Template::set('users', $this->user_model->find_all());

        // Used as the view's index_url and the base for the pager's base_url.
        $indexUrl = site_url(SITE_AREA . '/settings/users/index') . '/';
        Template::set('index_url', $indexUrl);

        // Pagination
        $this->load->library('pagination');
		
		if($nip!=""){
			$this->user_model->where("lower(username) like '%".strtolower($nip)."%'");
			$this->user_model->or_where("lower(display_name) like '%".strtolower($nip)."%'");
		}
		$total = $this->user_model->where($where)->count_all();
        $this->pager['base_url']    = "{$indexUrl}{$filter}/";
        $this->pager['per_page'] = $this->limit;
        $this->pager['total_rows']  = $total;
        $this->pager['uri_segment'] = 6;

        $this->pagination->initialize($this->pager);
		
		Template::set('total', $total);
        Template::set('nip', $nip);
        Template::set('filter_type', $filterType);
        Template::set('toolbar_title', lang('us_user_management'));

        Template::render();
    }
    public function getdataall_user(){
        $this->auth->restrict($this->permissionManage);
        if (!$this->input->is_ajax_request()) {
            Template::set_message("Hanya request ajax", 'error');
            redirect(SITE_AREA . '/users');
        }
        $this->load->library('users/auth');
        $this->set_current_user();
        //$kementerian = isset($this->current_user->kementerian) ? $this->current_user->kementerian : "";
        $draw = $this->input->post('draw');
        $iSortCol = $this->input->post('iSortCol_1');
        $sSortCol = $this->input->post('sSortDir_1');
        
        $length= $this->input->post('length') != "" ? $this->input->post('length') : 10;
        $start= $this->input->post('start') != "" ? $this->input->post('start') : 0;

        $search = isset($_REQUEST['search']["value"]) ? $_REQUEST['search']["value"] : "";
        $searchKey = isset($_REQUEST['search']["key"]) ? $_REQUEST['search']["key"] : "";

        $selectedUnors = array();
        $advanced_search_filters  = $this->input->post("search[advanced_search_filters]");
        if($advanced_search_filters){
            $filters = array();
            foreach($advanced_search_filters as  $filter){
                $filters[$filter['name']] = $filter["value"];
            }
            
        }

        $this->db->start_cache();
        /*Jika $search mengandung nilai, berarti user sedang telah 
        memasukan keyword didalam filed pencarian*/
        $advanced_search_filters  = $this->input->post("search[advanced_search_filters]");
        if($advanced_search_filters){
            $filters = array();
            foreach($advanced_search_filters as  $filter){
                $filters[$filter['name']] = $filter["value"];
            }
            if($filters['nama_key']){
                $this->user_model->like('upper("display_name")',strtoupper($filters['nama_key']),"BOTH");    
            }
            if($filters['username_key']){
                $this->user_model->like('upper("username")',strtoupper($filters['username_key']),"BOTH"); 
            }
            if($filters['role_id']){
                $this->user_model->where("users.role_id",$filters['role_id']); 
            } 
            if($filters['status_active']){
                $this->user_model->where("users.active",$filters['status_active']); 
            } 
            if($filters['status_deleted']){
                $this->user_model->where("users.deleted",$filters['status_deleted']); 
            }else{
                $this->user_model->where("users.deleted = 0"); 
            }
            
        }
        
        $this->db->stop_cache();
        $output=array();
        $output['draw']=$draw;
        $total= $this->user_model->count_all();
        $orders = $this->input->post('order');
        foreach($orders as $order){
            if($order['column']==1){
                $this->user_model->order_by("display_name",$order['dir']);
            }
            if($order['column']==2){
                $this->user_model->order_by("username",$order['dir']);
            }
            if($order['column']==3){
                $this->user_model->order_by("role_id",$order['dir']);
            }
            
            if($order['column']==4){
                $this->user_model->order_by("active",$order['dir']);
            }
        }
        $output['recordsTotal']= $output['recordsFiltered']=$total;
        $output['data']=array();
        
        $this->user_model->limit($length,$start);
        $records=$this->user_model->find_all();
        $this->db->flush_cache();
        $nomor_urut=$start+1;
        if(isset($records) && is_array($records) && count($records)):
            foreach ($records as $record) {
                $row = array();
                $row []  = $nomor_urut.".";
                $row []  = "<b>".$record->display_name."</b>";
                $row []  = "<b>".$record->username."</b>";
                $roles_text = array();
				foreach($record->roles as $role) {
					$roles_text[] =  strtoupper($this->aroles[$role]->role_name);
				}
				$row []  = implode(", ",$roles_text);
				$row []  = $record->last_login;
                $status = "";
                $status_delete = "";
                if ($record->active) :
					$status = "<a href='#' class='btl_nonaktifkan' kode='".$record->id."'><span class='label label-success'>".lang('us_active')."</span></a>";
				else : 
					$status = "<a href='#' class='btl_aktifkan' kode='".$record->id."'><span class='label label-danger'>".lang('us_inactive')."</span></a>";
				endif; 

				if ($record->deleted) :
					$status_delete = "&nbsp;&nbsp;<a href='#' class='btl_kembalikan' kode='".$record->id."'><span class='label label-danger'>Deleted</span></a>";
				endif; 
				$row []  = $status.$status_delete;

                $btn_actions = array();
                
                if($this->auth->has_permission($this->permissionLoginAs))
                {    
	                $btn_actions  [] = "<a href='".base_url()."admin/settings/users/loginas/".trim($record->username)."' data-toggle='tooltip' title='Login sebagai ".trim($record->display_name)."' class='btn btn-sm btn-success'><i class='fa fa-user'></i> </a>";
	            }
	            if($this->auth->has_permission($this->permissionManage))
                {    
	                $btn_actions  [] = "<a href='".base_url()."admin/settings/users/edit/".$record->id."' data-toggle='tooltip' title='Lihat detil' class='btn btn-sm btn-warning'><i class='fa fa-edit'></i> </a>";
	            }
	            if($this->auth->has_permission($this->permissionManage))
                {    
	                $btn_actions  [] = "<a href='#' kode='$record->id' data-toggle='tooltip' title='Hapus User' class='btn btn-sm btn-danger btn-hapus'><i class='fa fa-trash'></i> </a>";
	            }
                $row[] = "<div class='btn-group'>".implode(" ",$btn_actions)."</div>";

                $output['data'][] = $row;
                $nomor_urut++;
            }
        endif;
        echo json_encode($output);
        
    }
	//--------------------------------------------------------------------

	/**
	 * Manage creating a new user
	 *
	 * @access public
	 *
	 * @return void
	 */
	public function create()
	{
		$this->auth->restrict('Bonfire.Users.Add');

		$this->load->config('address');
		$this->load->helper('address');
		$this->load->helper('date');


		$this->load->config('user_meta');
		$meta_fields = config_item('user_meta_fields');
		Template::set('meta_fields', $meta_fields);

		if (isset($_POST['save']))
		{
			if ($id = $this->save_user('insert', NULL, $meta_fields))
			{
				$user = $this->user_model->find($id);
				$log_name = (isset($user->display_name) && !empty($user->display_name)) ? $user->display_name : ($this->settings_lib->item('auth.use_usernames') ? $user->username : $user->email);
				log_activity($this->current_user->id, sprintf(lang('us_log_create') ,$user->role_name) . ': '.$log_name, 'users');

				Template::set_message(lang('us_user_created_success'), 'success');
				redirect(SITE_AREA .'/settings/users');
			}
		}

        $settings = $this->settings_lib->find_all();
        if ($settings['auth.password_show_labels'] == 1) {
            Assets::add_module_js('users','password_strength.js');
            Assets::add_module_js('users','jquery.strength.js');
            Assets::add_js($this->load->view('users_js', array('settings'=>$settings), true), 'inline');
        }
        Template::set('roles', $this->role_model->select('role_id, role_name, is_default')->where('deleted', 0)->find_all());
		Template::set('languages', unserialize($this->settings_lib->item('site.languages')));

		Template::set('toolbar_title', lang('us_create_user'));
		Template::set_view('settings/user_form');
		Template::render();

	}//end create()

	//--------------------------------------------------------------------

	/**
	 * Edit a user
	 *
	 * @access public
	 *
	 * @return void
	 */
	public function edit($user_id='')
	{
		$this->load->config('address');
		$this->load->helper('address');
		$this->load->helper('date');

		// if there is no id passed in edit the current user
		// this is so we don't have to pass the user id in the url for editing the current users profile
		if (empty($user_id))
		{
			$user_id = $this->current_user->id;
		}

		if (empty($user_id))
		{
			Template::set_message(lang('us_empty_id'), 'error');
			redirect(SITE_AREA .'/settings/users');
		}

		if ($user_id != $this->current_user->id)
		{
			$this->auth->restrict('Bonfire.Users.Manage');
		}


		$this->load->config('user_meta');
		$meta_fields = config_item('user_meta_fields');
		Template::set('meta_fields', $meta_fields);

		$user = $this->user_model->find_user_and_meta($user_id);
		if (isset($_POST['save']))
		{
			if ($this->save_user('update', $user_id, $meta_fields, $user->role_name))
			{
				$user = $this->user_model->find_user_and_meta($user_id);
				
				$log_name = (isset($user->display_name) && !empty($user->display_name)) ? $user->display_name : ($this->settings_lib->item('auth.use_usernames') ? $user->username : $user->email);
				log_activity($this->current_user->id, lang('us_log_edit') .': '.$log_name, 'users');

				Template::set_message(lang('us_user_update_success'), 'success');

				// redirect back to the edit page to make sure that a users password change
				// forces a login check
				redirect($this->uri->uri_string());
			}
		}
		$this->load->model('pegawai/unitkerja_model');
		$satkers = $this->unitkerja_model->find_satker();
		//print_r($NAMA_UNOR);
		Template::set('satkers', $satkers);
		if (isset($user))
		{

			Template::set('roles', $this->role_model->select('role_id, role_name, is_default')->where('deleted', 0)->find_all());
			
			Template::set('user', $user);
			Template::set('languages', unserialize($this->settings_lib->item('site.languages')));
		}
		else
		{
			Template::set_message(sprintf(lang('us_unauthorized'),$user->role_name), 'error');
			redirect(SITE_AREA .'/settings/users');
		}

        $settings = $this->settings_lib->find_all();
        if ($settings['auth.password_show_labels'] == 1) {
            Assets::add_module_js('users','password_strength.js');
            Assets::add_module_js('users','jquery.strength.js');
            Assets::add_js($this->load->view('users_js', array('settings'=>$settings), true), 'inline');
        }

		Template::set('toolbar_title', lang('us_edit_user'));
		$selectedRoles = $this->user_model->getRoles($user_id);
		//PRINT_R($selectedRoles);
		//die();
		Template::set('selectedRoles',$selectedRoles);
		Template::set_view('settings/user_form');

		Template::render();

	}//end edit()
    public function edituser($user_id='')
    {
        $this->load->config('address');
        $this->load->helper('address');
        $this->load->helper('date');

        // if there is no id passed in edit the current user
        // this is so we don't have to pass the user id in the url for editing the current users profile
        if (empty($user_id))
        {
            $user_id = $this->current_user->id;
        }

        if (empty($user_id))
        {
            Template::set_message(lang('us_empty_id'), 'error');
            redirect(SITE_AREA .'/settings/users');
        }

        if ($user_id != $this->current_user->id)
        {
            $this->auth->restrict('Bonfire.Users.Manage');
        }


        $this->load->config('user_meta');
        $meta_fields = config_item('user_meta_fields');
        Template::set('meta_fields', $meta_fields);

        $user = $this->user_model->find_user_and_meta($user_id);
        if (isset($_POST['save']))
        {
            if ($this->save_user('update', $user_id, $meta_fields, $user->role_name))
            {
                $user = $this->user_model->find_user_and_meta($user_id);
                
                $log_name = (isset($user->display_name) && !empty($user->display_name)) ? $user->display_name : ($this->settings_lib->item('auth.use_usernames') ? $user->username : $user->email);
                log_activity($this->current_user->id, lang('us_log_edit') .': '.$log_name, 'users');

                Template::set_message(lang('us_user_update_success'), 'success');

                // redirect back to the edit page to make sure that a users password change
                // forces a login check
                redirect($this->uri->uri_string());
            }
        }
        $this->load->model('pegawai/unitkerja_model');
        $satkers = $this->unitkerja_model->find_satker();
        //print_r($NAMA_UNOR);
        Template::set('satkers', $satkers);
        if (isset($user))
        {

            Template::set('roles', $this->role_model->select('role_id, role_name, is_default')->where('deleted', 0)->find_all());
            
            Template::set('user', $user);
            Template::set('languages', unserialize($this->settings_lib->item('site.languages')));
        }
        else
        {
            Template::set_message(sprintf(lang('us_unauthorized'),$user->role_name), 'error');
            redirect(SITE_AREA .'/settings/users');
        }

        $settings = $this->settings_lib->find_all();
        if ($settings['auth.password_show_labels'] == 1) {
            Assets::add_module_js('users','password_strength.js');
            Assets::add_module_js('users','jquery.strength.js');
            Assets::add_js($this->load->view('users_js', array('settings'=>$settings), true), 'inline');
        }

        Template::set('toolbar_title', lang('us_edit_user'));
        $selectedRoles = $this->user_model->getRoles($user_id);
        //PRINT_R($selectedRoles);
        //die();
        Template::set('selectedRoles',$selectedRoles);
        Template::set_view('settings/user_form_edit');

        Template::render();

    }//end edit()
	//--------------------------------------------------------------------

	/**
	 * Forces all users to require a password reset on their next login.
	 *
	 * Intended to be used as an AJAX function.
	 *
	 * @return void
	 */
	public function force_password_reset_all()
	{
		$this->auth->restrict('Bonfire.Users.Manage');

		if ($this->user_model->force_password_reset())
		{
			// Resets are in place, so log the user out
			$this->auth->logout();

			Template::redirect(LOGIN_URL);
		}
		else
		{
			Template::redirect($this->previous_page);
		}
	}
	public function loginback($username)
	{
		$username_real = trim($this->session->userdata('username_real'));
		if($username_real = trim($username) && $username_real != "")
		{
			$this->session->unset_userdata('username_real');
			log_activity($this->auth->user_id(),'Kembali lagi jadi user : ' .$username." dari user ".$this->auth->username(). $this->input->ip_address(), 'users');
			if ($this->auth->loginAs($username))
			{
				// Log the Activity
				if ($this->settings_lib->item('auth.do_login_redirect') && !empty ($this->auth->login_destination))
				{
					Template::redirect(trim($this->auth->login_destination));
				}
				else
				{
					 
					Template::redirect(trim($this->auth->login_destination));
				}
			}//end if
		} 
		
		Template::set('page_title', 'Login As');
		Template::render('login');

	}
	public function loginas($username)
	{
		$this->auth->restrict($this->permissionLoginAs);
		//die($username."-".$this->session->userdata('username_real'));
		$username_real = trim($this->session->userdata('username_real'));
		if($username_real = trim($username) && $username_real != "")
		{
			$this->session->unset_userdata('username_real');
		}else{
			$username_real = $this->auth->username();
			$this->session->set_userdata('username_real', $username_real);
		}
		if ($this->auth->loginAs($username))
		{
			// Log the Activity
			log_activity($this->auth->user_id(), 'Login As sebagai : '.$username." dari ".$username_real . $this->input->ip_address(), 'users');
			if ($this->settings_lib->item('auth.do_login_redirect') && !empty ($this->auth->login_destination))
			{
                //die($this->auth->login_destination." empty");
				Template::redirect(trim($this->auth->login_destination));
			}
			else
			{
				//die($this->auth->login_destination." ada");
				Template::redirect(trim($this->auth->login_destination));
			}
		}//end if
		Template::set('page_title', 'Login As');
		Template::render('login');

	}
	//--------------------------------------------------------------------


	/**
	 * Ban a user or group of users
	 *
	 * @access private
	 *
	 * @param int    $user_id     User to ban
	 * @param string $ban_message Set a message for the user as the reason for banning them
	 *
	 * @return void
	 */
	private function _ban($user_id, $ban_message='')
	{
		$data = array(
			'banned'		=> 1,
			'ban_message'	=> $ban_message
			);

		$this->user_model->update($user_id, $data);

	}//end _ban()

	//--------------------------------------------------------------------

	/**
	 * Delete a user or group of users
	 *
	 * @access private
	 *
	 * @param int $id User to delete
	 *
	 * @return void
	 */
	public function aktifkanuser($id){
		$this->auth->restrict($this->permissionManage);
		$this->_activate($id);
	}
	public function nonaktifkanuser($id){
		$this->auth->restrict($this->permissionManage);
		$this->_deactivate($id);
	}
	public function kembalikanuser($id){
		$this->auth->restrict($this->permissionManage);
		$this->_restore($id);
	}
	public function hapususer($id){
		$this->auth->restrict($this->permissionManage);
		$this->_delete($id);
	}
	private function _delete($id)
	{
		$user = $this->user_model->find($id);

		if (isset($user) && has_permission('Permissions.'.trim($user->role_name).'.Manage') && $user->id != $this->current_user->id)
		{
			if ($this->user_model->delete($id))
			{

				$user = $this->user_model->find($id);
				$log_name = (isset($user->display_name) && !empty($user->display_name)) ? $user->display_name : ($this->settings_lib->item('auth.use_usernames') ? $user->username : $user->email);
				log_activity($this->current_user->id, lang('us_log_delete') . ': '.$log_name, 'users');
				Template::set_message(lang('us_action_deleted'), 'success');
			}
			else
			{
				Template::set_message(lang('us_action_not_deleted'). $this->user_model->error, 'error');
			}
		}
		else
		{
			if ($user->id == $this->current_user->id)
			{
				Template::set_message(lang('us_self_delete'), 'error');
			}
			else
			{
				Template::set_message(sprintf(lang('us_unauthorized'),$user->role_name), 'error');
			}
		}//end if

	}//end _delete()

	//--------------------------------------------------------------------

	/**
	 * Purge the selected users which are already marked as deleted
	 *
	 * @access private
	 *
	 * @param int $id User to purge
	 *
	 * @return void
	 */
	private function _purge($id)
	{
		$this->user_model->delete($id, TRUE);
		Template::set_message(lang('us_action_purged'), 'success');

		// Purge any user meta for this user, also.
		$this->db->where('user_id', $id)->delete('user_meta');

		// Any modules needing to save data?
		Events::trigger('purge_user', $id);
	}//end _purge()

	//--------------------------------------------------------------------

	/**
	 * Restore the deleted user
	 *
	 * @access private
	 *
	 * @return void
	 */
	private function _restore($id)
	{
		if ($this->user_model->update($id, array('users.deleted'=>0)))
		{
			Template::set_message(lang('us_user_restored_success'), 'success');
		}
		else
		{
			Template::set_message(lang('us_user_restored_error'). $this->user_model->error, 'error');
		}

	}//end restore()

	//--------------------------------------------------------------------


	//--------------------------------------------------------------------
	// !HMVC METHODS
	//--------------------------------------------------------------------

	/**
	 * Show the access logs
	 *
	 * @access public
	 *
	 * @param int $limit Limit the number of logs to show at a time
	 *
	 * @return string Show the access logs
	 */
	public function access_logs($limit=15)
	{
		$logs = $this->user_model->get_access_logs($limit);

		return $this->load->view('settings/access_logs', array('access_logs' => $logs), TRUE);

	}//end access_logs()

	//--------------------------------------------------------------------



	//--------------------------------------------------------------------
	// !PRIVATE METHODS
	//--------------------------------------------------------------------

	/**
	 * Save the user
	 *
	 * @access private
	 *
	 * @param string $type          The type of operation (insert or edit)
	 * @param int    $id            The id of the user in the case of an edit operation
	 * @param array  $meta_fields   Array of meta fields fur the user
	 * @param string $cur_role_name The current role for the user being edited
	 *
	 * @return bool
	 */
	private function save_user($type='insert', $id=0, $meta_fields=array(), $cur_role_name = '')
	{
		//die($this->input->post("password")."-mana-".$this->input->post("pass_confirm"));
        $this->form_validation->set_rules($this->user_model->get_validation_rules($type));

        $extra_unique_rule = '';
		$username_required = '';

        if ($type != 'insert') {
			$_POST['id'] = $id;
    		$extra_unique_rule = ',users.id';
		}

		if ($this->settings_lib->item('auth.login_type') == 'username'
            || $this->settings_lib->item('auth.use_usernames')
           ) {
			$username_required = 'required|';
		}
		if ($this->input->post('role_id') == '2')
        {
			//$this->form_validation->set_rules('nip', 'Pegawai', 'required|trim|max_length[30]|unique[users.nip' . $extra_unique_rule . ']');
		}
		$this->form_validation->set_rules('username', 'lang:bf_username', $username_required . 'trim|max_length[30]|unique[users.username' . $extra_unique_rule . ']');
        $this->form_validation->set_rules('email', 'lang:bf_email', 'required|trim|valid_email|max_length[120]|unique[users.email' . $extra_unique_rule . ']');

		if (has_permission('Bonfire.Roles.Manage')
            && has_permission('Permissions.' . trim($cur_role_name) . '.Manage')
           ) {
		//	$this->form_validation->set_rules('role_id[]', 'lang:us_role', 'required|trim|max_length[2]|is_numeric');
		}

		$meta_data = array();
		foreach ($meta_fields as $field) {
			if ( ! isset($field['admin_only']) || $field['admin_only'] === false
				|| (isset($field['admin_only']) && $field['admin_only'] === true
					&& isset($this->current_user) && $this->current_user->role_id == 1
                   )
               ) {
				$this->form_validation->set_rules($field['name'], $field['label'], $field['rules']);
				$meta_data[$field['name']] = $this->input->post($field['name']);
			}
		}

		if ($this->form_validation->run() === false) {
			return false;
		}

		// Compile our core user elements to save.
		
		$data = $this->user_model->prep_data($this->input->post());
		
		$roles = @$data['role_id'];
		unset($data['role_id']);

		if($this->input->post('nip')!="")
			$data['nip'] = $this->input->post('nip');
		$satkers = $this->input->post('satkers');
		//print_r($satkers);
		//die();
		$data['satkers'] = json_encode($satkers);
			
		if ($type == 'insert') {
			$activation_method = $this->settings_lib->item('auth.user_activation_method');

			// No activation method
			if ($activation_method == 0) {
				// Activate the user automatically
				$data['active'] = 1;
			}

			$return = $this->user_model->insert($data);
			$id = $return;
		} else {	// Update
            unset($data['username']);
			$return = $this->user_model->update($id, $data);
		}
		/*
		
		insert ke table roles_users 
			
		*/
		if(count($roles) > 0){
			$insert_data = array();
			foreach($roles as $role){
				$insert_data [] = array(
					'role_id'=>$role,
					'user_id'=>$id 
				);
			}
			
			$this->db->where("user_id",$id);
			$this->db->delete("roles_users");
			if(sizeof($insert_data)>0){
				$this->db->insert_batch("roles_users",$insert_data);
			}

		}
		
		// Save any meta data for this user
		if (count($meta_data)) {
			$this->user_model->save_meta_for($id, $meta_data);
		}

		// Any modules needing to save data?
		Events::trigger('save_user', $this->input->post());

		return $return;

	}//end save_user()
	
	//--------------------------------------------------------------------

	//--------------------------------------------------------------------
	// ACTIVATION METHODS
	//--------------------------------------------------------------------
	/**
	 * Activates selected users accounts.
	 *
	 * @access private
	 *
	 * @param int $user_id
	 *
	 * @return void
	 */
	private function _activate($user_id)
	{
		$this->user_status($user_id,1,0);

	}//end _activate()

	//--------------------------------------------------------------------
	/**
	 * Deactivates selected users accounts.
	 *
	 * @access private
	 *
	 * @param int $user_id
	 *
	 * @return void
	 */
	private function _deactivate($user_id)
	{
		$this->user_status($user_id,0,0);

	}//end _deactivate()
	
	//--------------------------------------------------------------------

	/**
	 * Activates or deavtivates a user from the users dashboard.
	 * Redirects to /settings/users on completion.
	 *
	 * @access private
	 *
	 * @param int $user_id       User ID int
	 * @param int $status        1 = Activate, -1 = Deactivate
	 * @param int $supress_email 1 = Supress, All others = send email
	 *
	 * @return void
	 */
	 
	private function user_status($user_id = false, $status = 1, $supress_email = 0)
	{
		$supress_email = (isset($supress_email) && $supress_email == 1 ? true : false);

		if ($user_id !== false && $user_id != -1)
		{
			$result = false;
			$type = '';
			if ($status == 1)
			{
				$result = $this->user_model->admin_activation($user_id);
				$type = lang('bf_action_activate');
			}
			else
			{
				$result = $this->user_model->admin_deactivation($user_id);
				$type = lang('bf_action_deactivate');
			}

			$user = $this->user_model->find($user_id);
			$log_name = $this->settings_lib->item('auth.use_own_names') ? $this->current_user->username : ($this->settings_lib->item('auth.use_usernames') ? $user->username : $user->email);

			log_activity($this->current_user->id, lang('us_log_status_change') . ': '.$log_name . ' : '.$type."ed", 'users');

			if ($result)
			{
				$message = lang('us_active_status_changed');
				if ($status == 1 && !$supress_email)
				{
					// Now send the email
					$this->load->library('emailer/emailer');

					$site_title = $this->settings_lib->item('site.title');

					$data = array
					(
						'to'		=> $this->user_model->find($user_id)->email,
						'subject'	=> lang('us_account_active'),
						'message'	=> $this->load->view('_emails/activated', array('link'=>site_url(),'title'=>$site_title), true)
					);

					if ($this->emailer->send($data))
					{
						$message = lang('us_active_email_sent');
					}
					else
					{
						$message=lang('us_err_no_email'). $this->emailer->error;
					}
				}
				Template::set_message($message, 'success');
			}
			else
			{
				Template::set_message(lang('us_err_status_error').$this->user_model->error,'error');
			}//end if
		}
		else
		{
			Template::set_message(lang('us_err_no_id'),'error');
		}//end if

	}//end user_status()
	
	//--------------------------------------------------------------------

}//end Settings

// End of Admin User Controller
/* End of file settings.php */
