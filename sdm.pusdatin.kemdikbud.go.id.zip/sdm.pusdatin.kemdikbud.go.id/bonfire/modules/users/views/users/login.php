<link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
<body class="gray-bg">

    <div class="loginColumns animated fadeInDown">
        <div class="row">

            <div class="col-md-6 align-middle align-text-bottom" style="height: 200px;">
	                <center>
	                <p>
	                	<br><br><br>
	                    	<h2>E-INFORMASI MANAJEMEN PEGAWAI</h2>
	                    					<br>
								PUSAT DATA DAN TEKNOLOGI INFORMASI
	                </p>
            		</center>
            </div>
            <div class="col-md-6">
                <div class="ibox-content">
                	<center><img src="<?php echo base_url(); ?>assets/images/logo.png" width="80px"/></center>
                	<br>
                	<h2>Silahkan Login</h2>

					<?php echo Template::message(); ?>

					<?php
						if (validation_errors()) :
					?>
					<div class="row-fluid">
						<div class="span12">
							<div class="alert alert-error fade in">
							  <a data-dismiss="alert" class="close">&times;</a>
								<?php echo validation_errors(); ?>
							</div>
						</div>
					</div>
					<?php endif; ?>

                    <?php echo form_open(LOGIN_URL, array('autocomplete' => 'off')); ?>
                        <div class="form-group">
                        	<input class="form-control" type="text" name="login" id="login_value" value="<?php echo set_value('login'); ?>" tabindex="1" placeholder="Username" />
                        </div>

                        <div class="input-group">
                          <span class="input-group-addon input-group-addon-password" id="input-group-addon-password"><i class="fa fa-eye" style="color:red"></i></span>
                          <input type="password" class="form-control" name="password" tabindex="2" id="passwordanda" placeholder="Password">

                        </div>
                        <br>
                        <button type="submit" name="log-me-in" class="btn btn-primary block full-width m-b">Login</button>

                        <a href="<?php echo base_url(); ?>forgot_password" class="btn btn-danger block full-width m-b">
                            <small>Lupa password?</small>
                        </a>

                        <p class="text-muted text-center">
                            <small>anda tidak punya akun?</small><br>
                            Silahkan hubungi administrator
                        </p>
                        
                    </form>
                     
                </div>
            </div>
        </div>
        <hr/>
        <div class="row">
            <div class="col-md-6">
                Copyright Pusdatin
            </div>
            <div class="col-md-6 text-right">
               <small>© 2018</small>
            </div>
        </div>
    </div>

</body>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap-show-password.js"></script>